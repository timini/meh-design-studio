from pathlib import Path
from meh_studio.boundary_lab import BoundaryLabRuntime, SolveRequest
root=Path('/Users/timrichardson/Documents/Codex/2026-09-06/i/work')
runtime=BoundaryLabRuntime(root/'boundary-lab-research',root/'boundary-lab-runtime/bin/python3.11',root/'julia-runtime/julia-1.12.6/bin/julia',julia_threads=4)
print(runtime.solve(root/'r1-radiating-project-first/project.blab.json',SolveRequest(frequencies_hz=(240.,),retain=('fem_nodal_pressure','bem_boundary_pressure','bem_boundary_neumann')),root/'r1-radiating-solve-first',timeout_s=600))
