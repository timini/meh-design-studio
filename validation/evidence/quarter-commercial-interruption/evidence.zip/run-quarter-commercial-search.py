"""Predeclare a public-data full-band quarter-model evolutionary experiment."""
from pathlib import Path
import argparse,json,subprocess
from meh_studio.boundary_lab import BoundaryLabRuntime,sha256
from meh_studio.catalogue import Catalogue
from meh_studio.domain import DriverRevision
from meh_studio.geometry import HornGeometry
from meh_studio.optimisation import SearchBrief,candidates,optimise
from meh_studio.evolution import validate_bounds
from meh_studio.build_bundle import export_search
from meh_studio.search_results import load_completed_search
root=Path.cwd();runs=root/'runs';source=runs/'quarter-commercial-source'
parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');args=parser.parse_args()
commit=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
assert commit=='d90dc02d4da9c66896fb9ad4aa97095b551052f1'
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True)
import meh_studio.geometry
assert Path(meh_studio.geometry.__file__).resolve().is_relative_to(source)
prior_path=runs/'nonlinear-commercial-search-controls.json';prior=json.loads(prior_path.read_text())
case=next(c for c in prior['cases'] if c['label']=='exponential-round')
base=HornGeometry.model_validate(case['base']|{'solver_symmetry':'xy','mesh_size_m':.004,
 'maximum_tetrahedra':500000,'maximum_exterior_triangles':16000})
value=case['brief'];value.update(trial_budget=12,seed=20260919)
value['evolution']['geometry_bounds'].pop('driver_axial_offset_m')
value['evolution']['geometry_bounds']['driver_tilt_deg']=[0.,25.]
brief=SearchBrief.model_validate(value);validate_bounds(brief.evolution,base)
drivers=[DriverRevision.model_validate(d) for d in prior['drivers']]
assert candidates(brief,base,drivers)[0]['design'].content_hash==base.content_hash
assert brief.acoustic_objectives.minimum_bank_impedance_ohm==2.
assert brief.acoustic_objectives.acoustic_handover_hz==(3000.,5000.)
assert brief.acoustic_objectives.mid_highpass_hz==350.
assert brief.build_budget.maximum_total_cost==300.
assert len(brief.frequencies_hz)==15 and brief.frequencies_hz[-1]==7500.
controls={'application_source_commit':commit,'runner_sha256':sha256(Path(__file__)),
 'prior_commercial_controls_sha256':sha256(prior_path),'base':base.model_dump(mode='json'),
 'brief':brief.model_dump(mode='json'),'drivers':[d.model_dump(mode='json') for d in drivers],
 'backend':'coupled_reference','julia_threads':2,'solver_stage_timeout_s':7200,
 'maximum_total_tetrahedra':500000,'maximum_final_exterior_triangles':10000,
 'response_screen_limit_db':6.,'electrical_relative_tolerance':1e-8,
 'source_data':'Existing public Peerless catalogue and official FaitalPRO records, with their unchanged provenance and qualification states',
 'selection':'Twelve seeded evolutionary proposals on identical frequency, mesh and DSP controls; seed, elite mutation and every-third-proposal random exploration. Geometry, profile, tilt and bank loading all evaluated from newly generated full CAD.',
 'qualified':False,'limitations':[
 'Reported FaitalPRO and provisional Peerless ideal-outlet model; no measured phase-plug, breakup or load-dependent driver qualification',
 'Exploration retains declared commercial 350Hz highpass, 3-5kHz acoustic handover, 2ohm bank and GBP300 build constraints',
 'Twelve proposals are not a global optimum; denser heldout, mesh stability and physical comparisons remain necessary',
 '20m finite-distance observations are not a qualified far-field reference',
 'Ideal diaphragm/rear-cup geometry does not establish purchased-driver basket fit, output or print qualification']}
path=runs/'quarter-commercial-controls.json'
if args.prepare:
 with path.open('x') as stream:stream.write(json.dumps(controls,indent=2)+'\n')
 print(json.dumps({'controls_sha256':sha256(path),'source_commit':commit,'trial_budget':brief.trial_budget},indent=2));raise SystemExit
assert json.loads(path.read_text())==controls
class BoundedRuntime(BoundaryLabRuntime):
 def solve(self,project,request,output,*,timeout_s=7200):
  import meshio
  from meh_studio.radiation_geometry import surface_integrity
  document=json.loads(Path(project).read_text());assert document['symmetry']=='xy';total=0
  for resource in document['physical_system']['meshes']:
   mesh_path=Path(project).parent/resource['file']
   if resource['purpose']=='fem_volume':
    mesh=meshio.read(mesh_path);total+=sum(len(cell.data) for cell in mesh.cells if cell.type=='tetra')
   else:surface_integrity(mesh_path,maximum_triangles=controls['maximum_final_exterior_triangles'],symmetry='xy')
  assert total<=controls['maximum_total_tetrahedra'],'commercial quarter concurrent tetrahedron cap exceeded'
  return super().solve(project,request,output,timeout_s=timeout_s)
output=runs/'quarter-commercial-search';database=runs/'quarter-commercial.sqlite'
assert not output.exists() and not database.exists()
with Catalogue.create(database) as catalogue:
 for driver in drivers:catalogue.add(driver)
native=runs/'runtime';runtime=BoundedRuntime(native/'boundary-lab',native/'blab-env/bin/python',
 native/'julia-1.12.6/bin/julia','coupled_reference',julia_threads=2)
result=optimise(brief,base,database,runtime,output,solver_stage_timeout_s=7200)
(output/'experiment-provenance.json').write_text(json.dumps({'application_source_commit':commit,
 'controls_sha256':sha256(path),'qualified':False,'limitations':controls['limitations']},indent=2)+'\n')
load_completed_search(output)
export=export_search(output,runs/'quarter-commercial-winner.zip')
(output/'export-verification.json').write_text(json.dumps(export,indent=2)+'\n')
print(json.dumps({'status':result['status'],'winner_index':result['winner_index'],'export':export},indent=2))
