"""Preserve the original unfinalised experiment and externally observed termination."""
from pathlib import Path
import json,hashlib,zipfile
root=Path.cwd();runs=root/'runs'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
observation=json.loads((runs/'quarter-commercial-terminal-observation.json').read_text())
assert observation['observed_exit_code']==137
assert digest(runs/'quarter-commercial-search/search.json')==observation['search_json_sha256']
assert digest(runs/'quarter-commercial-native.log')==observation['native_log_sha256']
assert digest(runs/'quarter-commercial-controls.json')==observation['controls_sha256']
paths=[p for p in (runs/'quarter-commercial-search').rglob('*') if p.is_file()]
paths += [runs/name for name in ['quarter-commercial-controls.json','run-quarter-commercial-search.py',
 'quarter-commercial-prepare.log','quarter-commercial-native.log','quarter-commercial-terminal-observation.json',
 'archive-quarter-commercial-interruption.py']]
assert not list((runs/'quarter-commercial-search').glob('trial-*/evaluation/evaluation.json'))
identities={p.relative_to(runs).as_posix():digest(p) for p in sorted(paths)}
out=root/'validation/evidence/quarter-commercial-interruption';out.mkdir(exist_ok=False)
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(paths):z.write(p,p.relative_to(runs).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,sha in identities.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha
assert identities=={p.relative_to(runs).as_posix():digest(p) for p in sorted(paths)}
assert archive.stat().st_size<100_000_000
report={'status':'archived_abrupt_termination','observation':observation,'original_manifest_unchanged':True,
 'no_native_evaluations_completed':True,'source_commit':observation['source_commit'],
 'archives':[{'file':'evidence.zip','size_bytes':archive.stat().st_size,'sha256':digest(archive)}],
 'archived_file_sha256':identities,'qualified':False}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'archives':report['archives'],'files':len(paths)},indent=2))
