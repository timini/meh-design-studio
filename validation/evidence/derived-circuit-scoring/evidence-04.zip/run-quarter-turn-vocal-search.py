"""Full-size four-proposal periodic-profile search after the larger-port handover failure."""
from pathlib import Path
import argparse,json
from meh_studio.boundary_lab import BoundaryLabRuntime,sha256
from meh_studio.catalogue import Catalogue
from meh_studio.domain import DriverRevision
from meh_studio.geometry import HornGeometry
from meh_studio.optimisation import SearchBrief,candidates,optimise,verified_assessment
from meh_studio.evolution import validate_bounds
root=Path.cwd();prior=root/'runs/wide-vocal-search'
saved_path=prior/'trial-000/candidate.json';saved=json.loads(saved_path.read_text())
failure_path=root/'runs/large-port-handover-diagnostic.json';failure=json.loads(failure_path.read_text())
assert all(not r['continuous_interval_exists'] for r in failure['gain_feasibility'])
failed_trial=root/'runs/large-port-vocal-search/trial-000'
assert verified_assessment(failed_trial/'system/project.blab.json',failed_trial/'evaluation')==failure['evidence_identity']
assert sha256(root/'runs/large-port-vocal-search/search.json')==failure['search_sha256']
assert json.loads((root/'runs/large-port-vocal-search/search.json').read_text())['status']=='failed'
data=saved['design']|{'profile_interpolation':'periodic_cubic'}
for section in data['profile_sections']:
    old=section['radial_scales']
    grouped=[sum(old[i] for i in group)/len(group) for group in ((0,2,4,6),(1,3,5,7))]
    section['radial_scales']=[grouped[i%2] for i in range(8)]
base=HornGeometry.model_validate(data);drivers=[DriverRevision.model_validate(d) for d in saved['driver_revisions']]
controls=json.loads((prior/'brief.json').read_text());controls.update(trial_budget=4,seed=20260913)
controls['evolution'].update(profile_symmetry='quarter_turn',profile_scale_bounds=[.65,1.5],
    elite_size=1,explore_every=3,sigma_fraction=.12)
controls['acoustic_objectives']['observation_distance_m']=20.
brief=SearchBrief.model_validate(controls);validate_bounds(brief.evolution,base)
assert candidates(brief,base,drivers)[0]['design'].content_hash==base.content_hash
assert brief.acoustic_objectives.minimum_bank_impedance_ohm==2.
assert brief.acoustic_objectives.acoustic_handover_hz==(3000.,5000.)
assert brief.build_budget.maximum_total_cost==300.
provenance={'application_source_commit':'ab6714f','source_worktree':'runs/periodic-profile-source',
    'reference_candidate_sha256':sha256(saved_path),'larger_port_failure_sha256':sha256(failure_path),
    'seed_selection':'Original ports retained because the larger-port variant has no continuous mid gain satisfying the unchanged LR4 handover constraints',
    'new_seed_geometry':'Explicit cardinal/diagonal averaging and periodic_cubic interpolation; this is a new physical model requiring fresh meshes and a solve',
    'search_design':'Baseline and fitness-driven elite mutations when completed candidates are eligible, with random exploration at proposal 3 or after failures, all on the same 15-frequency full-sphere grid',
    'profile_scale_bounds':[.65,1.5],'observation_distance_m':20.,'solver_stage_timeout_s':7200,
    'response_screen_limit_db':6.,'qualification':False,
    'limitations':['Four proposals are a bounded search, not a global optimum',
        'Complex64 exploratory solves do not pass the separate 1e-8 electrical qualification gate',
        'Reported FaitalPRO mid circuits, synthetic HF and idealised cavities; no source, cone/motor fit or print qualification',
        '15 training frequencies and 20 m finite-distance observations, not a holdout, convergence result or far-field qualification']}
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');args=parser.parse_args()
    (root/'runs/quarter-turn-vocal-controls.json').write_text(json.dumps({'brief':brief.model_dump(mode='json'),
        'base':base.model_dump(mode='json'),'provenance':provenance},indent=2)+'\n')
    if args.prepare:print(json.dumps(provenance,indent=2))
    else:
        native=root/'runs/runtime';database=root/'runs/quarter-turn-vocal-search.sqlite';output=root/'runs/quarter-turn-vocal-search'
        with Catalogue.create(database) as catalogue:
            for driver in drivers:catalogue.add(driver)
        runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',native/'julia-1.12.6/bin/julia',
            'beat_cpu',julia_threads=4)
        result=optimise(brief,base,database,runtime,output,solver_stage_timeout_s=7200)
        (output/'experiment-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
        print(json.dumps(result,indent=2))
