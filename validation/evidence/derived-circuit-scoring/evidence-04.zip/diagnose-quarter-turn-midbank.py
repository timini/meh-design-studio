"""Inspect the completed periodic target's coherent common-mid response."""
from pathlib import Path
import json
import numpy as np
from meh_studio.boundary_lab import sha256,_contained
from meh_studio.optimisation import verified_assessment
root=Path.cwd();trial=root/'runs/quarter-turn-vocal-search/trial-000'
project=trial/'system/project.blab.json';evaluation=trial/'evaluation'
evidence=verified_assessment(project,evaluation)
raw=evaluation/'upstream';manifest=json.loads((raw/'manifest.json').read_text())
system=json.loads(project.read_text())['physical_system']
ports={p['id']:p['component_id'] for p in system['excitation_ports']}
ids=[ports[p] for p in manifest['excitation_port_ids']];mids=[i for i,c in enumerate(ids) if c!='component:throat']
domains=json.loads(_contained(raw,manifest['domains_metadata_file']).read_text())['domains']
domain=next(d for d in domains if d['id']=='observation:horizontal-polar')
with np.load(_contained(raw,manifest['domains_file']),allow_pickle=False) as data:
    angles=data[domain['coordinates']['angle_deg']].copy()
axis=np.flatnonzero(angles==0);assert len(axis)==1
terms=[];velocity=[];current=[]
for row in manifest['results']:
    meta=json.loads(_contained(raw,row['metadata_file']).read_text());q={r['id']:r for r in meta['quantities']}
    assert meta['diagnostics']['transducer_reference_voltage_v']==2.83
    with np.load(_contained(raw,row['arrays_file']),allow_pickle=False) as data:
        terms.append(data[q['acoustic:pressure:horizontal-polar']['key']][mids,axis[0]].astype(complex)/2.83)
        for name,target in (('mechanical:diaphragm-velocity',velocity),('electrical:voice-coil-current',current)):
            quantity=q[name];order=quantity['metadata']['component_ids']
            target.append(data[quantity['key']][:,[order.index(c) for c in ids]][mids,:].astype(complex).sum(axis=0)/2.83)
terms=np.asarray(terms);velocity=np.asarray(velocity);current=np.asarray(current)
coherence=abs(terms.sum(axis=1))/abs(terms).sum(axis=1)
assert np.all(coherence>0) and np.all(coherence<=1.+1e-12)
report={'status':'complete','application_source_commit':'40e23d4','native_source_commit':'ab6714f',
    'native_evidence':evidence,'runner_sha256':sha256(Path(__file__)),
    'frequencies_hz':manifest['frequencies_hz'],'mid_component_ids':[ids[i] for i in mids],
    'normalisation':'One common mid-bank volt before DSP, HF amplifier at zero volts; no RMS or SPL calibration',
    'contribution_definition':'Complete mutually coupled field from each mid voltage excitation, not isolated receiving diaphragm radiation',
    'observation_distance_m':20.,'mid_excitation_axial_amplitude_pa_per_v':abs(terms).tolist(),
    'mid_excitation_axial_phase_deg':np.angle(terms,deg=True).tolist(),
    'mid_excitation_coherent_sum_pa_per_v':abs(terms.sum(axis=1)).tolist(),
    'coherent_sum_relative_to_magnitude_sum_db':(20*np.log10(coherence)).tolist(),
    'receiving_component_ids':ids,'receiving_velocity_magnitude_m_s_per_v':abs(velocity).tolist(),
    'receiving_velocity_phase_deg':np.angle(velocity,deg=True).tolist(),
    'receiving_current_magnitude_a_per_v':abs(current).tolist(),
    'qualified':False,'physical_validation':False,
    'limitations':['Algebraic excitation decomposition, not a unique identification of the physical cause of a dip',
        'Complex64 native storage; no strict electrical qualification, convergence, physical or print qualification',
        'Finite 20 m and training frequencies; pre-DSP amplitudes do not establish corrective EQ headroom']}
assert verified_assessment(project,evaluation)==evidence
(root/'runs/quarter-turn-midbank-diagnostic.json').write_text(json.dumps(report,indent=2)+'\n')
for f,p,c in zip(manifest['frequencies_hz'],abs(terms.sum(axis=1)),20*np.log10(coherence)):
    print(f'{f:5.0f} Hz: {p:.6g} Pa/V at 20m, coherent/magnitude sum {c:.6g} dB')
