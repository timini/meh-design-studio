from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter
root=Path.cwd();comparison=root/'runs/quarter-turn-commercial-circuit/diagnostic.json'
r=json.loads(comparison.read_text());mid=json.loads((root/'runs/quarter-turn-midbank-diagnostic.json').read_text())
f=np.asarray(mid['frequencies_hz']);fig,axes=plt.subplots(2,1,figsize=(10,7),sharex=True,layout='constrained')
for key,label,color in [('baseline','Synthetic HF reference','#2368a2'),('replacement','Provisional Peerless HF','#d56b22')]:
 s=r[key]['selected'];y=np.asarray(s['target_residual_db']);y-=(y.max()+y.min())/2
 axes[0].plot(f,y,'o-',color=color,label=f'{label}: {s["ripple_db"]:.2f} dB range',markersize=4)
axes[0].axhspan(-3,3,color='#3a9163',alpha=.12,label='6 dB range target')
axes[0].set_ylabel('Response minus target roll-off (dB)\nrange centred')
axes[0].legend(fontsize=9,loc='lower left')
axes[0].set_title('Completed curved-profile candidate: response target still missed',loc='left',fontweight='bold')
axes[1].plot(f,mid['mid_excitation_coherent_sum_pa_per_v'],'o-',color='#2368a2',markersize=4)
axes[1].set_ylabel('Raw mid-bank pressure\n(native Pa/V at 20 m)')
axes[1].set_xlabel('Frequency (Hz)')
axes[1].set_yscale('log')
axes[1].annotate('3 kHz dip remains with\nonly 0.018 dB excitation cancellation',xy=(3000,mid['mid_excitation_coherent_sum_pa_per_v'][10]),xytext=(1050,.011),arrowprops={'arrowstyle':'->','color':'#555'},fontsize=9)
for ax in axes:
 ax.set_xscale('log');ax.xaxis.set_minor_formatter(NullFormatter());ax.grid(True,which='both',alpha=.2);ax.set_xlim(330,8000)
 axes[-1].set_xticks([350,700,1000,2000,3000,5000,7500],['350','700','1000','2000','3000','5000','7500'])
fig.suptitle('15 training frequencies; 20 m finite-distance simulation; complex64 native basis\nIdealised sources/cavities. No physical, output, convergence or print qualification.',fontsize=10)
fig.savefig(root/'runs/quarter-turn-response-diagnostic.png',dpi=180)
