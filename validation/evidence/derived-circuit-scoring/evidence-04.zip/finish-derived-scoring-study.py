"""Archive the replay and complete target trial zero without freezing a running search."""
from pathlib import Path
import json,zipfile
from meh_studio.boundary_lab import sha256
from meh_studio.optimisation import verified_assessment
root=Path.cwd();replay=root/'runs/derived-scoring-replay'
report=json.loads((replay/'report.json').read_text())
controls=json.loads((root/'runs/derived-scoring-replay-controls.json').read_text())
assert report['status']=='complete'
assert sha256(root/'runs/derived-scoring-replay-controls.json')==report['controls_sha256']
for case in controls['native_cases']:
    assert verified_assessment(Path(case['project']),Path(case['evaluation']))==case['evidence']
    assert sha256(Path(case['trial'])/'score.json')==case['native_score_sha256']
for item in report['derived']:
    assert item['comparison']['passed']
    folder=replay/item['label'];assert sha256(folder/'derived.json')==item['derived_report_sha256']
    dr=json.loads((folder/'derived.json').read_text())
    assert sha256(folder/'circuit-basis.npz')==dr['circuit_basis_sha256']
    assert all(sha256(folder/row['arrays_file'])==row['arrays_sha256'] for row in dr['rows'])
old=root/'runs/quarter-turn-commercial-circuit'
old_report=json.loads((old/'derived.json').read_text())
new_report=json.loads((replay/'full-size/derived.json').read_text())
assert old_report['circuit_basis_sha256']==new_report['circuit_basis_sha256']
assert all(a['arrays_sha256']==b['arrays_sha256'] for a,b in zip(old_report['rows'],new_report['rows'],strict=True))
# Keep the earlier diagnostics and report. Its identical field files are included
# once, under the new scored dataset, with an explicit relocation map below.
old_reports=[old/'derived.json',old/'diagnostic.json']
trial=root/'runs/quarter-turn-vocal-search/trial-000'
paths=sorted(p for directory in (trial,replay) for p in directory.rglob('*') if p.is_file())
paths+=old_reports
names=['replay-derived-scoring.py','derived-scoring-replay-controls.json','derived-scoring-prepare.log',
    'derived-scoring-replay.log','derived-scoring-unit-tests.log','finish-derived-scoring-study.py',
    'run-quarter-turn-vocal-search.py','quarter-turn-vocal-controls.json',
    'compare-quarter-turn-commercial-circuit.py','quarter-turn-commercial-circuit-controls.json',
    'quarter-turn-commercial-circuit.log','diagnose-quarter-turn-midbank.py',
    'quarter-turn-midbank-diagnostic.json','quarter-turn-midbank-diagnostic.log',
    'plot-quarter-turn-diagnostic.py','quarter-turn-response-diagnostic.png']
paths += [root/'runs'/name for name in names]
paths += [trial.parent/'brief.json']
target=root/'validation/evidence/derived-circuit-scoring';target.mkdir(parents=True,exist_ok=False)
groups=[];files=[];size=0
for path in paths:
    n=path.stat().st_size;assert n<90_000_000
    if files and size+n>75_000_000:groups.append(files);files=[];size=0
    files.append(path);size+=n
if files:groups.append(files)
archives=[]
for index,files in enumerate(groups):
    archive_path=target/f'evidence-{index:02d}.zip'
    with zipfile.ZipFile(archive_path,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for path in files:archive.write(path,str(path.relative_to(root/'runs')))
    assert archive_path.stat().st_size<100_000_000
    with zipfile.ZipFile(archive_path) as archive:assert archive.testzip() is None
    archives.append({'file':archive_path.name,'sha256':sha256(archive_path),'size_bytes':archive_path.stat().st_size})
result={'status':'completed_native_and_derived_scoring_replay','application_source_commit':'93da10c',
    'native_source_commits':['ab6714f','40e23d4'],
    'small_native_archive_reports':['../periodic-profile-symmetry/report.json','../circuit-reanalysis/report.json'],
    'archives':archives,'replay':report,
    'full_size_native_trial_archive':'quarter-turn-vocal-search/trial-000',
    'full_size_search_completion_claimed':False,
    'identical_earlier_derived_array_relocation':{
        'from':'quarter-turn-commercial-circuit','to':'derived-scoring-replay/full-size',
        'files':['circuit-basis.npz']+[r['arrays_file'] for r in old_report['rows']]},
    'native_response_variation_db':14.467794071242732,'derived_response_variation_db':14.99597492691643,
    'response_screen_limit_db':6.,'response_screen_passed':False,
    'qualified':False,'physical_validation':False,
    'limitations':['Target trial zero is complete, but its four-proposal search remains running and is not archived as complete',
        'Full-size complex64 basis fails the separate unchanged 1e-8 electrical gate',
        'No target acceptance, source measurement, convergence, physical fit, manufacturing or output qualification']}
(target/'report.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
