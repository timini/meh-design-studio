"""Replay native and derived DSP selection using the shared production kernel."""
from pathlib import Path
import argparse,contextlib,json,math
from meh_studio.boundary_lab import sha256
from meh_studio.optimisation import verified_assessment,SearchBrief
from meh_studio.acoustic_objectives import score_acoustics
from meh_studio.generated_system import HornSources
from meh_studio.cli import main
root=Path.cwd();parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');args=parser.parse_args()
trials=[root/'runs/periodic-symmetry-search/trial-000',root/'runs/circuit-reanalysis-search/trial-000',
    root/'runs/quarter-turn-vocal-search/trial-000']
cases=[]
for trial in trials:
    project=trial/'system/project.blab.json';evaluation=trial/'evaluation';brief=trial.parent/'brief.json'
    cases.append({'trial':str(trial),'project':str(project),'evaluation':str(evaluation),'brief':str(brief),
        'brief_sha256':sha256(brief),'native_score_sha256':sha256(trial/'score.json'),
        'evidence':verified_assessment(project,evaluation)})
diagnostic=root/'runs/quarter-turn-commercial-circuit/diagnostic.json'
controls={'application_source_commit':'93da10c','native_cases':cases,
    'full_size_independent_diagnostic_sha256':sha256(diagnostic),
    'predeclared_limits':{'native_score_absolute':1e-10,'small_fresh_native_derived_score_absolute':1e-8,
        'full_size_independent_derived_score_absolute':1e-10},
    'qualified':False,'physical_validation':False}
control_path=root/'runs/derived-scoring-replay-controls.json'
if args.prepare:
    with control_path.open('x') as stream:stream.write(json.dumps(controls,indent=2)+'\n')
    print(json.dumps(controls,indent=2));raise SystemExit
assert json.loads(control_path.read_text())==controls
output=root/'runs/derived-scoring-replay';output.mkdir(exist_ok=False)

def compare(actual,expected,limit):
    errors=[]
    def visit(a,b,path=''):
        if isinstance(a,dict):
            assert a.keys()==b.keys(),path
            for k in a:visit(a[k],b[k],path+'/'+k)
        elif isinstance(a,list):
            assert len(a)==len(b),path
            for i,(aa,bb) in enumerate(zip(a,b)):visit(aa,bb,path+'/'+str(i))
        elif isinstance(a,(float,int)) and not isinstance(a,bool):
            assert isinstance(b,(float,int)) and math.isfinite(a) and math.isfinite(b),path
            error=abs(a-b);assert error<=limit,(path,error,limit);errors.append(error)
        else:assert a==b,(path,a,b)
    visit(actual,expected)
    return {'maximum_absolute_difference':max(errors,default=0.),'numeric_leaves_compared':len(errors),'limit':limit,'passed':True}

native=[]
for case in cases:
    brief=SearchBrief.model_validate_json(Path(case['brief']).read_text())
    actual=score_acoustics(Path(case['project']),Path(case['evaluation']),brief.side_gains,brief.acoustic_objectives)
    expected=json.loads((Path(case['trial'])/'score.json').read_text())
    native.append({'trial':case['trial'],'comparison':compare(actual,{k:expected[k] for k in actual},1e-10)})
replacement=HornSources.model_validate_json((trials[1]/'system/sources.json').read_text()).throat
derived=[]
for label,index in (('small',0),('full-size',2)):
    case=cases[index];old=HornSources.model_validate_json((Path(case['project']).parent/'sources.json').read_text())
    sources=HornSources.model_validate(old.model_dump()|{'throat':replacement})
    source_path=output/(label+'-sources.json');source_path.write_text(sources.model_dump_json(indent=2)+'\n')
    target=output/label
    with (output/(label+'-cli.json')).open('w') as stream,contextlib.redirect_stdout(stream):
        code=main(['reanalyse-circuits',case['project'],'--evaluation',case['evaluation'],
            '--sources',str(source_path),'--output',str(target),'--brief',case['brief']])
    assert code==0
    report=json.loads((target/'derived.json').read_text());scoring=report['acoustic_scoring']
    assert report['status']=='complete' and scoring['status']=='complete'
    assert not report['qualified'] and 'electrical_validation' not in scoring['score']
    actual=scoring['score']
    if label=='small':
        expected=json.loads((trials[1]/'score.json').read_text())
        comparison=compare(actual,{k:expected[k] for k in actual},1e-8)
    else:
        expected=json.loads(diagnostic.read_text())['replacement']['selected']
        keys=('ripple_db','directivity_error_db','acoustic_objective','drive_settings','relative_response_db','acoustic_handover')
        comparison=compare({k:actual[k] for k in keys},{k:expected[k] for k in keys},1e-10)
    derived.append({'label':label,'derived_report_sha256':sha256(target/'derived.json'),
        'comparison':comparison,'ripple_db':actual['ripple_db'],'drive_settings':actual['drive_settings'],
        'native_storage_dtypes':report['native_storage_dtypes'],'qualified':False})
for case in cases:
    assert verified_assessment(Path(case['project']),Path(case['evaluation']))==case['evidence']
    assert sha256(Path(case['trial'])/'score.json')==case['native_score_sha256']
    assert sha256(Path(case['brief']))==case['brief_sha256']
result={'status':'complete','application_source_commit':'93da10c','controls_sha256':sha256(control_path),
    'runner_sha256':sha256(Path(__file__)),'native':native,'derived':derived,
    'qualified':False,'physical_validation':False,
    'limitations':['Replay of previously completed native fields, no new acoustic solve or geometry search',
        'Small reference uses synthetic mids and provisional HF; full-size replacement still fails the 6 dB response screen',
        'No new source, physical, convergence, manufacturing or output qualification']}
(output/'report.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
