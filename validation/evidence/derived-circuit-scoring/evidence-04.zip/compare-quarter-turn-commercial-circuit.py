"""Derived source comparison on completed trial zero, without promoting the search."""
from pathlib import Path
import itertools,json
import numpy as np
from meh_studio.boundary_lab import sha256,_contained
from meh_studio.optimisation import verified_assessment,SearchBrief,relative_response
from meh_studio.generated_system import HornSources
from meh_studio.domain import DriverRevision
from meh_studio.circuit_reanalysis import reanalyse_circuits
from meh_studio.acoustic_objectives import drive_weights,lr4,polar_error,parallel_bank,verify_observation_distance
from meh_studio.acoustic_handover import acoustic_handover
from meh_studio.spherical_metrics import sphere_error

root=Path.cwd();trial=root/'runs/quarter-turn-vocal-search/trial-000'
project=trial/'system/project.blab.json';evaluation=trial/'evaluation'
brief_path=trial.parent/'brief.json';brief=SearchBrief.model_validate_json(brief_path.read_text())
obj=brief.acoustic_objectives;verify_observation_distance(project,obj)
assert obj.minimum_bank_impedance_ohm==2. and obj.acoustic_handover_hz==(3000.,5000.)
assert brief.build_budget.maximum_total_cost==300.
native_evidence=verified_assessment(project,evaluation)
native_score_path=trial/'score.json';native_score_hash=sha256(native_score_path)
native_score=json.loads(native_score_path.read_text())
old=HornSources.model_validate_json((project.parent/'sources.json').read_text())
replacement_path=root/'examples/reported-drivers/peerless-dfm2535-8-ideal-outlet.json'
replacement=DriverRevision.model_validate_json(replacement_path.read_text())
new=HornSources.model_validate(old.model_dump()|{'throat':replacement.source_model})
controls_path=root/'runs/quarter-turn-commercial-circuit-controls.json'
controls={'application_source_commit':'40e23d4','native_source_commit':'ab6714f',
    'native_evidence':native_evidence,'native_score_sha256':native_score_hash,
    'brief_sha256':sha256(brief_path),'replacement_driver_file_sha256':sha256(replacement_path),
    'new_sources':new.model_dump(mode='json'),
    'predeclared_limits':{'native_score_replay_absolute':1e-10,'response_screen_db':6.},
    'objectives':obj.model_dump(mode='json'),'side_gains':brief.side_gains,
    'qualified':False,'physical_validation':False}
with controls_path.open('x') as stream:stream.write(json.dumps(controls,indent=2)+'\n')
derived=root/'runs/quarter-turn-commercial-circuit'
report=reanalyse_circuits(project,evaluation,new,derived)
raw=evaluation/'upstream';manifest=json.loads((raw/'manifest.json').read_text())
ids=report['component_ids'];f=np.asarray(manifest['frequencies_hz'])
assert list(f)==list(brief.frequencies_hz)
domains=json.loads(_contained(raw,manifest['domains_metadata_file']).read_text())['domains']
with np.load(_contained(raw,manifest['domains_file']),allow_pickle=False) as data:
    angles={plane:data[next(d for d in domains if d['id']==f'observation:{plane}-polar')['coordinates']['angle_deg']].copy()
            for plane in ('horizontal','vertical')}
    sphere_points=data[next(d for d in domains if d['id']=='observation:sphere')['coordinates']['points_m']].copy()

def load_bases(derived_rows=None):
    bases={p:[] for p in ('horizontal','vertical','sphere')};currents=[]
    for index,row in enumerate(manifest['results']):
        meta=json.loads(_contained(raw,row['metadata_file']).read_text());qs={q['id']:q for q in meta['quantities']}
        if derived_rows is None:path=_contained(raw,row['arrays_file'])
        else:
            dr=derived_rows[index];path=derived/dr['arrays_file']
            assert sha256(path)==dr['arrays_sha256']
            assert sha256(Path(dr['original_metadata_file']))==dr['original_metadata_sha256']
        with np.load(path,allow_pickle=False) as data:
            for plane in bases:
                name='sphere' if plane=='sphere' else f'{plane}-polar'
                bases[plane].append(data[qs[f'acoustic:pressure:{name}']['key']].copy())
            q=qs['electrical:voice-coil-current'];order=q['metadata']['component_ids']
            currents.append(data[q['key']][:,[order.index(c) for c in ids]].copy())
    return {p:np.asarray(v) for p,v in bases.items()},np.asarray(currents)

def select(bases,currents):
    bank=parallel_bank(currents,ids);winner=None;key=None;rejected=0;options=0
    assert bank['minimum_impedance_magnitude_ohm']>=obj.minimum_bank_impedance_ohm
    axis=int(np.flatnonzero(angles['horizontal']==0)[0]);hf=ids.index('component:throat');mids=[i for i in range(len(ids)) if i!=hf]
    for gain,crossover,polarity,delay in itertools.product(brief.side_gains,obj.upper_crossovers_hz,obj.mid_polarities,obj.hf_delays_s):
        settings={'side_gain':gain,'mid_highpass_hz':obj.mid_highpass_hz,'upper_crossover_hz':crossover,
            'mid_polarity':polarity,'hf_delay_s':delay,'filter':'analogue_lr4','phasor_convention':'exp(-i omega t)'}
        options+=1;weights=drive_weights(f,ids,settings)
        pressure={p:np.einsum('fea,fe->fa',b,weights) for p,b in bases.items()}
        axial=pressure['horizontal'][:,axis];terms=bases['horizontal'][:,:,axis]*weights
        handover=acoustic_handover(f,terms[:,mids].sum(axis=1),terms[:,hf],obj.mid_highpass_hz,obj.acoustic_handover_hz)
        if not handover['passed']:rejected+=1;continue
        relative=relative_response(axial)
        residual=relative-20*np.log10(abs(lr4(f,obj.mid_highpass_hz,'highpass')))
        errors=[polar_error(pressure[p],angles[p],getattr(obj,p+'_coverage_deg'))['rms_target_error_db'] for p in angles]
        errors.append(sphere_error(pressure['sphere'],axial,f,sphere_points,obj.sphere,
            obj.horizontal_coverage_deg,obj.vertical_coverage_deg)['rms_target_error_db'])
        directivity=sum(errors)/len(errors);ripple=float(np.ptp(residual))
        option={'ripple_db':ripple,'directivity_error_db':directivity,
            'acoustic_objective':ripple+obj.directivity_weight*directivity,'drive_settings':settings,
            'relative_response_db':relative.tolist(),'target_residual_db':residual.tolist(),'acoustic_handover':handover}
        next_key=(option['acoustic_objective'],gain,crossover)
        if key is None or next_key<key:key=next_key;winner=option
    return {'selected':winner,'options':options,'handover_rejections':rejected,'parallel_mid_bank':bank}

baseline=select(*load_bases())
assert baseline['selected']['drive_settings']==native_score['drive_settings']
for key in ('ripple_db','directivity_error_db','acoustic_objective'):
    assert abs(baseline['selected'][key]-native_score[key])<=1e-10
selection=select(*load_bases(report['rows']))
assert verified_assessment(project,evaluation)==native_evidence
assert sha256(native_score_path)==native_score_hash
assert all(sha256(derived/r['arrays_file'])==r['arrays_sha256'] for r in report['rows'])
result={'status':'complete','kind':'derived_commercial_circuit_diagnostic',
    'application_source_commit':'40e23d4','runner_sha256':sha256(Path(__file__)),
    'controls_sha256':sha256(controls_path),'derived_report_sha256':sha256(derived/'derived.json'),
    'original_native_score_replay_passed':True,'baseline':baseline,'replacement':selection,
    'response_screen_limit_db':6.,'response_screen_passed':selection['selected'] is not None and selection['selected']['ripple_db']<=6.,
    'native_precision':report['native_storage_dtypes'],'original_native_electrical_validation':native_evidence['checks'],
    'qualified':False,'physical_validation':False,'absolute_spl_calibrated':False,
    'limitations':['Derived fixed-geometry source comparison, not a new native candidate or search winner',
        'Complex64 native basis does not meet the unchanged 1e-8 electrical gate',
        '15 training frequencies at 20 m; no holdout, convergence or far-field qualification',
        'Provisional HF ideal outlet retains a failed PWT source screen and omits phase-plug/breakup physics',
        'Reported mids and idealised cavities; no mechanical fit, print or physical qualification']}
(derived/'diagnostic.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('status','response_screen_passed')},indent=2))
print(json.dumps(selection,indent=2))
