"""Small FP64 native workflow for versioned periodic profiles and linked mutations."""
from pathlib import Path
import argparse,json
from meh_studio.boundary_lab import BoundaryLabRuntime,sha256
from meh_studio.catalogue import Catalogue
from meh_studio.domain import DriverRevision
from meh_studio.geometry import HornGeometry
from meh_studio.optimisation import SearchBrief,candidates,optimise
from meh_studio.build_bundle import export_search
from meh_studio.search_results import load_completed_search
root=Path.cwd();prior=root/'runs/reference-backend-search'
saved_path=prior/'trial-000/candidate.json';saved=json.loads(saved_path.read_text())
data=saved['design']|{'profile_interpolation':'periodic_cubic'}
for section in data['profile_sections']:
    old=section['radial_scales']
    values=[sum(old[i] for i in group)/len(group) for group in ((0,2,4,6),(1,3,5,7))]
    section['radial_scales']=[values[i%2] for i in range(8)]
base=HornGeometry.model_validate(data);drivers=[DriverRevision.model_validate(d) for d in saved['driver_revisions']]
controls=json.loads((prior/'brief.json').read_text())
controls['evolution']['profile_symmetry']='quarter_turn';controls['acoustic_objectives']['observation_distance_m']=20.
brief=SearchBrief.model_validate(controls)
assert brief.trial_budget==2 and brief.frequencies_hz==(350.,1000.,2000.,3000.)
assert candidates(brief,base,drivers)[0]['design'].content_hash==base.content_hash
assert brief.acoustic_objectives.minimum_bank_impedance_ohm is None
provenance={'application_source_commit':'ab6714f','source_worktree':'runs/periodic-profile-source',
    'reference_candidate_sha256':sha256(saved_path),
    'seed_construction':'Each original section is explicitly averaged into cardinal and diagonal quarter-turn groups; new periodic_cubic geometry identity and new meshes',
    'observation_distance_m':20.,'backend':'coupled_reference','julia_threads':2,
    'qualification':False,'solver_stage_timeout_s':1800,
    'limitations':['Small synthetic five-driver integration case, not the user target horn',
        'Synthetic circuits retain the explicitly disabled 2-ohm screen from their reference brief',
        'Four frequencies, no mesh-convergence or physical/print qualification',
        'Geometric symmetry does not by itself prove symmetry of unstructured-mesh numerical results']}
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');args=parser.parse_args()
    (root/'runs/periodic-symmetry-controls.json').write_text(json.dumps({'brief':brief.model_dump(mode='json'),
        'base':base.model_dump(mode='json'),'provenance':provenance},indent=2)+'\n')
    if args.prepare:print(json.dumps(provenance,indent=2))
    else:
        native=root/'runs/runtime';database=root/'runs/periodic-symmetry-search.sqlite';output=root/'runs/periodic-symmetry-search'
        with Catalogue.create(database) as catalogue:
            for driver in drivers:catalogue.add(driver)
        runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',
            native/'julia-1.12.6/bin/julia','coupled_reference',julia_threads=2)
        result=optimise(brief,base,database,runtime,output,solver_stage_timeout_s=1800)
        (output/'experiment-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
        load_completed_search(output)
        bundle=export_search(output,root/'runs/periodic-symmetry-winner.zip')
        (output/'export-verification.json').write_text(json.dumps(bundle,indent=2)+'\n')
        print(json.dumps({'search':result,'export':bundle,'provenance':provenance},indent=2))
