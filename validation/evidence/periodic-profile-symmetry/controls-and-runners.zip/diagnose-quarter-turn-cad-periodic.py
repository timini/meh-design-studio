from pathlib import Path
import json
import numpy as np
from test_evolution import symmetric_inputs
from meh_studio.optimisation import candidates
from meh_studio.evolution import propose
from meh_studio.geometry import build_geometry
from meh_studio.waveguide_profile import horn_solids,cad_volume
brief,base,drivers=symmetric_inputs('quarter_turn');seeds=candidates(brief,base,drivers)
first,_=propose(brief,seeds,[],[]);offspring,_=propose(brief,seeds,[{'status':'complete','objective':10.}],[first]);design=offspring['design']
regions,parts,sources=build_geometry(design);air,outer=horn_solids(design)
records={}
for name,shape in (('unported_air',air),('front',regions['front']),('horn',parts['horn'])):
    rotated=shape.rotate((0,0,0),(0,0,1),90);ab=shape.cut(rotated);ba=rotated.cut(shape)
    box=shape.BoundingBox();rng=np.random.default_rng(57)
    pts=rng.uniform([box.xmin,box.ymin,box.zmin],[box.xmax,box.ymax,box.zmax],(400,3))
    different=[]
    for point in pts:
        a=shape.isInside(tuple(point),1e-7);b=rotated.isInside(tuple(point),1e-7)
        if a!=b:different.append(point.tolist())
    records[name]={'volume':cad_volume(design,shape),'difference':cad_volume(design,ab)+cad_volume(design,ba),
        'cut_valid':ab.isValid() and ba.isValid(),'bbox':[box.xmin,box.xmax,box.ymin,box.ymax],
        'sample_disagreements':different}
Path('runs/quarter-turn-cad-periodic.json').write_text(json.dumps({'design':design.model_dump(mode='json'),'sources':sources,'results':records},indent=2)+'\n')
print(json.dumps(records,indent=2))
