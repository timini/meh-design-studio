"""Preserve CAD seam failure, corrected geometry, native runs and motivating diagnostic."""
from pathlib import Path
import json,zipfile
from meh_studio.boundary_lab import sha256
from meh_studio.search_results import load_completed_search
root=Path.cwd();search=root/'runs/periodic-symmetry-search'
hashes,result,*_=load_completed_search(search)
validation=json.loads((root/'runs/periodic-symmetry-native-validation.json').read_text())
assert validation['search_sha256']==sha256(search/'search.json')
assert validation['controls_sha256']==sha256(root/'runs/periodic-symmetry-validation-controls.json')
old=json.loads((root/'runs/quarter-turn-cad-legacy-frozen.json').read_text());new=json.loads((root/'runs/quarter-turn-cad-periodic.json').read_text())
a=old['design'].copy();b=new['design'].copy();b.pop('profile_interpolation');assert a==b
assert all(r['cut_valid'] and r['difference']==0. and not r['sample_disagreements'] for r in new['results'].values())
export=json.loads((search/'export-verification.json').read_text());bundle=root/'runs/periodic-symmetry-winner.zip'
assert sha256(bundle)==export['sha256']
target=root/'validation/evidence/periodic-profile-symmetry';target.mkdir(parents=True,exist_ok=False)
groups={}
for label,directory in (('native-search',search),('dense-distance-baseline',root/'runs/wide-vocal-distance')):
    files=[];total=0;part=0
    for path in sorted(directory.rglob('*')):
        if not path.is_file():continue
        if total+path.stat().st_size>85_000_000 and files:
            groups[f'{label}-{part:02d}']=files;files=[];total=0;part+=1
        assert path.stat().st_size<90_000_000
        files.append((path,str(path.relative_to(root/'runs'))));total+=path.stat().st_size
    if files:groups[f'{label}-{part:02d}']=files
names=('run-periodic-symmetry-search.py','periodic-symmetry-search.log','periodic-symmetry-controls.json',
    'periodic-symmetry-validation-controls.json','check-periodic-symmetry-native.py','periodic-symmetry-native-validation.json',
    'diagnose-quarter-turn-cad.py','quarter-turn-cad-diagnostic.json','quarter-turn-cad-diagnostic.log',
    'diagnose-quarter-turn-cad-legacy-frozen.py','quarter-turn-cad-legacy-frozen.json','quarter-turn-cad-legacy-frozen.log',
    'diagnose-quarter-turn-cad-periodic.py','quarter-turn-cad-periodic.json','quarter-turn-cad-periodic.log',
    'symmetry-controls-cad-failure.log','profile-symmetry-unit-tests.log','plot-periodic-profile-seam.py','periodic-profile-seam.png',
    'prepare-wide-vocal-distance.py','project-wide-vocal-distance.py','prepare-wide-vocal-distance-analysis.py',
    'analyse-wide-vocal-distance.py','diagnose-wide-vocal-midbank.py','wide-vocal-midbank-diagnostic.json','wide-vocal-midbank-diagnostic.log',
    'finish-periodic-symmetry-study.py')
groups['controls-and-runners']=[(root/'runs'/name,name) for name in names]+[(bundle,bundle.name)]
archives=[]
for label,files in groups.items():
    path=target/(label+'.zip')
    with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for source,name in files:archive.write(source,name)
    assert path.stat().st_size<100_000_000
    with zipfile.ZipFile(path) as archive:assert archive.testzip() is None
    archives.append({'file':path.name,'sha256':sha256(path),'size_bytes':path.stat().st_size})
report={'status':'completed_periodic_profile_workflow_diagnostic','source_commits':{
    'legacy_CAD_failure':'d0e3821','periodic_CAD_and_native_search':'ab6714f',
    'dense_distance_baseline_and_midbank_decomposition':'c36e357','original_dense_raw_evidence_main':'6ca27a2'},
    'archives':archives,'native_validation':validation,'search':result,'export':export,
    'cad_comparison':{'controls_identical_except_interpolation':True,
        'legacy_extents':{k:v['bbox'] for k,v in old['results'].items()},
        'periodic_geometry':new['results'],
        'legacy_invalid_boolean_difference_volumes_are_not_error_estimates':True},
    'qualified':False,'physical_validation':False,'target_horn_design':False,
    'limitations':['Synthetic small native workflow, four frequencies, disabled 2-ohm screen, no mesh-convergence study',
        'CAD/symmetry checks do not establish commercial source accuracy, motor/cone fit or print qualification',
        'The dense 20 m baseline is a retained-trace projection of the previously failed target candidate',
        'Excitation-column cancellation includes induced motion and is not a uniquely isolated physical mechanism']}
(target/'report.json').write_text(json.dumps(report,indent=2)+'\n')
assert all(sha256(search/name)==digest for name,digest in hashes.items())
print(json.dumps({'archives':archives,'symmetry_reference_passed':validation['symmetry_reference_passed'],
    'electrical_validation_passed':validation['electrical_validation_passed']},indent=2))
