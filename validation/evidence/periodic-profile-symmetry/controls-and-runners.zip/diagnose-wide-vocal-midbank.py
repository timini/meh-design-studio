"""Decompose equal-voltage excitation contributions; not isolated diaphragm radiation."""
from pathlib import Path
import json
import numpy as np
from meh_studio.boundary_lab import sha256
from meh_studio.partial_results import verify_frequency_assembly
root=Path.cwd();source=root/'runs/wide-vocal-distance'
assembly_path=root/'runs/wide-vocal-frequency-assembly-reviewed.json'
assembly=json.loads(assembly_path.read_text());verify_frequency_assembly(assembly)
controls=json.loads((source/'controls.json').read_text());report=json.loads((source/'report.json').read_text())
assert sha256(assembly_path)==controls['assembly_sha256']
assert sha256(source/'controls.json')==report['controls_sha256']
assert report['reproduction']['passed'] and report['original_kernel_replay_passed']
assert sha256(source/'trial-000/result.npz')==report['projection_result_sha256']
trial=controls['trials'][0];ids=trial['component_ids'];mids=[i for i,c in enumerate(ids) if c!='component:throat']
assert sha256(source/'trial-000/input.npz')==trial['input_sha256']
with np.load(source/'trial-000/input.npz',allow_pickle=False) as data:
    angles=data['angles'].copy();freq=data['frequencies'].copy();count=data['original_pressure'].shape[2]
with np.load(source/'trial-000/result.npz',allow_pickle=False) as data:
    basis=data['pressure'][:,:,count:].astype(complex)
axis=np.flatnonzero(angles==0);assert len(axis)==1
terms=basis[:,mids,axis[0]]/2.83
amplitude=abs(terms);coherence=abs(terms.sum(axis=1))/amplitude.sum(axis=1)
assert np.all(coherence>0) and np.all(coherence<=1.+1e-12)
# Mutual receiving motion is retained: every driven mid basis contributes to all diaphragms.
velocity=[];currents=[]
for row in assembly['rows']:
    meta=json.loads(Path(row['metadata_file']).read_text());quantities={q['id']:q for q in meta['quantities']}
    assert meta['diagnostics']['transducer_reference_voltage_v']==2.83
    with np.load(row['arrays_file'],allow_pickle=False) as data:
        for name,target in (('mechanical:diaphragm-velocity',velocity),('electrical:voice-coil-current',currents)):
            q=quantities[name];order=q['metadata']['component_ids']
            assert set(order)==set(ids)
            target.append(data[q['key']][:,[order.index(c) for c in ids]][mids,:].sum(axis=0)/2.83)
velocity=np.asarray(velocity);currents=np.asarray(currents)
result={'status':'complete','application_source_commit':'c36e357','runner_sha256':sha256(Path(__file__)),
    'assembly_sha256':sha256(assembly_path),'projection_report_sha256':sha256(source/'report.json'),
    'frequencies_hz':freq.tolist(),'mid_component_ids':[ids[i] for i in mids],
    'normalisation':'One common mid-bank volt before DSP; HF amplifier held at zero volts; no RMS/SPL calibration',
    'contribution_definition':'Each column is the complete mutually coupled transfer from one independently excited mid voltage basis, not radiation from one isolated receiving diaphragm',
    'observation_distance_m':20.,'mid_excitation_axial_amplitude_pa_per_v':amplitude.tolist(),
    'mid_excitation_axial_phase_deg':np.angle(terms,deg=True).tolist(),
    'mid_excitation_coherent_sum_pa_per_v':abs(terms.sum(axis=1)).tolist(),
    'mid_excitation_sum_of_magnitudes_pa_per_v':amplitude.sum(axis=1).tolist(),
    'coherent_sum_relative_to_magnitude_sum_db':(20*np.log10(coherence)).tolist(),
    'receiving_component_ids':ids,'receiving_velocity_magnitude_m_s_per_v':abs(velocity).tolist(),
    'receiving_velocity_phase_deg':np.angle(velocity,deg=True).tolist(),
    'receiving_current_magnitude_a_per_v':abs(currents).tolist(),
    'qualified':False,'physical_validation':False,
    'limitations':['Excitation-column cancellation is an algebraic decomposition, not a uniquely isolated cavity or diaphragm mechanism',
        '20 m finite-distance field; no far-field, mesh or commercial source qualification',
        'Raw pre-DSP contribution magnitudes do not establish achievable output or corrective equalisation headroom']}
verify_frequency_assembly(assembly)
(root/'runs/wide-vocal-midbank-diagnostic.json').write_text(json.dumps(result,indent=2)+'\n')
for f,a,s,c in zip(freq,amplitude,abs(terms.sum(axis=1)),20*np.log10(coherence)):
    print(f'{f:5.0f} Hz: individual {a}, sum {s:.5g} Pa/V, cancellation {c:.2f} dB')
