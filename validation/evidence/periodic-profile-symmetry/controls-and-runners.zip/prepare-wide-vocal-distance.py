"""Freeze the complete assembled basis for a distance-only projection comparison."""
from pathlib import Path
import json
import numpy as np
from meh_studio.boundary_lab import sha256,_contained
from meh_studio.partial_results import verify_frequency_assembly
root=Path.cwd();path=root/'runs/wide-vocal-frequency-assembly-reviewed.json'
report=json.loads(path.read_text());verify_frequency_assembly(report)
out=root/'runs/wide-vocal-distance';out.mkdir(exist_ok=False)
project=json.loads(Path(report['project']).read_text())
assert project['project_preferences']['polar_observation_distance_m']==1.
ports={p['id']:p['component_id'] for p in project['physical_system']['excitation_ports']}
ids=[ports[p] for p in report['identity']['excitation_port_ids']]
raw=Path(report['sources'][0]['evaluation'])/'upstream';manifest=json.loads((raw/'manifest.json').read_text())
domains=json.loads(_contained(raw,manifest['domains_metadata_file']).read_text())['domains']
with np.load(_contained(raw,manifest['domains_file']),allow_pickle=False) as data:
    bem=next(d for d in domains if d['id']=='domain:bem-boundary')
    points=data[bem['coordinates']['points_m']].copy();triangles=data[bem['topology']['triangles']].copy()
    observations=[];angles=[]
    for name in ('horizontal-polar','vertical-polar','sphere'):
        d=next(d for d in domains if d['id']==f'observation:{name}')
        observations.append(data[d['coordinates']['points_m']].copy())
        if name!='sphere':angles.append(data[d['coordinates']['angle_deg']].copy())
    np.testing.assert_array_equal(*angles)
pressure=[];neumann=[];original=[];currents=[]
for row in report['rows']:
    meta=json.loads(Path(row['metadata_file']).read_text());q={q['id']:q for q in meta['quantities']}
    assert meta['diagnostics']['transducer_reference_voltage_v']==2.83
    with np.load(row['arrays_file'],allow_pickle=False) as data:
        pressure.append(data[q['acoustic:pressure:bem-boundary']['key']].copy())
        neumann.append(data[q['acoustic:normal-derivative:bem-boundary']['key']].copy())
        original.append(np.concatenate([data[q[f'acoustic:pressure:{name}']['key']] for name in ('horizontal-polar','vertical-polar','sphere')],axis=1))
        order=q['electrical:voice-coil-current']['metadata']['component_ids']
        currents.append(data[q['electrical:voice-coil-current']['key']][:,[order.index(c) for c in ids]].copy())
unit=np.vstack(observations);np.testing.assert_allclose(np.linalg.norm(unit,axis=1),1.,atol=1e-12)
directory=out/'trial-000';directory.mkdir()
np.savez_compressed(directory/'input.npz',boundary_points=points,boundary_triangles=triangles,
    boundary_pressure=pressure,boundary_neumann=neumann,original_pressure=original,currents=currents,
    observation_points=np.vstack([unit,20*unit]),sphere_points=20*observations[-1],angles=angles[0],
    frequencies=[row['frequency_hz'] for row in report['rows']])
controls={'application_source_commit':'c36e357','assembly_sha256':sha256(path),
    'original_score_sha256':sha256(root/'runs/wide-vocal-derived-score.json'),
    'observation_distance_m':20.,'pinned_boundary_lab_revision':'8cb166226e412877d3f71f2845918e479b97aa85',
    'reproduction_limits':{'magnitude_db':.05,'phase_deg':.5,'relative_null_floor':.001},
    'projection_backend':'beat_cpu','projection_precision':'float32','julia_threads':2,
    'trials':[{'index':0,'component_ids':ids,'input_sha256':sha256(directory/'input.npz')}],
    'qualified':False,'physical_validation':False,'new_coupled_solve':False,
    'limitations':['1 m reproduction must pass for all retained original observation directions before 20 m scoring',
        '20 m finite-distance projection is not far-field qualification',
        'Same source, mesh and complex64 limitations as the assembled 15-frequency diagnostic']}
(out/'controls.json').write_text(json.dumps(controls,indent=2)+'\n')
verify_frequency_assembly(report)
print('Prepared original complete 1 m and new 20 m observations for all five voltage excitations')
