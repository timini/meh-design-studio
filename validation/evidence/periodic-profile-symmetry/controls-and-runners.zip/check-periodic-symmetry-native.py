"""Check quarter-turn covariance against predeclared numerical limits."""
from pathlib import Path
import json
import numpy as np
from meh_studio.boundary_lab import sha256,_contained
from meh_studio.optimisation import verified_assessment
from meh_studio.search_results import load_completed_search
root=Path.cwd();search=root/'runs/periodic-symmetry-search'
controls_path=root/'runs/periodic-symmetry-validation-controls.json';controls=json.loads(controls_path.read_text())
hashes,search_report,*_=load_completed_search(search)
limit=controls['maximum_relative_complex_norm_error'];reports=[]

def relative(left,right):
    scale=float(np.linalg.norm(left));difference=float(np.linalg.norm(right-left))
    if scale==0:return {'reference_norm':0.,'difference_norm':difference,'relative_complex_norm_error':None,'passed':difference==0}
    error=difference/scale
    return {'reference_norm':scale,'difference_norm':difference,'relative_complex_norm_error':error,'passed':bool(np.isfinite(error) and error<=limit)}

for directory in sorted(search.glob('trial-*')):
    if not (directory/'score.json').exists():continue
    project_path=directory/'system/project.blab.json';evaluation=directory/'evaluation';raw=evaluation/'upstream'
    evidence=verified_assessment(project_path,evaluation);project=json.loads(project_path.read_text())
    geometry=json.loads((directory/'geometry/geometry.json').read_text())
    assert geometry['design']['profile_interpolation']=='periodic_cubic'
    assert geometry['design']['entry_layout']=='four_driver_ring'
    manifest=json.loads((raw/'manifest.json').read_text())
    ports={p['id']:p['component_id'] for p in project['physical_system']['excitation_ports']}
    ids=[ports[p] for p in manifest['excitation_port_ids']]
    centers={'component:'+s['id']:s['front_center_m'] for s in geometry['sources']}
    centers['component:throat']=[0.,0.,0.]
    xyz=np.array([centers[name] for name in ids]);rotated=xyz[:,[1,0,2]].copy();rotated[:,0]*=-1
    distances=np.linalg.norm(rotated[:,None,:]-xyz[None,:,:],axis=2)
    permutation=distances.argmin(axis=1);assert len(set(permutation))==len(ids)
    assert float(distances.min(axis=1).max())<1e-9
    domains=json.loads(_contained(raw,manifest['domains_metadata_file']).read_text())['domains']
    observation=[]
    with np.load(_contained(raw,manifest['domains_file']),allow_pickle=False) as arrays:
        for plane in ('horizontal','vertical'):
            domain=next(d for d in domains if d['id']==f'observation:{plane}-polar')
            observation.append(arrays[domain['coordinates']['points_m']].copy())
    points=np.vstack(observation);rotated=points[:,[1,0,2]].copy();rotated[:,0]*=-1
    distances=np.linalg.norm(rotated[:,None,:]-points[None,:,:],axis=2)
    point_permutation=distances.argmin(axis=1);point_error=float(distances.min(axis=1).max());assert point_error<1e-10
    axis=np.flatnonzero((np.linalg.norm(points[:len(observation[0]),:2],axis=1)<1e-10)&(points[:len(observation[0]),2]>0))
    assert len(axis)==1
    mids=[i for i,c in enumerate(ids) if c!='component:throat'];frequencies=[]
    for row in manifest['results']:
        metadata=json.loads(_contained(raw,row['metadata_file']).read_text());q={v['id']:v for v in metadata['quantities']}
        with np.load(_contained(raw,row['arrays_file']),allow_pickle=False) as arrays:
            pressure=np.concatenate([arrays[q[f'acoustic:pressure:{plane}-polar']['key']] for plane in ('horizontal','vertical')],axis=1).astype(complex)
            transformed=pressure[permutation][:,point_permutation]
            polar={name:relative(pressure[i],transformed[i]) for i,name in enumerate(ids)}
            terms=pressure[mids,axis[0]];mean=complex(terms.mean())
            axial={ids[i]:relative(np.array([mean]),np.array([pressure[i,axis[0]]])) for i in mids}
            matrices={}
            for name in ('mechanical:diaphragm-velocity','electrical:voice-coil-current'):
                quantity=q[name];order=quantity['metadata']['component_ids']
                matrix=arrays[quantity['key']][:,[order.index(c) for c in ids]].astype(complex)
                matrices[name]=relative(matrix,matrix[permutation][:,permutation])
        passed=all(v['passed'] for group in (polar,axial,matrices) for v in group.values())
        frequencies.append({'frequency_hz':row['freq_hz'],'polar_rotation':polar,'mid_axis_equality':axial,'matrix_rotation':matrices,'passed':passed})
    assert verified_assessment(project_path,evaluation)==evidence
    reports.append({'trial':directory.name,'component_ids':ids,'rotated_component_ids':[ids[i] for i in permutation],
        'maximum_observation_mapping_error_m':point_error,'frequencies':frequencies,
        'symmetry_reference_passed':all(f['passed'] for f in frequencies),
        'electrical_validation':evidence['checks'],'evidence_identity':evidence})
report={'status':'complete','application_source_commit':'ab6714f','runner_sha256':sha256(Path(__file__)),
    'controls_sha256':sha256(controls_path),'search_sha256':sha256(search/'search.json'),
    'trials':reports,'symmetry_reference_passed':all(t['symmetry_reference_passed'] for t in reports) and len(reports)==2,
    'electrical_validation_passed':all(t['electrical_validation']['passed'] for t in reports) and len(reports)==2,
    'qualified':False,'physical_validation':False,'limitations':controls['limitations']}
(root/'runs/periodic-symmetry-native-validation.json').write_text(json.dumps(report,indent=2)+'\n')
assert all(sha256(search/name)==digest for name,digest in hashes.items())
print(json.dumps({'symmetry_reference_passed':report['symmetry_reference_passed'],'electrical_validation_passed':report['electrical_validation_passed'],
    'trials':[{'trial':t['trial'],'passed':t['symmetry_reference_passed']} for t in reports]},indent=2))
