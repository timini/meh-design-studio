"""Visualise actual CAD edge interpolation for the same quarter-turn controls."""
from pathlib import Path
import math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from meh_studio.cad_runtime import load_cadquery
from meh_studio.waveguide_profile import periodic_profile_edge
cq=load_cadquery();root=Path.cwd()
points=[cq.Vector(50*(1. if i%2==0 else 1.1)*math.cos(i*math.pi/4),50*(1. if i%2==0 else 1.1)*math.sin(i*math.pi/4),0.) for i in range(8)]
edges=[cq.Edge.makeSpline(points,periodic=True),periodic_profile_edge(points)]
fig,axes=plt.subplots(1,2,figsize=(10,5),layout='constrained')
for ax,edge,title in zip(axes,edges,('Legacy interpolation','Uniform periodic cubic')):
    samples=np.array([edge.positionAt(float(t)).toTuple()[:2] for t in np.linspace(0,1,401)])
    rotated=samples[:,[1,0]].copy();rotated[:,0]*=-1
    ax.plot(samples[:,0],samples[:,1],label='Original edge')
    ax.plot(rotated[:,0],rotated[:,1],'--',label='Rotated 90°')
    xy=np.array([p.toTuple()[:2] for p in points]);ax.scatter(xy[:,0],xy[:,1],s=20,c='black',marker='x',label='Declared controls')
    ax.set(aspect='equal',xlabel='x (mm)',ylabel='y (mm)',title=title,xlim=(-60,60),ylim=(-60,60))
    ax.grid(alpha=.2);ax.legend(fontsize=8,loc='center')
fig.suptitle('Identical quarter-turn controls: the new CAD edge preserves symmetry')
fig.supxlabel('Actual CAD curves • geometry comparison only, no acoustic performance claim',fontsize=9)
fig.savefig(root/'runs/periodic-profile-seam.png',dpi=170)
