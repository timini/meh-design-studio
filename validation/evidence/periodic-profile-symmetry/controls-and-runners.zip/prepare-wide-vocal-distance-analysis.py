from pathlib import Path
import ast
prior=Path('runs/analyse-large-distance-bases.py').read_text();tree=ast.parse(prior)
kernel='\n\n'.join(ast.get_source_segment(prior,n) for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('score_basis','select'))
header='''"""Isolate observation-distance effects on the complete assembled voltage basis."""
from pathlib import Path
import itertools,json
import numpy as np
from meh_studio.boundary_lab import sha256
from meh_studio.partial_results import verify_frequency_assembly
from meh_studio.acoustic_objectives import AcousticObjectives,drive_weights,lr4,polar_error,parallel_bank
from meh_studio.acoustic_handover import acoustic_handover
from meh_studio.optimisation import relative_response
from meh_studio.spherical_metrics import sphere_error
root=Path.cwd();out=root/'runs/wide-vocal-distance';controls=json.loads((out/'controls.json').read_text())
assembly_path=root/'runs/wide-vocal-frequency-assembly-reviewed.json'
assembly=json.loads(assembly_path.read_text());verify_frequency_assembly(assembly)
assert sha256(assembly_path)==controls['assembly_sha256']
old_path=root/'runs/wide-vocal-derived-score.json';old=json.loads(old_path.read_text())
assert sha256(old_path)==controls['original_score_sha256']
brief=json.loads((root/'runs/wide-vocal-search/brief.json').read_text());gains=brief['side_gains']
original_objectives=AcousticObjectives.model_validate(brief['acoustic_objectives'])
new_objectives=AcousticObjectives.model_validate(original_objectives.model_dump()|{'observation_distance_m':20.})
directory=out/'trial-000';trial=controls['trials'][0];ids=trial['component_ids']
assert sha256(directory/'input.npz')==trial['input_sha256']
with np.load(directory/'input.npz',allow_pickle=False) as data:
    original=data['original_pressure'].copy();angles=data['angles'].copy();freq=data['frequencies'].copy()
    currents=data['currents'].copy();sphere=data['sphere_points'].copy()
with np.load(directory/'result.npz',allow_pickle=False) as data:
    projected=data['pressure'].copy();np.testing.assert_array_equal(data['frequencies'],freq)
count=original.shape[2];reference=projected[:,:,:count];far=projected[:,:,count:]
assert reference.shape==far.shape==original.shape
floor=controls['reproduction_limits']['relative_null_floor']
mask=(abs(original)>=floor*abs(original).max(axis=2,keepdims=True))&(abs(original)>0)
ratio=reference[mask]/original[mask]
mag=float(abs(20*np.log10(abs(ratio))).max());phase=float(abs(np.angle(ratio,deg=True)).max())
reproduction={'maximum_magnitude_change_db':mag,'maximum_phase_change_deg':phase,
    'relative_complex_norm_error':float(np.linalg.norm(reference-original)/np.linalg.norm(original)),
    'excluded_samples':int((~mask).sum()),'total_samples':int(mask.size),
    'passed':mag<=controls['reproduction_limits']['magnitude_db'] and phase<=controls['reproduction_limits']['phase_deg']}
assert reproduction['passed'],reproduction
'''
footer='''
replay=select(original,angles,freq,ids,original_objectives,sphere/20)
assert replay['selected']['drive_settings']==old['selection']['selected']['drive_settings']
assert replay['handover_rejections']==old['selection']['handover_rejections']
for key in ('ripple_db','directivity_error_db','acoustic_objective'):
    np.testing.assert_allclose(replay['selected'][key],old['selection']['selected'][key],rtol=0,atol=1e-10)
fixed=score_basis(far,angles,freq,ids,new_objectives,replay['selected']['drive_settings'],sphere)
selection=select(far,angles,freq,ids,new_objectives,sphere)
bank=parallel_bank(currents,ids);assert bank['minimum_impedance_magnitude_ohm']>=2.
verify_frequency_assembly(assembly)
result={'status':'complete','kind':'derived_frequency_distance_diagnostic',
    'application_source_commit':'c36e357','controls_sha256':sha256(out/'controls.json'),
    'runner_sha256':sha256(Path(__file__)),'projection_result_sha256':sha256(directory/'result.npz'),
    'reproduction':reproduction,'original_kernel_replay_passed':True,'frequencies_hz':freq.tolist(),
    'original_1m_selection':replay,'20m_fixed_dsp':fixed,'20m_selection':selection,
    'parallel_mid_bank':bank,'original_evaluations_modified':False,'new_coupled_solve':False,
    'qualified':False,'physical_validation':False,'far_field_qualified':False,
    'limitations':controls['limitations']}
(out/'report.json').write_text(json.dumps(result,indent=2)+'\\n')
print(json.dumps(result,indent=2))
'''
Path('runs/analyse-wide-vocal-distance.py').write_text(header+'\n'+kernel+'\n'+footer)
