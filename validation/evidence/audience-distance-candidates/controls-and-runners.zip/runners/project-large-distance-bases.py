"""Project each retained native excitation independently with pinned BEM code."""
from pathlib import Path
import hashlib,json,subprocess,time
import numpy as np
import blab.solvers.coupled_field as field
from blab.solvers.beat_engine_backend import shutdown_julia_workers
root=Path.cwd();out=root/'runs/large-distance-bases';controls=json.loads((out/'controls.json').read_text())
checkout=root/'runs/runtime/boundary-lab'
assert subprocess.check_output(['git','-C',str(checkout),'rev-parse','HEAD'],text=True).strip()==controls['pinned_boundary_lab_revision']
assert not subprocess.check_output(['git','-C',str(checkout),'status','--porcelain','--untracked-files=no'],text=True).strip()
get_worker=field._get_julia_worker
field._get_julia_worker=lambda **kwargs:get_worker(**(kwargs|{'julia_threads':2}))
started=time.time()
try:
    for trial in controls['trials']:
        directory=out/f'trial-{trial["index"]:03d}'
        assert hashlib.sha256((directory/'input.npz').read_bytes()).hexdigest()==trial['input_sha256']
        with np.load(directory/'input.npz',allow_pickle=False) as data:
            results=[]
            for i,freq in enumerate(data['frequencies']):
                basis=[]
                for source in range(len(trial['component_ids'])):
                    request=field.BemFieldEvaluationRequest(domain_key=trial['input_sha256'],points_m=data['observation_points'],
                        boundary_points_m=data['boundary_points'],boundary_triangles=data['boundary_triangles'],
                        boundary_pressure=data['boundary_pressure'][i,source],boundary_normal_derivative=data['boundary_neumann'][i,source],
                        frequency_hz=float(freq),sound_speed_m_per_s=343.,symmetry='off')
                    basis.append(field.evaluate_bem_field(request,backend_id='beat_cpu',
                        julia_executable=str(root/'runs/runtime/julia-1.12.6/bin/julia')))
                results.append(basis)
                np.savez_compressed(directory/f'frequency-{i:03d}.npz',pressure=np.asarray(basis),frequency_hz=freq)
                print(json.dumps({'trial':trial['index'],'frequency_hz':float(freq),'elapsed_s':time.time()-started}),flush=True)
            np.savez_compressed(directory/'result.npz',pressure=np.asarray(results),frequencies=data['frequencies'])
        assert hashlib.sha256((directory/'input.npz').read_bytes()).hexdigest()==trial['input_sha256']
finally:shutdown_julia_workers()
