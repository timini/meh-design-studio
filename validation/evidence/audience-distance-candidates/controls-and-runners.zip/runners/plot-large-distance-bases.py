from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path.cwd();out=root/'runs/large-distance-bases';report=json.loads((out/'report.json').read_text())
fig,axes=plt.subplots(1,3,figsize=(12,4.3),layout='constrained',sharey=True)
frequencies=[350,700,1200,2000,3000,4000,5000,7500]
for ax,trial in zip(axes,report['trials']):
    original=trial['20m_original_dsp'];selected=trial['20m_handover_constrained_selection']['selected']
    for label,value in [('Historical DSP',original),('Handover constrained DSP',selected)]:
        if value is None:continue
        residual=np.asarray(value['target_residual_db']);residual-=residual.max()
        ax.semilogx(frequencies,residual,marker='o',ms=3,label=label)
    ax.axhline(-6.,color='grey',ls=':',label='6 dB screening range')
    ax.set(title=f"Candidate {trial['trial_index']}",xlabel='Frequency (Hz)',ylim=(-26,1))
    ax.set_xticks([350,1000,3000,7500],labels=['350','1000','3000','7500']);ax.minorticks_off();ax.grid(alpha=.25)
axes[0].set_ylabel('Residual after 350 Hz high-pass target (dB)')
axes[0].legend(fontsize=8)
fig.suptitle('Three existing horn candidates evaluated at 20 metres\nReported mids + synthetic HF; eight frequency samples; no physical qualification',fontsize=11)
fig.savefig(out/'candidate-comparison.png',dpi=150)
