"""Prepare immutable full driver bases for three completed large candidates."""
from pathlib import Path
import json
import numpy as np
from meh_studio.boundary_lab import sha256,_read_json,_contained
from meh_studio.optimisation import verified_assessment,SearchBrief
from meh_studio.spherical_metrics import fibonacci_directions
root=Path.cwd();search=root/'runs/larger-wide-mid-32k';output=root/'runs/large-distance-bases'
output.mkdir(exist_ok=False)
brief=SearchBrief.model_validate(_read_json(search/'brief.json'))
control={'application_source_commit':'b13c176','native_source_commit':'a0a604e',
    'native_evidence_commit':'e1696b3c963a44c6f36eb822adee71e99aef58ad',
    'native_search':str(search),'native_search_sha256':sha256(search/'search.json'),
    'original_brief':brief.model_dump(mode='json'),'observation_distance_m':20.,
    'acoustic_handover_hz':[3000.,5000.],'sphere_angle_precision_deg':10.,
    'projection_backend':'beat_cpu','projection_precision':'float32','julia_threads':2,
    'pinned_boundary_lab_revision':'8cb166226e412877d3f71f2845918e479b97aa85',
    'reproduction_limits':{'magnitude_db':.05,'phase_deg':.5,'relative_null_floor':.001},
    'qualification':False,'trials':[],
    'limitations':['Reanalysis of existing unconverged eight-frequency candidates; not a fresh shape search or frequency holdout',
        'Reported mid circuits and synthetic HF; no physical source qualification',
        '20 m finite-distance pressure; the previous 20-to-40 m stability test remains failed',
        'Original electrical consistency remains failed due to complex64 native storage',
        'No measured SPL, power handling, commercial mount or print qualification']}
for index in (0,2,7):
    trial=search/f'trial-{index:03d}';evaluation=trial/'evaluation';raw=evaluation/'upstream'
    identity=verified_assessment(trial/'system/project.blab.json',evaluation)
    project=_read_json(trial/'system/project.blab.json');manifest=_read_json(raw/'manifest.json')
    assert manifest['phasor_convention']=='exp(-i omega t)'
    assert project['project_preferences']['polar_observation_distance_m']==1.
    ports={p['id']:p['component_id'] for p in project['physical_system']['excitation_ports']}
    ids=[ports[p] for p in manifest['excitation_port_ids']]
    domains=_read_json(_contained(raw,manifest['domains_metadata_file']))['domains']
    with np.load(_contained(raw,manifest['domains_file']),allow_pickle=False) as data:
        bem=next(d for d in domains if d['id']=='domain:bem-boundary')
        points=data[bem['coordinates']['points_m']].copy();triangles=data[bem['topology']['triangles']].copy()
        polars=[]
        for plane in ('horizontal','vertical'):
            d=next(d for d in domains if d['id']==f'observation:{plane}-polar')
            polars.append(data[d['coordinates']['points_m']].copy())
            angles=data[d['coordinates']['angle_deg']].copy()
    pressure=[];neumann=[];original=[];currents=[]
    for row in manifest['results']:
        meta=_read_json(_contained(raw,row['metadata_file']));q={q['id']:q for q in meta['quantities']}
        assert meta['diagnostics']['transducer_reference_voltage_v']==2.83
        with np.load(_contained(raw,row['arrays_file']),allow_pickle=False) as data:
            pressure.append(data[q['acoustic:pressure:bem-boundary']['key']].copy())
            neumann.append(data[q['acoustic:normal-derivative:bem-boundary']['key']].copy())
            original.append(np.concatenate([data[q[f'acoustic:pressure:{plane}-polar']['key']]
                                           for plane in ('horizontal','vertical')],axis=1))
            ordered=q['electrical:voice-coil-current']['metadata']['component_ids']
            currents.append(data[q['electrical:voice-coil-current']['key']][:,[ordered.index(c) for c in ids]].copy())
    destination=output/f'trial-{index:03d}';destination.mkdir()
    unit_points=np.vstack(polars);sphere=20*fibonacci_directions(413)
    np.savez_compressed(destination/'input.npz',boundary_points=points,boundary_triangles=triangles,
        boundary_pressure=pressure,boundary_neumann=neumann,original_pressure=original,currents=currents,
        observation_points=np.vstack([unit_points,20*unit_points,sphere]),sphere_points=sphere,
        angles=angles,frequencies=[r['freq_hz'] for r in manifest['results']])
    control['trials'].append({'index':index,'component_ids':ids,'input_sha256':sha256(destination/'input.npz'),
        'evidence_identity':identity,'original_score':_read_json(trial/'score.json'),
        'candidate_sha256':sha256(trial/'candidate.json')})
    assert verified_assessment(trial/'system/project.blab.json',evaluation)==identity
(output/'controls.json').write_text(json.dumps(control,indent=2)+'\n')
print('Prepared three unchanged native full driver bases')
