"""Archive full-basis audience-distance reanalysis with its unchanged failures."""
from pathlib import Path
import json,zipfile
from meh_studio.boundary_lab import sha256
root=Path.cwd();source=root/'runs/large-distance-bases'
report=json.loads((source/'report.json').read_text());controls=json.loads((source/'controls.json').read_text())
assert sha256(source/'controls.json')==report['controls_sha256']
for trial,record in zip(controls['trials'],report['trials']):
    assert trial['index']==record['trial_index']
    directory=source/f'trial-{trial["index"]:03d}'
    assert sha256(directory/'input.npz')==trial['input_sha256']
    assert sha256(directory/'result.npz')==record['projection_result_sha256']
    assert record['reproduction']['passed'] and record['original_kernel_replay_passed']
    assert record['20m_handover_constrained_selection']['selected']['ripple_db']>6.
target=root/'validation/evidence/audience-distance-candidates';target.mkdir(parents=True,exist_ok=False)
groups={p.name:[(f,str(f.relative_to(source))) for f in sorted(p.rglob('*')) if f.is_file()]
        for p in sorted(source.iterdir()) if p.is_dir()}
groups['controls-and-runners']=[(p,p.name) for p in sorted(source.iterdir()) if p.is_file()]
for name in ('prepare-large-distance-bases.py','project-large-distance-bases.py','analyse-large-distance-bases.py',
             'plot-large-distance-bases.py','finish-large-distance-bases.py'):
    groups['controls-and-runners'].append((root/'runs'/name,'runners/'+name))
archives=[]
for name,files in groups.items():
    path=target/(name+'.zip')
    with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for original,relative in files:archive.write(original,relative)
    assert path.stat().st_size<100_000_000
    with zipfile.ZipFile(path) as archive:assert archive.testzip() is None
    archives.append({'file':path.name,'sha256':sha256(path),'size_bytes':path.stat().st_size})
(target/'report.json').write_text(json.dumps(report|{'archives':archives,'source_provenance':{
    k:controls[k] for k in ('application_source_commit','native_source_commit','native_evidence_commit','pinned_boundary_lab_revision')},
    'minimum_response_ripple_db':min(t['20m_handover_constrained_selection']['selected']['ripple_db'] for t in report['trials']),
    'response_screen_limit_db':6.,'any_candidate_passes_response_screen':False},indent=2)+'\n')
print(json.dumps(archives,indent=2))
