"""Compare projected driver bases with frozen and reselected acoustic handover DSP.

The diagnostic kernel mirrors the existing objective using its tested primitives;
first it must reproduce every original score from the original native arrays.
"""
from pathlib import Path
import itertools,json
import numpy as np
from meh_studio.boundary_lab import sha256
from meh_studio.search_results import load_completed_search
from meh_studio.acoustic_objectives import AcousticObjectives,drive_weights,lr4,polar_error,parallel_bank
from meh_studio.acoustic_handover import acoustic_handover
from meh_studio.optimisation import relative_response
from meh_studio.spherical_metrics import sphere_error
root=Path.cwd();out=root/'runs/large-distance-bases';controls=json.loads((out/'controls.json').read_text())
search=Path(controls['native_search']);hashes,*_=load_completed_search(search)
assert sha256(search/'search.json')==controls['native_search_sha256']
original_objectives=AcousticObjectives.model_validate(controls['original_brief']['acoustic_objectives'])
new_objectives=AcousticObjectives.model_validate(original_objectives.model_dump()|{
    'observation_distance_m':20.,'acoustic_handover_hz':[3000.,5000.],'sphere':{}})
gains=controls['original_brief']['side_gains']

def score_basis(basis,angles,freq,ids,objectives,settings,sphere_points=None):
    count=len(angles);axis=int(np.flatnonzero(angles==0)[0])
    weights=drive_weights(freq,ids,settings)
    pressure=np.einsum('fea,fe->fa',basis,weights)
    axial=pressure[:,axis]
    relative=relative_response(axial)
    residual=relative-20*np.log10(abs(lr4(freq,objectives.mid_highpass_hz,'highpass')))
    errors=[polar_error(pressure[:,j*count:(j+1)*count],angles,getattr(objectives,plane+'_coverage_deg'))['rms_target_error_db']
            for j,plane in enumerate(('horizontal','vertical'))]
    if objectives.sphere is not None:
        errors.append(sphere_error(pressure[:,2*count:],axial,freq,sphere_points,objectives.sphere,
                      objectives.horizontal_coverage_deg,objectives.vertical_coverage_deg)['rms_target_error_db'])
    directivity=sum(errors)/len(errors);ripple=float(np.ptp(residual))
    terms=basis[:,:,axis]*weights;hf=ids.index('component:throat');mids=[i for i in range(len(ids)) if i!=hf]
    handover=acoustic_handover(freq,terms[:,mids].sum(axis=1),terms[:,hf],350.,(3000.,5000.))
    return {'ripple_db':ripple,'directivity_error_db':directivity,
        'acoustic_objective':ripple+objectives.directivity_weight*directivity,
        'drive_settings':settings,'relative_response_db':relative.tolist(),
        'target_residual_db':residual.tolist(),'acoustic_handover':handover}

def select(basis,angles,freq,ids,objectives,sphere_points=None):
    winner=None;key=None;rejected=0;options=0
    for gain,crossover,polarity,delay in itertools.product(gains,objectives.upper_crossovers_hz,
                                                       objectives.mid_polarities,objectives.hf_delays_s):
        settings={'side_gain':gain,'mid_highpass_hz':objectives.mid_highpass_hz,
            'upper_crossover_hz':crossover,'mid_polarity':polarity,'hf_delay_s':delay,
            'filter':'analogue_lr4','phasor_convention':'exp(-i omega t)'}
        options+=1
        score=score_basis(basis,angles,freq,ids,objectives,settings,sphere_points)
        if objectives.acoustic_handover_hz is not None and not score['acoustic_handover']['passed']:
            rejected+=1;continue
        next_key=(score['acoustic_objective'],gain,crossover)
        if key is None or next_key<key:key=next_key;winner=score
    return {'selected':winner,'handover_rejections':rejected,'options':options}

reports=[]
for trial in controls['trials']:
    directory=out/f'trial-{trial["index"]:03d}'
    assert sha256(directory/'input.npz')==trial['input_sha256']
    with np.load(directory/'input.npz',allow_pickle=False) as data:
        original=data['original_pressure'].copy();angles=data['angles'].copy();freq=data['frequencies'].copy()
        currents=data['currents'].copy();sphere_points=data['sphere_points'].copy()
    with np.load(directory/'result.npz',allow_pickle=False) as data:projected=data['pressure'].copy()
    count=len(angles);reference=projected[:,:,:2*count]
    floor=controls['reproduction_limits']['relative_null_floor']
    mask=abs(original)>=floor*abs(original).max(axis=2)[:,:,None]
    ratio=reference[mask]/original[mask]
    mag=float(abs(20*np.log10(abs(ratio))).max());phase=float(abs(np.angle(ratio,deg=True)).max())
    reproduced={'maximum_magnitude_change_db':mag,'maximum_phase_change_deg':phase,
        'excluded_samples':int((~mask).sum()),'total_samples':int(mask.size),
        'passed':mag<=.05 and phase<=.5}
    assert reproduced['passed'],reproduced
    ids=trial['component_ids'];old=trial['original_score']
    original_selection=select(original,angles,freq,ids,original_objectives)
    check=original_selection['selected']
    assert check['drive_settings']==old['drive_settings']
    for key in ('ripple_db','directivity_error_db','acoustic_objective'):
        np.testing.assert_allclose(check[key],old[key],rtol=0,atol=1e-10)
    far=projected[:,:,2*count:]
    original_dsp=score_basis(far,angles,freq,ids,new_objectives,old['drive_settings'],sphere_points)
    constrained=select(far,angles,freq,ids,new_objectives,sphere_points)
    bank=parallel_bank(currents,ids)
    assert bank['minimum_impedance_magnitude_ohm']>=new_objectives.minimum_bank_impedance_ohm
    selected=constrained['selected']
    if selected is not None:
        selected['objective']=selected['acoustic_objective']+old['objective']-old['acoustic_objective']
    reports.append({'trial_index':trial['index'],'reproduction':reproduced,'original_kernel_replay_passed':True,
        'original_1m_score':{k:old[k] for k in ('ripple_db','directivity_error_db','acoustic_objective','drive_settings','objective','build_cost')},
        '20m_original_dsp':original_dsp,'20m_handover_constrained_selection':constrained,
        'parallel_mid_bank':bank,'projection_result_sha256':sha256(directory/'result.npz')})
report={'status':'complete','controls_sha256':sha256(out/'controls.json'),
    'new_acoustic_objectives':new_objectives.model_dump(mode='json'),'trials':reports,
    'physical_validation':False,'qualified':False,'new_native_coupled_solve':False,
    'original_search_changed':False,'limitations':controls['limitations']}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
assert all(sha256(search/name)==digest for name,digest in hashes.items())
for trial in reports:
    selected=trial['20m_handover_constrained_selection']['selected']
    print(json.dumps({'trial':trial['trial_index'],'reproduction':trial['reproduction'],
        '1m_ripple_db':trial['original_1m_score']['ripple_db'],
        '20m_original_dsp_ripple_db':trial['20m_original_dsp']['ripple_db'],
        '20m_constrained':selected,'handover_rejections':trial['20m_handover_constrained_selection']['handover_rejections']},indent=2))
