"""Check stricter rim classification against unchanged final geometric limits."""
from pathlib import Path
import json
from meh_studio.boundary_lab import sha256
from meh_studio.interface_coordinates import restore_fem_interface_coordinates
from meh_studio.radiation_geometry import surface_integrity,verify_exterior_groups
root=Path.cwd();runs=root/'runs';out=runs/'quarter-rim-classification';trial=runs/'quarter-commercial-isolated-search/trial-000'
controls=json.loads((out/'controls.json').read_text());report=json.loads((out/'report.json').read_text())
assert report['status']=='complete'
assert sha256(out/'controls.json')==report['controls_sha256']
assert sha256(out/'exterior-conformed-raw.msh')==report['output_sha256']
front=trial/'system/meshes/front.msh';assert sha256(front)==controls['inputs_sha256']['front']
restore=restore_fem_interface_coordinates(out/'exterior-conformed-raw.msh',front,out/'exterior.msh')
verify_exterior_groups(out/'exterior.msh',front)
integrity=surface_integrity(out/'exterior.msh',symmetry='xy',maximum_triangles=controls['maximum_final_native_triangles'])
cad=json.loads((trial/'system/exterior/exterior.json').read_text());error=abs(integrity['enclosed_volume_m3']/cad['cad_volume_m3']-1)
assert error<=controls['unchanged_exterior_volume_relative_limit']
result={'status':'complete','runner_sha256':sha256(Path(__file__)),'source_commit':'4dadcfdeb8ede70f3723db5ab60a72a61bbc8961',
 'controls_sha256':sha256(out/'controls.json'),'conform_report_sha256':sha256(out/'report.json'),
 'coordinate_restoration':restore,'surface':integrity,'relative_CAD_volume_error':error,
 'exact_FEM_BEM_mouth_facets_verified':True,'native_frequency_solve_executed':False,'qualified':False}
(out/'final-check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'complete','triangles':integrity['triangles'],'relative_volume_error':error},indent=2))
