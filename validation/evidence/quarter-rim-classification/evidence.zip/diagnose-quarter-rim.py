"""Test a topology-derived stricter tolerance on the retained quarter mouth."""
from pathlib import Path
from collections import Counter
import json,hashlib,importlib.util,dataclasses
import numpy as np
import meshio
from blab.interface_conform import conform_bem_interface_to_fem
root=Path.cwd();runs=root/'runs';trial=runs/'quarter-commercial-isolated-search/trial-000'
out=runs/'quarter-rim-classification';out.mkdir(exist_ok=False)
helper=runs/'isolated-preparation-source/src/meh_studio/native_mouth_conform.py'
spec=importlib.util.spec_from_file_location('retained_conformer',helper);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
front=trial/'system/meshes/front.msh';exterior=trial/'system/exterior/exterior.msh'
inputs={'front':digest(front),'exterior':digest(exterior),'helper':digest(helper),
 'original_failed_report':digest(trial/'system/conform-interface.json'),'runner':digest(Path(__file__))}
fem=meshio.read(front);bem=meshio.read(exterior)
name,protected_tag,rigid,before,classification=module.protect_curved_walls(fem,bem,.3)
faces,tags=module.triangles(bem);mouth=int(bem.field_data['mouth_interface'][0])
def boundary_edges(f):
 c=Counter(tuple(sorted((int(a),int(b)))) for tri in f for a,b in zip(tri,np.roll(tri,-1)))
 assert all(n<=2 for n in c.values())
 return {edge for edge,count in c.items() if count==1}
opening_boundary=boundary_edges(faces[tags==mouth]);rim_boundary=boundary_edges(faces[tags==rigid])
shared=opening_boundary & rim_boundary;other=rim_boundary-shared
assert shared and other
edges=np.array(sorted(shared));points=bem.points[edges];a=points[:,0];delta=points[:,1]-a
midpoints=bem.points[np.array(sorted(other))].mean(axis=1)
distances=[]
for p in midpoints:
 t=np.clip(np.einsum('ij,ij->i',p-a,delta)/np.einsum('ij,ij->i',delta,delta),0.,1.)
 distances.append(float(np.linalg.norm(p-(a+t[:,None]*delta),axis=1).min()))
separation=min(distances);assert separation>0
ftag=int(fem.field_data['mouth_interface'][0]);fi=np.concatenate([c.data[np.asarray(t)==ftag] for c,t in zip(fem.cells,fem.cell_data['gmsh:physical']) if c.type=='triangle'])
diameter=float(np.linalg.norm(np.ptp(fem.points[np.unique(fi)],axis=0)))
default=max(diameter*5e-3,1e-9);tolerance=min(default,separation/2)
controls={'inputs_sha256':inputs,'rule':'min(upstream default, half minimum midpoint distance of non-opening rim boundary edges to the topologically shared mouth/rim opening)',
 'default_geometry_tolerance_m':default,'minimum_nonopening_midpoint_distance_m':separation,
 'selected_geometry_tolerance_m':tolerance,'shared_opening_edges':len(shared),'other_rim_boundary_edges':len(other),
 'unchanged_merge_tolerance_m':1e-8,'unchanged_restored_interface_tolerance_m':1e-8,
 'unchanged_exterior_volume_relative_limit':.02,'maximum_final_native_triangles':10000,
 'native_frequency_solve_executed':False,'qualified':False}
(out/'controls.json').write_text(json.dumps(controls,indent=2)+'\n')
report={'status':'running','controls_sha256':digest(out/'controls.json')}
try:
 result,identity=conform_bem_interface_to_fem(fem,bem,fem_interface_name='mouth_interface',
  bem_interface_name='mouth_interface',protected_bem_interface_names=(name,),symmetry_mode='xy',geometry_tolerance=tolerance)
 result_faces,result_tags=module.triangles(result)
 assert module.oriented_facets(result.points[result_faces[result_tags==protected_tag]])==before
 for physical in result.cell_data['gmsh:physical']:physical[physical==protected_tag]=rigid
 del result.field_data[name]
 output=out/'exterior-conformed-raw.msh';meshio.write(output,result,file_format='gmsh22',binary=False,float_fmt='.17e')
 assert inputs=={'front':digest(front),'exterior':digest(exterior),'helper':digest(helper),
  'original_failed_report':digest(trial/'system/conform-interface.json'),'runner':digest(Path(__file__))}
 report.update(status='complete',result=dataclasses.asdict(identity),protected_facets_unchanged=True,
  output_sha256=digest(output),original_inputs_unchanged=True)
except BaseException as e:
 report.update(status='failed',error=f'{type(e).__name__}: {e}');raise
finally:(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'default':default,'selected':tolerance,'minimum_separation':separation,
 'triangles':len(result_faces)},indent=2))
