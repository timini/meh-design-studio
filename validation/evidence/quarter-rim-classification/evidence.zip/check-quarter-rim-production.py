"""Check the production adapter on retained thin-rim, quarter and full inputs."""
from pathlib import Path
import json,subprocess
from meh_studio.boundary_lab import BoundaryLabRuntime,sha256
from meh_studio.radiating_system import conform_mouth_interface
from meh_studio.interface_coordinates import restore_fem_interface_coordinates
from meh_studio.radiation_geometry import surface_integrity,verify_exterior_groups
root=Path.cwd();runs=root/'runs';source=runs/'quarter-rim-source'
commit=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
assert commit.startswith('188a933') and not subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True)
paths={'thin-quarter':runs/'quarter-commercial-isolated-search/trial-000/system',
 'original-quarter':runs/'isolated-preparation-reference/system','original-full':runs/'tilted-entry-10mm/trial-000/system'}
controls={'source_commit':commit,'runner_sha256':sha256(Path(__file__)),'inputs':{},
 'native_frequency_solve_executed':False,'qualified':False}
for label,path in paths.items():
 names=['meshes/front.msh','exterior/exterior.msh','exterior/exterior.json']
 if label!='thin-quarter':names+=['meshes/exterior-conformed-raw.msh']
 controls['inputs'][label]={name:sha256(path/name) for name in names}
out=runs/'quarter-rim-production';out.mkdir(exist_ok=False)
(out/'controls.json').write_text(json.dumps(controls,indent=2)+'\n')
native=runs/'runtime';runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',native/'julia-1.12.6/bin/julia','coupled_reference',julia_threads=2)
report={'status':'running','controls_sha256':sha256(out/'controls.json'),'rows':[]}
try:
 for label,path in paths.items():
  directory=out/label;directory.mkdir()
  mode='off' if label=='original-full' else 'xy';z=.3 if label=='thin-quarter' else .25
  raw=directory/'exterior-raw.msh';front=path/'meshes/front.msh'
  result=conform_mouth_interface(runtime,front,path/'exterior/exterior.msh',raw,directory/'conform.json',z,600,symmetry=mode)
  restore=restore_fem_interface_coordinates(raw,front,directory/'exterior.msh')
  verify_exterior_groups(directory/'exterior.msh',front)
  integrity=surface_integrity(directory/'exterior.msh',maximum_triangles=10000,symmetry=mode)
  cad=json.loads((path/'exterior/exterior.json').read_text());error=abs(integrity['enclosed_volume_m3']/cad['cad_volume_m3']-1)
  assert error<=.02
  previous_identical=None
  if label!='thin-quarter':
   previous_identical=sha256(raw)==sha256(path/'meshes/exterior-conformed-raw.msh')
   assert previous_identical
  report['rows'].append({'case':label,'conforming':result,'restoration':restore,'surface':integrity,
   'relative_volume_error':error,'previous_raw_output_byte_identical':previous_identical})
 assert controls['inputs']=={label:{name:sha256(paths[label]/name) for name in names} for label,names in controls['inputs'].items()}
 report['status']='complete'
except BaseException as e:
 report.update(status='failed',error=f'{type(e).__name__}: {e}');raise
finally:(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'rows':[{'case':r['case'],'triangles':r['surface']['triangles'],'previous_output_identical':r['previous_raw_output_byte_identical']} for r in report['rows']]},indent=2))
