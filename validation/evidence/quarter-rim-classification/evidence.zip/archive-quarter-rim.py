"""Preserve the failed thin-rim inputs and three production conformer checks."""
from pathlib import Path
import json,hashlib,zipfile
root=Path.cwd();runs=root/'runs'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
production=runs/'quarter-rim-production'; controls=json.loads((production/'controls.json').read_text());result=json.loads((production/'report.json').read_text())
assert result['status']=='complete' and len(result['rows'])==3
assert all(r['previous_raw_output_byte_identical'] is True for r in result['rows'][1:])
inputs={'thin-quarter':runs/'quarter-commercial-isolated-search/trial-000/system','original-quarter':runs/'isolated-preparation-reference/system','original-full':runs/'tilted-entry-10mm/trial-000/system'}
paths=[p for folder in (production,runs/'quarter-rim-classification') for p in folder.rglob('*') if p.is_file()]
for label,names in controls['inputs'].items():
 for name,sha in names.items():
  p=inputs[label]/name;assert digest(p)==sha;paths.append(p)
paths += [inputs['thin-quarter']/name for name in ['conform-interface.log','conform-interface.json']]
paths += [runs/name for name in ['diagnose-quarter-rim.py','check-quarter-rim-result.py','check-quarter-rim-production.py','quarter-rim-classification.log','quarter-rim-final-check.log','quarter-rim-production.log','quarter-rim-noncad.log','archive-quarter-rim.py']]
paths=sorted(set(paths));identities={p.relative_to(runs).as_posix():digest(p) for p in paths}
out=root/'validation/evidence/quarter-rim-classification';out.mkdir(exist_ok=False)
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in paths:z.write(p,p.relative_to(runs).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,sha in identities.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha
assert identities=={p.relative_to(runs).as_posix():digest(p) for p in paths}
assert archive.stat().st_size<100_000_000
report={'status':'complete','source_commit':controls['source_commit'],'production_regressions':result,
 'archives':[{'file':'evidence.zip','size_bytes':archive.stat().st_size,'sha256':digest(archive)}],
 'archived_file_sha256':identities,'qualified':False,'native_frequency_solve_executed':False,
 'limitations':['Native interface preparation checks only; no acoustic frequency solve or physical qualification.',
 'The new commercial search is separate and is not included while running.']}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'archives':report['archives'],'files':len(paths)},indent=2))
