"""Freeze the previously replay-checked diagnostic scoring kernel in a new runner."""
from pathlib import Path
import ast
prior=Path('runs/analyse-large-distance-bases.py')
source=prior.read_text();tree=ast.parse(source)
kernel='\n\n'.join(ast.get_source_segment(source,node) for node in tree.body
    if isinstance(node,ast.FunctionDef) and node.name in ('score_basis','select'))
header='''"""Score an explicit derived frequency assembly; never promote the cancelled search."""
from pathlib import Path
import itertools,json
import numpy as np
from meh_studio.boundary_lab import sha256,_contained
from meh_studio.partial_results import verify_frequency_assembly
from meh_studio.acoustic_objectives import AcousticObjectives,drive_weights,lr4,polar_error,parallel_bank,verify_observation_distance
from meh_studio.acoustic_handover import acoustic_handover
from meh_studio.optimisation import relative_response
from meh_studio.spherical_metrics import sphere_error
root=Path.cwd()
assembly_path=root/'runs/wide-vocal-frequency-assembly-reviewed.json'
assembly=json.loads(assembly_path.read_text())
verify_frequency_assembly(assembly)
brief_path=root/'runs/wide-vocal-search/brief.json'
brief=json.loads(brief_path.read_text())
objectives=AcousticObjectives.model_validate(brief['acoustic_objectives'])
gains=brief['side_gains']
project=Path(assembly['project']);verify_observation_distance(project,objectives)
project_data=json.loads(project.read_text())
ports={p['id']:p['component_id'] for p in project_data['physical_system']['excitation_ports']}
ids=[ports[p] for p in assembly['identity']['excitation_port_ids']]
native=Path(assembly['sources'][0]['evaluation'])/'upstream'
manifest=json.loads((native/'manifest.json').read_text())
assert manifest['phasor_convention']=='exp(-i omega t)'
domains=json.loads(_contained(native,manifest['domains_metadata_file']).read_text())['domains']
with np.load(_contained(native,manifest['domains_file']),allow_pickle=False) as data:
    angle_sets=[]
    for plane in ('horizontal','vertical'):
        domain=next(d for d in domains if d['id']==f'observation:{plane}-polar')
        angle_sets.append(data[domain['coordinates']['angle_deg']].copy())
    np.testing.assert_array_equal(*angle_sets)
    angles=angle_sets[0]
    domain=next(d for d in domains if d['id']=='observation:sphere')
    sphere_points=data[domain['coordinates']['points_m']].copy()
freq=np.array([row['frequency_hz'] for row in assembly['rows']])
assert freq.tolist()==brief['frequencies_hz']
basis=[];currents=[]
for row in assembly['rows']:
    metadata=json.loads(Path(row['metadata_file']).read_text())
    assert metadata['diagnostics']['transducer_reference_voltage_v']==2.83
    quantities={q['id']:q for q in metadata['quantities']}
    with np.load(row['arrays_file'],allow_pickle=False) as data:
        basis.append(np.concatenate([data[quantities[f'acoustic:pressure:{name}']['key']]
            for name in ('horizontal-polar','vertical-polar','sphere')],axis=1))
        q=quantities['electrical:voice-coil-current'];order=q['metadata']['component_ids']
        assert set(order)==set(ids)
        currents.append(data[q['key']][:,[order.index(c) for c in ids]].copy())
basis=np.asarray(basis);currents=np.asarray(currents)
'''
footer='''
bank=parallel_bank(currents,ids)
assert bank['minimum_impedance_magnitude_ohm']>=objectives.minimum_bank_impedance_ohm
selection=select(basis,angles,freq,ids,objectives,sphere_points)
original=json.loads((root/'runs/larger-wide-mid-32k/trial-007/score.json').read_text())
# The diagnostic also reports the historical setting, without treating it as feasible.
old_settings=original['score']['drive_settings'] if 'score' in original else original['drive_settings']
fixed=score_basis(basis,angles,freq,ids,objectives,old_settings,sphere_points)
verify_frequency_assembly(assembly)
report={'status':'complete','kind':'derived_frequency_diagnostic','application_source_commit':'c36e357',
    'assembly_sha256':sha256(assembly_path),'brief_sha256':sha256(brief_path),
    'runner_sha256':sha256(Path(__file__)),'kernel_source_sha256':sha256(root/'runs/analyse-large-distance-bases.py'),
    'kernel_replay_evidence_sha256':sha256(root/'runs/large-distance-bases/report.json'),
    'frequencies_hz':freq.tolist(),'objectives':objectives.model_dump(mode='json'),
    'selection':selection,'historical_dsp_on_full_grid':fixed,'parallel_mid_bank':bank,
    'response_screen_limit_db':6.,'response_screen_passed':selection['selected'] is not None and selection['selected']['ripple_db']<=6.,
    'original_search_status':'cancelled','original_trial_status':'failed','original_evaluation_status':'timed_out',
    'qualified':False,'physical_validation':False,'absolute_spl_calibrated':False,
    'electrical_validation':{'passed':False,'status':'unsupported_storage_precision','storage':'complex64','unchanged_tolerance':1e-8},
    'limitations':['15-frequency training grid, not a holdout or mesh-convergence test',
        '1 m observation distance, not demonstrated far field',
        'Reported mid circuits with idealised cavities and synthetic HF; no qualified commercial source or print fit']}
(root/'runs/wide-vocal-derived-score.json').write_text(json.dumps(report,indent=2)+'\\n')
print(json.dumps(report,indent=2))
'''
Path('runs/analyse-wide-vocal-assembly.py').write_text(header+'\n'+kernel+'\n'+footer)
