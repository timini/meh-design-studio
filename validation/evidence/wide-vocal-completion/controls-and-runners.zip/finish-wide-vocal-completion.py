"""Archive the unchanged timeout and verified completion as separate evidence."""
from pathlib import Path
import json,zipfile
from meh_studio.boundary_lab import sha256
from meh_studio.partial_results import verify_frequency_assembly
root=Path.cwd();assembly_path=root/'runs/wide-vocal-frequency-assembly-reviewed.json'
assembly=json.loads(assembly_path.read_text());verify_frequency_assembly(assembly)
score=json.loads((root/'runs/wide-vocal-derived-score.json').read_text())
assert score['assembly_sha256']==sha256(assembly_path)
assert not score['response_screen_passed']
original=root/'runs/wide-vocal-search';supplement=root/'runs/wide-vocal-missing-frequencies'
assert json.loads((original/'search.json').read_text())['status']=='cancelled'
assert json.loads((original/'trial-000/evaluation/evaluation.json').read_text())['status']=='timed_out'
assert json.loads((supplement/'evaluation.json').read_text())['status']=='complete'
target=root/'validation/evidence/wide-vocal-completion';target.mkdir(parents=True,exist_ok=False)
groups={}
for label,directory in (('original-cancelled-search',original),('supplemental-solve',supplement)):
    files=[];total=0;part=0
    for p in sorted(directory.rglob('*')):
        if not p.is_file():continue
        if total+p.stat().st_size>85_000_000 and files:
            groups[f'{label}-{part:02d}']=files;files=[];total=0;part+=1
        assert p.stat().st_size<90_000_000
        files.append((p,str(p.relative_to(root/'runs'))));total+=p.stat().st_size
    if files:groups[f'{label}-{part:02d}']=files
names=('run-wide-vocal-search.py','wide-vocal-search-controls.json','wide-vocal-search.log',
    'complete-wide-vocal-frequencies-v1.py','complete-wide-vocal-frequencies-v2.py','complete-wide-vocal-frequencies.py',
    'wide-vocal-missing-frequencies-v1.log','wide-vocal-missing-frequencies-v2.log','wide-vocal-missing-frequencies-v3.log',
    'wide-vocal-completion-controls.json','wide-vocal-partial-inspection.json','wide-vocal-frequency-assembly.json',
    'wide-vocal-frequency-assembly-reviewed.json','prepare-wide-vocal-analysis.py','analyse-wide-vocal-assembly.py',
    'analyse-large-distance-bases.py','wide-vocal-derived-score.json','wide-vocal-derived-score.log',
    'plot-wide-vocal-assembly.py','wide-vocal-derived-score.png','finish-wide-vocal-completion.py')
groups['controls-and-runners']=[(root/'runs'/name,name) for name in names]
archives=[]
for label,files in groups.items():
    path=target/(label+'.zip')
    with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for source,name in files:archive.write(source,name)
    assert path.stat().st_size<100_000_000
    with zipfile.ZipFile(path) as archive:assert archive.testzip() is None
    archives.append({'file':path.name,'sha256':sha256(path),'size_bytes':path.stat().st_size})
report={'status':'completed_frequency_coverage_with_failed_response_screen',
    'source_commits':{'original_solve':'e1a7a42','supplemental_solve':'b13c176',
        'initial_partial_inspection':'d84db56','reviewed_assembly_and_scoring':'c36e357'},
    'pinned_boundary_lab_revision':assembly['identity']['runtime']['revision'],
    'original_search_status':'cancelled','original_trial_status':'failed','original_evaluation_status':'timed_out',
    'supplemental_evaluation_status':'complete','frequency_count':len(assembly['rows']),
    'overlap_checks':assembly['overlap_checks'],'score':score,'archives':archives,
    'qualified':False,'physical_validation':False,'original_evaluations_modified':False}
(target/'report.json').write_text(json.dumps(report,indent=2)+'\n')
verify_frequency_assembly(assembly)
print(json.dumps({'archives':archives,'ripple_db':score['selection']['selected']['ripple_db']},indent=2))
