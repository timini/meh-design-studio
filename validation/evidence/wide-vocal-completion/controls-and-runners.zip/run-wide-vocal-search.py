"""New four-proposal native campaign with an explicit acoustic vocal-band constraint.

Starts from the historical mutated winner. It does not relabel old scores, and
retains the synthetic HF and unqualified commercial-mid limitations.
"""
from pathlib import Path
import argparse
import json
from meh_studio.boundary_lab import BoundaryLabRuntime, sha256
from meh_studio.catalogue import Catalogue
from meh_studio.domain import DriverRevision
from meh_studio.geometry import HornGeometry
from meh_studio.optimisation import SearchBrief, candidates, optimise

root = Path.cwd()
original = root / 'runs/larger-wide-mid-32k'
saved_path = original / 'trial-007/candidate.json'
saved = json.loads(saved_path.read_text())
base = HornGeometry.model_validate(saved['design'])
drivers = [DriverRevision.model_validate(d) for d in saved['driver_revisions']]
controls = json.loads((original / 'brief.json').read_text())
controls.update(frequencies_hz=[350., 700., 1000., 1200., 1500., 1750., 2000., 2250.,
    2500., 2750., 3000., 3500., 4000., 5000., 7500.], trial_budget=4, seed=20260911,
    lengths_m=[base.length_m], mouth_radii_m=[base.mouth_radius_m],
    entry_fractions=[[v/base.length_m for v in base.entry_positions_m]])
controls['evolution'].update(elite_size=1, explore_every=3, sigma_fraction=.18)
controls['evolution']['geometry_bounds'].update(driver_axial_offset_m=[-.012, 0.],
    port_radius_m=[.016, .032], front_depth_m=[.0015, .006])
controls['acoustic_objectives'].update(acoustic_handover_hz=[3000., 5000.],
    sphere={'angle_precision_deg': 10., 'control_from_hz': 1000., 'rear_attenuation_db': 30.})
brief = SearchBrief.model_validate(controls)
rows = candidates(brief, base, drivers)
assert rows[0]['design'].content_hash == base.content_hash
assert brief.acoustic_objectives.minimum_bank_impedance_ohm == 2.
provenance = {
    'application_source_commit': 'e1a7a42', 'source_worktree': 'runs/acoustic-handover-source',
    'reference_candidate_sha256': sha256(saved_path), 'reference_candidate_index': 7,
    'reference_application_source_commit': 'a0a604e',
    'new_native_evaluation_required': True,
    'design_space_rationale': 'After the positive-offset diagnostic failed, explore nonpositive driver offsets and larger ports/shallower cavities; no acoustic benefit is assumed',
    'offset_feasibility_check': 'Baseline winner with -12 mm offset passed full CAD checks; -18 mm was rejected by throat clearance before CAD',
    'limitations': ['Four proposals are a bounded campaign, not a global optimum',
        'Reported mid circuits and synthetic HF, not an all-commercial prediction',
        '15-frequency diagnostic search grid, not an independent holdout',
        'No mesh convergence, physical measurement, purchased-driver mounting or print qualification'],
}
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare', action='store_true')
    args = parser.parse_args()
    if args.prepare:
        (root / 'runs/wide-vocal-search-controls.json').write_text(json.dumps({
            'brief': brief.model_dump(mode='json'), 'base': base.model_dump(mode='json'),
            'provenance': provenance}, indent=2) + '\n')
        print(json.dumps(provenance, indent=2))
    else:
        native = root / 'runs/runtime'
        database = root / 'runs/wide-vocal-search.sqlite'
        with Catalogue.create(database) as catalogue:
            for driver in drivers:
                catalogue.add(driver)
        runtime = BoundaryLabRuntime(native/'boundary-lab', native/'blab-env/bin/python',
            native/'julia-1.12.6/bin/julia', julia_threads=4)
        output = root / 'runs/wide-vocal-search'
        result = optimise(brief, base, database, runtime, output, solver_stage_timeout_s=3600)
        (output/'experiment-provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
        print(json.dumps(result, indent=2))
