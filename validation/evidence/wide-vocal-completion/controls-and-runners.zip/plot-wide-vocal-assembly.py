from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
root=Path.cwd();report=json.loads((root/'runs/wide-vocal-derived-score.json').read_text())
freq=np.array(report['frequencies_hz']);selected=report['selection']['selected'];old=report['historical_dsp_on_full_grid']
fig,axes=plt.subplots(2,1,figsize=(10,7),sharex=True,layout='constrained')
for score,label in ((old,'Historical DSP (fails mid handover)'),(selected,'Reselected DSP (mid handover passes)')):
    y=np.array(score['target_residual_db']);y-=(y.max()+y.min())/2
    axes[0].semilogx(freq,y,'o-',label=f"{label}: {score['ripple_db']:.2f} dB span")
    axes[1].semilogx(freq,score['acoustic_handover']['mid_over_hf_db'],'o-',label=label)
axes[0].axhspan(-3,3,color='green',alpha=.12,label='6 dB response screen')
axes[0].set(ylabel='Target residual, centred (dB)',title='Completed 15-frequency diagnostic: the midband remains uneven')
axes[0].legend(fontsize=8)
axes[1].axhline(0,color='black',lw=.7)
axes[1].axvspan(3000,5000,color='grey',alpha=.12,label='Allowed mid/HF transition')
axes[1].set(xlabel='Frequency (Hz)',ylabel='Mid-channel / HF-channel pressure (dB)')
axes[1].legend(fontsize=8)
for ax in axes:ax.grid(alpha=.25,which='both')
axes[1].set_xticks([350,700,1000,2000,3000,5000,7500],labels=['350','700','1k','2k','3k','5k','7.5k'])
fig.supxlabel('1 m observation • synthetic HF / idealised cavities • numerical prediction, no physical qualification',fontsize=9)
fig.savefig(root/'runs/wide-vocal-derived-score.png',dpi=160)
