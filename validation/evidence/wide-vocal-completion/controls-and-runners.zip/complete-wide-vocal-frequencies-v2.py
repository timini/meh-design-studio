"""Complete missing frequencies on unchanged meshes, with an overlapping verification sample."""
from pathlib import Path
import json
from meh_studio.boundary_lab import BoundaryLabRuntime,SolveRequest,sha256
root=Path.cwd();original=root/'runs/wide-vocal-search/trial-000';native=root/'runs/runtime'
runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',
    native/'julia-1.12.6/bin/julia','beat_cpu',julia_threads=4)
old=json.loads((original/'evaluation/evaluation.json').read_text())
assert old['status']=='timed_out'
assert runtime.verify()==old['runtime']
manifest=json.loads((original/'evaluation/upstream/manifest.json').read_text())
complete=[row['freq_hz'] for row in manifest['results']]
assert complete==[350.,700.,1000.,1200.,1500.,1750.,2000.,2250.,2500.,2750.,3000.,3500.,4000.]
assert manifest['completion_mask']==[True]*13+[False]*2
output=root/'runs/wide-vocal-missing-frequencies'
controls={'application_source_commit':'b13c176','original_application_source_commit':'e1a7a42',
    'original_failed_evaluation_sha256':sha256(original/'evaluation/evaluation.json'),
    'original_partial_manifest_sha256':sha256(original/'evaluation/upstream/manifest.json'),
    'original_project_sha256':sha256(original/'system/project.blab.json'),
    'original_runtime':old['runtime'],'frequencies_hz':[4000.,5000.,7500.],
    'overlap_frequency_hz':4000.,'solver_stage_timeout_s':7200,
    'overlap_limits':{'maximum_magnitude_change_db':.05,'maximum_phase_change_deg':.5,
        'relative_null_floor':.001,'maximum_current_velocity_complex_norm_error':1e-5},
    'original_search_status':'cancelled after trial0 timeout and before continuing more one-hour-budget trials',
    'qualification':False,'original_failure_preserved':True}
(root/'runs/wide-vocal-completion-controls.json').write_text(json.dumps(controls,indent=2)+'\n')
request=SolveRequest(frequencies_hz=tuple(controls['frequencies_hz']),include_project_observations=True,
                     retain=('fem_nodal_pressure','bem_boundary_traces'))
result=runtime.solve(original/'system/project.blab.json',request,output,timeout_s=7200)
assert sha256(original/'evaluation/evaluation.json')==controls['original_failed_evaluation_sha256']
assert sha256(original/'evaluation/upstream/manifest.json')==controls['original_partial_manifest_sha256']
print(json.dumps(result,indent=2))
