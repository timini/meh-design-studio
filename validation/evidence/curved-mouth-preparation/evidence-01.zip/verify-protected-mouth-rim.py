from pathlib import Path
import json
from meh_studio.boundary_lab import sha256
from meh_studio.interface_coordinates import restore_fem_interface_coordinates
from meh_studio.radiation_geometry import surface_integrity,verify_exterior_groups
root=Path.cwd();probe=root/'runs/protected-mouth-rim-probe';failed=root/'runs/nonlinear-flare-seeds/exponential-round/system'
original=json.loads((probe/'report.json').read_text());exterior=json.loads((failed/'exterior/exterior.json').read_text())
restoration=restore_fem_interface_coordinates(probe/'exterior-conformed-raw.msh',failed/'meshes/front.msh',probe/'exterior.msh')
integrity=surface_integrity(probe/'exterior.msh',maximum_triangles=32000)
verify_exterior_groups(probe/'exterior.msh',failed/'meshes/front.msh')
error=abs(integrity['enclosed_volume_m3']/exterior['cad_volume_m3']-1)
assert error<=.02
report={'status':'complete','application_source_commit':'93da10c',
 'upstream_revision':'8cb166226e412877d3f71f2845918e479b97aa85',
 'probe_runner_sha256':sha256(root/'runs/probe-protected-mouth-rim.py'),
 'verification_runner_sha256':sha256(Path(__file__)),'probe_report_sha256':sha256(probe/'report.json'),
 'input_fem_sha256':sha256(failed/'meshes/front.msh'),'input_bem_sha256':sha256(failed/'exterior/exterior.msh'),
 'restoration':restoration,'integrity':integrity,'relative_enclosed_volume_difference':error,
 'nonplanar_triangles_unchanged_before_interface_restoration':original['nonplanar_triangle_coordinates_unchanged'],
 'native_acoustic_solve_executed':False,'qualified':False,'physical_validation':False}
(probe/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
