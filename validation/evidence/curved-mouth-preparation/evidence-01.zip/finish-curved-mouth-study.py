"""Bind complete nonlinear preparations and retained failures to immutable archives."""
from pathlib import Path
import json
import zipfile
from meh_studio.boundary_lab import sha256
from meh_studio.geometry import HornGeometry
from meh_studio.radiation_geometry import surface_integrity, verify_exterior_groups

root = Path.cwd()
runs = root / 'runs'
rebuilt = runs / 'nonlinear-flare-rebuild'
control_path = runs / 'nonlinear-flare-rebuild-controls.json'
controls = json.loads(control_path.read_text())
run = json.loads((rebuilt / 'report.json').read_text())
assert run['status'] == 'complete' and all(r['status'] == 'complete' for r in run['rows'])
assert run['controls_sha256'] == sha256(control_path)
assert controls['original_controls_sha256'] == sha256(runs / 'nonlinear-flare-seed-controls.json')
assert controls['original_report_sha256'] == sha256(runs / 'nonlinear-flare-seeds/report.json')
assert run['runner_sha256'] == controls['runner_sha256'] == sha256(runs / 'rebuild-nonlinear-flare-seeds.py')
rows = []
for seed, completed in zip(controls['seeds'], run['rows'], strict=True):
    label = seed['label']
    assert completed['label'] == label
    folder = rebuilt / label
    old = runs / 'nonlinear-flare-seeds' / label
    design = HornGeometry.model_validate_json((folder / 'geometry-input.json').read_text())
    assert design.content_hash == seed['design_hash'] == completed['design_hash']
    assert (folder / 'geometry-input.json').read_bytes() == (old / 'geometry-input.json').read_bytes()
    assert (folder / 'sources-input.json').read_bytes() == (old / 'sources-input.json').read_bytes()
    assert sha256(folder / 'geometry/geometry.json') == completed['geometry_manifest_sha256']
    system = folder / 'system'
    assert sha256(system / 'compilation.json') == completed['compilation_sha256']
    compilation = json.loads((system / 'compilation.json').read_text())
    mesh = json.loads((folder / 'geometry/analysis/mesh.json').read_text())
    exterior = json.loads((system / 'exterior/exterior.json').read_text())
    assert compilation['status'] == mesh['status'] == exterior['status'] == 'complete'
    assert sha256(system / 'project.blab.json') == compilation['project_sha256']
    for region in mesh['regions']:
        assert sha256(folder / 'geometry' / region['path']) == region['sha256']
        assert region['tetrahedra'] <= design.maximum_tetrahedra
    conform = compilation['mouth_conforming']
    assert conform == json.loads((system / 'conform-interface.json').read_text())
    assert conform['status'] == 'complete' and conform['protected_facets_unchanged']
    assert sha256(system / 'meshes/front.msh') == conform['input_sha256']['front']
    assert sha256(system / 'exterior/exterior.msh') == conform['input_sha256']['exterior']
    assert sha256(system / 'meshes/exterior-conformed-raw.msh') == conform['output_sha256']
    assert conform['helper_sha256'] == sha256(runs / 'curved-mouth-source/src/meh_studio/native_mouth_conform.py')
    integrity = surface_integrity(system / 'meshes/exterior.msh', maximum_triangles=design.maximum_exterior_triangles)
    assert integrity == compilation['exterior_surface']
    verify_exterior_groups(system / 'meshes/exterior.msh', system / 'meshes/front.msh')
    volume_error = abs(integrity['enclosed_volume_m3'] / exterior['cad_volume_m3'] - 1)
    source_error = max(a['relative_area_error'] for r in mesh['regions'] for a in r['source_area_checks'])
    assert volume_error <= .02 and source_error <= .01
    front = next(r for r in mesh['regions'] if r['id'] == 'front')
    old_mesh = json.loads((old / 'geometry/analysis/mesh.json').read_text())
    old_front = next((r for r in old_mesh['regions'] if r['id'] == 'front'), None)
    if label == 'exponential-round':
        assert conform['input_sha256']['front'] == sha256(old / 'system/meshes/front.msh')
        assert conform['input_sha256']['exterior'] == sha256(old / 'system/exterior/exterior.msh')
    rows.append({'label': label, 'status': 'complete', 'design_hash': design.content_hash,
        'front_tetrahedra': front['tetrahedra'], 'estimated_front_tetrahedra': front['estimated_tetrahedra'],
        'old_recorded_front_estimate': old_front['estimated_tetrahedra'] if old_front else None,
        'old_mesh_error': old_mesh.get('error'),
        'minimum_front_quality': front['minimum_quality'], 'exterior': integrity,
        'relative_exterior_volume_error': volume_error, 'maximum_relative_source_area_error': source_error,
        'conforming': conform, 'compilation_sha256': completed['compilation_sha256']})

paths = sorted(p for name in ('nonlinear-flare-seeds', 'nonlinear-flare-rebuild', 'protected-mouth-rim-probe')
    for p in (runs / name).rglob('*') if p.is_file())
paths += [runs / name for name in (
    'prepare-nonlinear-flare-seeds.py', 'nonlinear-flare-seed-controls.json', 'nonlinear-flare-seeds.log',
    'probe-protected-mouth-rim.py', 'verify-protected-mouth-rim.py',
    'rebuild-nonlinear-flare-seeds.py', 'nonlinear-flare-rebuild-controls.json',
    'nonlinear-flare-rebuild-preparation.log', 'nonlinear-flare-rebuild.log',
    'curved-mouth-unit-tests.log', 'render-nonlinear-flare-seeds.py',
    'nonlinear-flare-seeds-preview.png', 'finish-curved-mouth-study.py')]
inventory = {str(p.relative_to(runs)): sha256(p) for p in paths}
groups = []
files = []
size = 0
for path in paths:
    n = path.stat().st_size
    assert n < 90_000_000
    if files and size+n > 75_000_000:
        groups.append(files); files = []; size = 0
    files.append(path); size += n
if files: groups.append(files)
target = root / 'validation/evidence/curved-mouth-preparation'
target.mkdir(parents=True, exist_ok=False)
archives = []
for index, files in enumerate(groups):
    path = target / f'evidence-{index:02d}.zip'
    with zipfile.ZipFile(path, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for item in files: archive.write(item, str(item.relative_to(runs)))
    assert path.stat().st_size < 100_000_000
    with zipfile.ZipFile(path) as archive: assert archive.testzip() is None
    archives.append({'file': path.name, 'sha256': sha256(path), 'size_bytes': path.stat().st_size})
assert inventory == {str(p.relative_to(runs)): sha256(p) for p in paths}
report = {'status': 'completed_geometry_and_solver_input_preparation',
    'application_source_commit': controls['application_source_commit'],
    'original_failure_source_commit': '93da10c', 'controls_sha256': sha256(control_path),
    'rows': rows, 'archives': archives, 'archived_file_sha256': inventory,
    'native_acoustic_solve_executed': False, 'qualified': False, 'physical_validation': False,
    'limits': {'maximum_tetrahedra_per_region': 5_000_000, 'maximum_exterior_triangles': 32_000,
        'relative_source_area_error': .01, 'relative_exterior_volume_error': .02,
        'mouth_coordinate_tolerance_m': 1e-8},
    'limitations': controls['limitations']}
(target / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'rows': rows, 'archives': archives}, indent=2))
