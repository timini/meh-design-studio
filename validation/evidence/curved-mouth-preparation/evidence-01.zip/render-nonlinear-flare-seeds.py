from pathlib import Path
import struct
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
root=Path.cwd();fig=plt.figure(figsize=(11,6),layout='constrained')
dtype=np.dtype([('normal','<f4',(3,)),('vertices','<f4',(3,3)),('attribute','<u2')])
light=np.array([.3,-.5,.8]);light/=np.linalg.norm(light)
for index,(label,title) in enumerate([('exponential-round','Exponential-radius controls'),('quadratic-rounded-square','Quadratic flare · rounded-square mouth')]):
 ax=fig.add_subplot(1,2,index+1,projection='3d')
 for path in sorted((root/'runs/nonlinear-flare-seeds'/label/'geometry/parts').glob('*.stl')):
  with path.open('rb') as stream:
   stream.seek(80);count=struct.unpack('<I',stream.read(4))[0];data=np.fromfile(stream,dtype=dtype,count=count)
  assert path.stat().st_size==84+50*count and len(data)==count
  normals=data['normal'].astype(float);norm=np.linalg.norm(normals,axis=1);norm[norm==0]=1
  shade=.45+.55*abs((normals/norm[:,None])@light)
  color=np.array([.16,.52,.60] if path.stem=='horn' else [.57,.60,.62])
  ax.add_collection3d(Poly3DCollection(data['vertices'],facecolors=shade[:,None]*color,edgecolors='none'))
 ax.set_xlim(-245,245);ax.set_ylim(-245,245);ax.set_zlim(0,310)
 ax.set_box_aspect((490,490,310));ax.view_init(elev=28,azim=-58)
 ax.set_xlabel('x (mm)');ax.set_ylabel('y (mm)');ax.set_zlabel('z (mm)')
 ax.set_xticks([-200,0,200]);ax.set_yticks([-200,0,200]);ax.set_zticks([0,150,300])
 ax.set_title(title,fontsize=11,fontweight='bold')
fig.suptitle('Actual generated CAD: stronger nonlinear starting shapes\nMaterial shells with ideal circular driver interfaces. Acoustic preparation has not passed.',fontsize=12)
fig.savefig(root/'runs/nonlinear-flare-seeds-preview.png',dpi=180,bbox_inches='tight',pad_inches=.25)
