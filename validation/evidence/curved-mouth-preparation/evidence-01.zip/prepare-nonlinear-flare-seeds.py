"""Build stronger nonlinear control seeds with the existing freeform grammar."""
from pathlib import Path
import argparse,json,math
from meh_studio.boundary_lab import BoundaryLabRuntime,sha256
from meh_studio.domain import DriverRevision
from meh_studio.geometry import HornGeometry,export_geometry,mesh_geometry
from meh_studio.generated_system import HornSources
from meh_studio.radiating_system import compile_radiating_system
from meh_studio.optimisation import verified_assessment
root=Path.cwd();parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');args=parser.parse_args()
baseline=root/'runs/quarter-turn-vocal-search/trial-000'
evidence=verified_assessment(baseline/'system/project.blab.json',baseline/'evaluation')
saved=json.loads((baseline/'candidate.json').read_text());base=HornGeometry.model_validate(saved['design'])
replacement_path=root/'examples/reported-drivers/peerless-dfm2535-8-ideal-outlet.json'
replacement=DriverRevision.model_validate_json(replacement_path.read_text())
sources=HornSources.model_validate(saved['sources']|{'throat':replacement.source_model})
seeds=[]
for label,reference_mouth,axis_mouth in [('exponential-round',.16,.22),('quadratic-rounded-square',.15,.20)]:
    sections=[]
    for fraction in (.2,.4,.7,1.):
        radius=(base.throat_radius_m*(axis_mouth/base.throat_radius_m)**fraction if label=='exponential-round'
                else base.throat_radius_m+(axis_mouth-base.throat_radius_m)*fraction**2)
        reference=base.throat_radius_m+(reference_mouth-base.throat_radius_m)*fraction
        scales=[]
        for i in range(8):
            angle=i*math.pi/4
            factor=1. if label=='exponential-round' else (abs(math.cos(angle))**4+abs(math.sin(angle))**4)**(-.25)
            scales.append(radius*factor/reference)
        # Use exact linked cardinal/diagonal values to preserve declared C4 symmetry.
        scales=[scales[i%2] for i in range(8)]
        sections.append({'fraction':fraction,'radial_scales':scales})
    design=HornGeometry.model_validate(base.model_dump()|{'mouth_radius_m':reference_mouth,
        'profile_sections':sections,'port_length_m':.012})
    seeds.append({'label':label,'design':design.model_dump(mode='json'),'design_hash':design.content_hash,
        'construction':'Exponential radius controls with circular sections' if label=='exponential-round' else 'Quadratic axial radius controls with fourth-power superellipse azimuthal controls',
        'nominal_axis_mouth_radius_m':axis_mouth,
        'notes':['The resulting CAD is a spline loft through these controls, not an exact analytic flare between stations',
            'mouth_radius_m is the reference for radial scales; actual mouth dimensions come from the CAD',
            '12 mm nominal port extension is an explicit seed choice to separate the four chamber envelopes; actual duct length must be measured from the generated model']})
controls={'application_source_commit':'93da10c','reference_evidence':evidence,
    'reference_candidate_sha256':sha256(baseline/'candidate.json'),
    'replacement_driver_file_sha256':sha256(replacement_path),'sources':sources.model_dump(mode='json'),
    'seeds':seeds,'predeclared_checks':['valid CAD solids and positive air/material volumes','tagged air meshes within existing 5M tetrahedron cap','radiating compilation within existing 32000 exterior triangle cap'],
    'physical_validation':False,'qualified':False,
    'limitations':['Geometry and compilation preparation only; no acoustic solve, objective score or shape acceptance',
        'Provisional HF and reported mids with idealised cavities; no actual cone, basket fit or print qualification',
        'Existing geometric and mesh limits remain unchanged; failures are retained']}
control_path=root/'runs/nonlinear-flare-seed-controls.json'
if args.prepare:
    with control_path.open('x') as stream:stream.write(json.dumps(controls,indent=2)+'\n')
    print(json.dumps(controls,indent=2));raise SystemExit
assert json.loads(control_path.read_text())==controls
output=root/'runs/nonlinear-flare-seeds';output.mkdir(exist_ok=False)
native=root/'runs/runtime'
runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',native/'julia-1.12.6/bin/julia','beat_cpu',julia_threads=4)
rows=[]
for seed in seeds:
    folder=output/seed['label'];folder.mkdir();design=HornGeometry.model_validate(seed['design'])
    (folder/'geometry-input.json').write_text(design.model_dump_json(indent=2)+'\n')
    (folder/'sources-input.json').write_text(sources.model_dump_json(indent=2)+'\n')
    row={'label':seed['label'],'status':'running','design_hash':seed['design_hash']}
    try:
        geometry=export_geometry(design,folder/'geometry')
        mesh=mesh_geometry(folder/'geometry')
        compilation=compile_radiating_system(folder/'geometry',sources,folder/'system',runtime,
            exterior_mesh_size_m=.01,observation_distance_m=20.,sphere_angle_deg=10.)
        row.update(status='complete',geometry_manifest_sha256=sha256(folder/'geometry/geometry.json'),
            compilation_sha256=sha256(folder/'system/compilation.json'))
    except Exception as exc:row.update(status='failed',error=f'{type(exc).__name__}: {exc}')
    rows.append(row)
    result={'status':'complete' if len(rows)==len(seeds) else 'running','application_source_commit':'93da10c',
        'controls_sha256':sha256(control_path),'runner_sha256':sha256(Path(__file__)),'rows':rows,
        'native_acoustic_solve_executed':False,'qualified':False,'physical_validation':False}
    (output/'report.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(row),flush=True)
