"""Repeat the retained nonlinear seed preparation with the production mouth fix."""
from pathlib import Path
import argparse
import json
import subprocess
from meh_studio.boundary_lab import BoundaryLabRuntime, sha256
from meh_studio.geometry import HornGeometry, export_geometry, mesh_geometry
from meh_studio.generated_system import HornSources
from meh_studio.radiating_system import compile_radiating_system

root = Path.cwd()
parser = argparse.ArgumentParser()
parser.add_argument('--prepare', action='store_true')
args = parser.parse_args()
source = root / 'runs/curved-mouth-source'
commit = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
assert commit == '5c5fab109c7ae169582d7330b157bf068c46ef0a'
assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'], text=True)
old_path = root / 'runs/nonlinear-flare-seed-controls.json'
old = json.loads(old_path.read_text())
controls = {
    'application_source_commit': commit,
    'original_controls_sha256': sha256(old_path),
    'original_report_sha256': sha256(root / 'runs/nonlinear-flare-seeds/report.json'),
    'sources': old['sources'], 'seeds': old['seeds'],
    'runner_sha256': sha256(Path(__file__)),
    'predeclared_checks': old['predeclared_checks'] + [
        'exact preservation of protected oriented curved-wall facets',
        'exact FEM mouth facets after existing coordinate restoration',
        'closed oriented exterior and existing 2 percent volume tolerance',
        'unchanged 1 percent source-area tolerance'],
    'native_acoustic_solve_executed': False, 'qualified': False,
    'limitations': old['limitations'],
}
control_path = root / 'runs/nonlinear-flare-rebuild-controls.json'
if args.prepare:
    with control_path.open('x') as stream:
        stream.write(json.dumps(controls, indent=2) + '\n')
    print(json.dumps(controls, indent=2))
    raise SystemExit
assert json.loads(control_path.read_text()) == controls
output = root / 'runs/nonlinear-flare-rebuild'
output.mkdir(exist_ok=False)
native = root / 'runs/runtime'
runtime = BoundaryLabRuntime(native / 'boundary-lab', native / 'blab-env/bin/python',
    native / 'julia-1.12.6/bin/julia', 'beat_cpu', julia_threads=4)
sources = HornSources.model_validate(controls['sources'])
rows = []
for seed in controls['seeds']:
    folder = output / seed['label']
    folder.mkdir()
    design = HornGeometry.model_validate(seed['design'])
    assert design.content_hash == seed['design_hash']
    (folder / 'geometry-input.json').write_text(design.model_dump_json(indent=2) + '\n')
    (folder / 'sources-input.json').write_text(sources.model_dump_json(indent=2) + '\n')
    row = {'label': seed['label'], 'status': 'running', 'design_hash': design.content_hash}
    try:
        export_geometry(design, folder / 'geometry')
        mesh_geometry(folder / 'geometry')
        compile_radiating_system(folder / 'geometry', sources, folder / 'system', runtime,
            exterior_mesh_size_m=.01, observation_distance_m=20., sphere_angle_deg=10.)
        row.update(status='complete',
            geometry_manifest_sha256=sha256(folder / 'geometry/geometry.json'),
            compilation_sha256=sha256(folder / 'system/compilation.json'))
    except Exception as exc:
        row.update(status='failed', error=f'{type(exc).__name__}: {exc}')
    rows.append(row)
    report = {'status': 'complete' if len(rows) == len(controls['seeds']) else 'running',
        'application_source_commit': commit, 'controls_sha256': sha256(control_path),
        'runner_sha256': sha256(Path(__file__)), 'rows': rows,
        'native_acoustic_solve_executed': False, 'qualified': False,
        'physical_validation': False}
    (output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(row), flush=True)
