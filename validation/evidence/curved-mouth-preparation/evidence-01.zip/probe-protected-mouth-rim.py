"""Diagnose planar-rim classification on the preserved failed exponential mesh."""
from pathlib import Path
from collections import Counter
import json,dataclasses
import numpy as np
import meshio
from blab.interface_conform import conform_bem_interface_to_fem
root=Path.cwd();failed=root/'runs/nonlinear-flare-seeds/exponential-round/system'
fem=meshio.read(failed/'meshes/front.msh');bem=meshio.read(failed/'exterior/exterior.msh')
output=root/'runs/protected-mouth-rim-probe';output.mkdir(exist_ok=False)
mouth=int(bem.field_data['mouth_interface'][0]);rigid=int(bem.field_data['rigid_exterior'][0])
assert all(c.type=='triangle' for c in bem.cells)
rows=np.concatenate([c.data for c in bem.cells]);tags=np.concatenate(bem.cell_data['gmsh:physical'])
interface=rows[tags==mouth];level=float(fem.points[:,2].max())
deviation=np.max(abs(bem.points[rows,:,][...,2]-level),axis=1)
planar=(tags==rigid)&(deviation<=1e-8);protect=(tags==rigid)&~planar
assert np.any(planar) and np.any(protect)
normals=np.cross(bem.points[rows[:,1]]-bem.points[rows[:,0]],bem.points[rows[:,2]]-bem.points[rows[:,0]])
normal=lambda mask:(normals[mask].sum(axis=0)/np.linalg.norm(normals[mask].sum(axis=0))).tolist()
protected_tag=max(int(v[0]) for v in bem.field_data.values())+1
before=Counter(tuple(sorted(tuple(p) for p in face)) for face in bem.points[rows[protect]])
offset=0
for cell,physical in zip(bem.cells,bem.cell_data['gmsh:physical']):
    count=len(cell.data);physical[protect[offset:offset+count]]=protected_tag;offset+=count
bem.field_data['protected_rigid_exterior']=np.array([protected_tag,2])
conformed,result=conform_bem_interface_to_fem(fem,bem,fem_interface_name='mouth_interface',
    bem_interface_name='mouth_interface',protected_bem_interface_names=('protected_rigid_exterior',))
after=[]
for cell,physical in zip(conformed.cells,conformed.cell_data['gmsh:physical']):
    after.extend(conformed.points[cell.data[np.asarray(physical)==protected_tag]])
assert Counter(tuple(sorted(tuple(p) for p in face)) for face in after)==before
for physical in conformed.cell_data['gmsh:physical']:physical[physical==protected_tag]=rigid
del conformed.field_data['protected_rigid_exterior']
meshio.write(output/'exterior-conformed-raw.msh',conformed,file_format='gmsh22',binary=False,float_fmt='.17e')
report={'status':'complete','mouth_plane_z_m':level,'planar_rim_triangles':int(planar.sum()),
    'protected_nonplanar_triangles':int(protect.sum()),'planar_rim_area_weighted_normal':normal(planar),
    'nonplanar_triangle_coordinates_unchanged':True,'conforming_result':dataclasses.asdict(result),
    'native_acoustic_solve_executed':False,'qualified':False}
(output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
