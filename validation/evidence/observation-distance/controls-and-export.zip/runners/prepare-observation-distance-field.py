"""Freeze existing large winner and DSP for a retained-BEM distance diagnostic."""
from pathlib import Path
import json
import numpy as np
from meh_studio.boundary_lab import sha256,_read_json,_contained
from meh_studio.optimisation import verified_assessment
from meh_studio.acoustic_objectives import drive_weights
root=Path.cwd();trial=root/'runs/larger-wide-mid-32k/trial-007';evaluation=trial/'evaluation';raw=evaluation/'upstream'
identity=verified_assessment(trial/'system/project.blab.json',evaluation)
manifest=_read_json(raw/'manifest.json');project=_read_json(trial/'system/project.blab.json')
settings=_read_json(trial/'score.json')['drive_settings']
ports={p['id']:p['component_id'] for p in project['physical_system']['excitation_ports']}
ids=[ports[p] for p in manifest['excitation_port_ids']]
frequencies=[r['freq_hz'] for r in manifest['results']]
weights=drive_weights(frequencies,ids,settings)
domains=_read_json(_contained(raw,manifest['domains_metadata_file']))['domains']
with np.load(_contained(raw,manifest['domains_file']),allow_pickle=False) as data:
    bem=next(d for d in domains if d['id']=='domain:bem-boundary')
    points=data[bem['coordinates']['points_m']].copy();triangles=data[bem['topology']['triangles']].copy()
    polar=[]
    for plane in ('horizontal','vertical'):
        d=next(d for d in domains if d['id']==f'observation:{plane}-polar')
        polar.append(data[d['coordinates']['points_m']].copy())
        angles=data[d['coordinates']['angle_deg']].copy()
pressure=[];neumann=[];original=[]
for index,row in enumerate(manifest['results']):
    meta=_read_json(_contained(raw,row['metadata_file']));q={q['id']:q for q in meta['quantities']}
    with np.load(_contained(raw,row['arrays_file']),allow_pickle=False) as data:
        pressure.append(weights[index]@data[q['acoustic:pressure:bem-boundary']['key']])
        neumann.append(weights[index]@data[q['acoustic:normal-derivative:bem-boundary']['key']])
        original.append(np.concatenate([weights[index]@data[q[f'acoustic:pressure:{plane}-polar']['key']]
                                       for plane in ('horizontal','vertical')]))
output=root/'runs/large-distance-field';output.mkdir(exist_ok=False)
radii=np.array([1.,5.,10.,20.,40.])
np.savez_compressed(output/'input.npz',boundary_points=points,boundary_triangles=triangles,
    pressure=np.asarray(pressure,dtype=np.complex64),neumann=np.asarray(neumann,dtype=np.complex64),
    original=np.asarray(original),unit_points=np.vstack(polar),radii=radii,angles=angles,frequencies=frequencies)
controls={'application_source_commit':'b13c176','native_source_commit':'a0a604e',
    'native_search':'runs/larger-wide-mid-32k','native_trial':7,'native_evidence_identity':identity,
    'input_sha256':sha256(output/'input.npz'),'drive_settings':settings,
    'reference_voltage_v':2.83,'radii_m':radii.tolist(),'origin_m':[0.,0.,0.],
    'projection_backend':'beat_cpu','projection_precision':'float32','julia_threads':2,
    'pinned_boundary_lab_revision':'8cb166226e412877d3f71f2845918e479b97aa85',
    'reproduction_limits':{'magnitude_db':.05,'phase_deg':.5,'relative_null_floor':.001},
    'distance_stability_limits':{'comparison_radii_m':[20.,40.],
        'maximum_axis_distance_normalised_magnitude_change_db':.25,
        'maximum_relative_polar_change_db_inside_coverage':.5,'relative_null_floor':.001},
    'qualification':False,'limitations':['Retained traces of an unconverged large target candidate',
        'Reported mid circuits plus synthetic HF; no acoustic source calibration',
        'Frozen historical 3 kHz electrical crossover; does not pass the later acoustic handover constraint',
        'Magnitude/phase reproduction gates are declared before projection; no fitting or retuning',
        'A distance-stability pass is not acoustic accuracy, mesh convergence or maximum-SPL qualification']}
(output/'controls.json').write_text(json.dumps(controls,indent=2)+'\n')
assert verified_assessment(trial/'system/project.blab.json',evaluation)==identity
print('Prepared immutable pressure/normal-derivative traces and fixed DSP')
