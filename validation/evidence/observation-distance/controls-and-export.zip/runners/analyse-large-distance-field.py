"""Evaluate predeclared reproduction and distance-stability checks without fitting."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from meh_studio.boundary_lab import sha256
root=Path.cwd();out=root/'runs/large-distance-field'
controls=json.loads((out/'controls.json').read_text())
assert sha256(out/'input.npz')==controls['input_sha256']
with np.load(out/'input.npz',allow_pickle=False) as data:
    original=data['original'].copy();angles=data['angles'].copy()
with np.load(out/'result.npz',allow_pickle=False) as data:
    pressure=data['pressure'].copy();radii=data['radii'].copy();freq=data['frequencies'].copy()
limits=controls['reproduction_limits'];floor=limits['relative_null_floor']
valid=abs(original)>=floor*abs(original).max(axis=1)[:,None]
ratio=pressure[:,0,:][valid]/original[valid]
mag=float(np.max(abs(20*np.log10(abs(ratio)))))
phase=float(np.max(abs(np.angle(ratio,deg=True))))
reproduction={'passed':mag<=limits['magnitude_db'] and phase<=limits['phase_deg'],
    'maximum_magnitude_change_db':mag,'maximum_phase_change_deg':phase,
    'excluded_samples':int((~valid).sum()),'total_samples':int(valid.size),
    'relative_complex_norm_error_all_samples':float(np.linalg.norm(pressure[:,0]-original)/np.linalg.norm(original))}
count=len(angles);axis=int(np.flatnonzero(angles==0)[0]);axis_p=pressure[:,:,axis]
np.testing.assert_allclose(pressure[:,:,count+axis],axis_p,rtol=1e-6,atol=1e-8)
relative=20*np.log10(np.maximum(abs(pressure)/abs(axis_p[:,:,None]),1e-30))
inside=np.tile(abs(angles)<=45,2)
left,right=[int(np.flatnonzero(radii==r)[0]) for r in controls['distance_stability_limits']['comparison_radii_m']]
valid_sector=inside[None,:]&(abs(pressure[:,left,:])>=.001*abs(axis_p[:,left,None]))&(abs(pressure[:,right,:])>=.001*abs(axis_p[:,right,None]))
angular_delta=abs(relative[:,left]-relative[:,right])
axis_delta=abs(20*np.log10(abs(axis_p[:,left]*radii[left]/(axis_p[:,right]*radii[right]))))
maximum_polar=float(angular_delta[valid_sector].max());maximum_axis=float(axis_delta.max())
excluded=int((np.broadcast_to(inside,valid_sector.shape)&~valid_sector).sum())
limits=controls['distance_stability_limits']
stability={'passed':maximum_polar<=limits['maximum_relative_polar_change_db_inside_coverage'] and maximum_axis<=limits['maximum_axis_distance_normalised_magnitude_change_db'] and excluded==0,
    'maximum_relative_polar_change_db_inside_coverage':maximum_polar,
    'maximum_axis_distance_normalised_magnitude_change_db':maximum_axis,
    'excluded_coverage_samples':excluded,'coverage_angles_deg':[-45.,45.],
    'require_no_excluded_coverage_samples_for_pass':True,'comparison_radii_m':[20.,40.]}
per_radius=[]
for j,r in enumerate(radii):
    per_radius.append({'distance_m':float(r),'axis_magnitude_times_distance':abs(axis_p[:,j]*r).tolist(),
        'axis_raw_band_variation_db':float(np.ptp(20*np.log10(abs(axis_p[:,j])))),
        'maximum_relative_coverage_change_vs_40m_db':float(abs(relative[:,j,inside]-relative[:,right,inside]).max())})
report={'status':'complete','input_sha256':sha256(out/'input.npz'),'result_sha256':sha256(out/'result.npz'),
    'reproduction':reproduction,'distance_stability':stability,'radii':per_radius,
    'frequencies_hz':freq.tolist(),'controls':controls,'physical_validation':False}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
fig,axes=plt.subplots(1,2,figsize=(11,4.5),layout='constrained')
reference=abs(axis_p[:,left]*radii[left]).max()
for j,r in enumerate(radii):
    axes[0].semilogx(freq,20*np.log10(abs(axis_p[:,j]*r)/reference),marker='.',label=f'{r:g} m')
    axes[1].plot(angles,relative[np.flatnonzero(freq==3000.)[0],j,:count],label=f'{r:g} m')
axes[0].set(xlabel='Frequency (Hz)',ylabel='Distance-normalised axis pressure (relative dB)',title='Same geometry and fixed historical DSP')
axes[1].set(xlabel='Horizontal angle (degrees)',ylabel='Pressure relative to axis (dB)',title='3 kHz horizontal cut',xlim=(-90,90),ylim=(-45,10))
axes[0].set_xticks([350,700,1200,2000,3000,5000,7500],labels=['350','700','1200','2000','3000','5000','7500'])
axes[0].minorticks_off()
for ax in axes:ax.grid(alpha=.3);ax.legend()
fig.suptitle('Retained native BEM fields: larger trial 7 at increasing distance\nReported mids + synthetic HF; no mesh or physical qualification',fontsize=11)
fig.savefig(out/'distance-comparison.png',dpi=150)
print(json.dumps({'reproduction':reproduction,'distance_stability':stability,'radii':per_radius},indent=2))
