"""Pinned native BEM projection of retained traces; no new coupled-system solve."""
from pathlib import Path
import hashlib,json,subprocess,time
import numpy as np
import blab.solvers.coupled_field as field
from blab.solvers.beat_engine_backend import shutdown_julia_workers
root=Path.cwd();out=root/'runs/large-distance-field'
controls=json.loads((out/'controls.json').read_text())
checkout=root/'runs/runtime/boundary-lab'
assert subprocess.check_output(['git','-C',str(checkout),'rev-parse','HEAD'],text=True).strip()==controls['pinned_boundary_lab_revision']
assert not subprocess.check_output(['git','-C',str(checkout),'status','--porcelain','--untracked-files=no'],text=True).strip()
assert hashlib.sha256((out/'input.npz').read_bytes()).hexdigest()==controls['input_sha256']
# Only this diagnostic process changes the upstream helper's default eight threads.
get_worker=field._get_julia_worker
field._get_julia_worker=lambda **kwargs:get_worker(**(kwargs|{'julia_threads':2}))
with np.load(out/'input.npz',allow_pickle=False) as data:
    points=np.vstack([r*data['unit_points'] for r in data['radii']])
    results=[];started=time.time()
    try:
        for i,freq in enumerate(data['frequencies']):
            request=field.BemFieldEvaluationRequest(domain_key=controls['input_sha256'],points_m=points,
                boundary_points_m=data['boundary_points'],boundary_triangles=data['boundary_triangles'],
                boundary_pressure=data['pressure'][i],boundary_normal_derivative=data['neumann'][i],
                frequency_hz=float(freq),sound_speed_m_per_s=343.,symmetry='off')
            result=field.evaluate_bem_field(request,backend_id='beat_cpu',
                julia_executable=str(root/'runs/runtime/julia-1.12.6/bin/julia'))
            results.append(result.reshape(len(data['radii']),len(data['unit_points'])))
            np.savez_compressed(out/f'frequency-{i:03d}.npz',pressure=results[-1],frequency_hz=freq)
            print(json.dumps({'frequency_hz':float(freq),'completed':len(results),'elapsed_s':time.time()-started}),flush=True)
        np.savez_compressed(out/'result.npz',pressure=np.array(results),radii=data['radii'],frequencies=data['frequencies'])
    finally:shutdown_julia_workers()
assert hashlib.sha256((out/'input.npz').read_bytes()).hexdigest()==controls['input_sha256']
