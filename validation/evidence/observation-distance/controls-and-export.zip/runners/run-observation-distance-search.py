"""One native FP64 workflow case at a declared 20 m observation radius."""
from pathlib import Path
import json
from meh_studio.boundary_lab import BoundaryLabRuntime,sha256
from meh_studio.catalogue import Catalogue
from meh_studio.domain import DriverRevision
from meh_studio.geometry import HornGeometry
from meh_studio.optimisation import SearchBrief,candidates,optimise
from meh_studio.build_bundle import export_search
from meh_studio.search_results import load_completed_search

root=Path.cwd();prior=root/'runs/reference-backend-search'
saved=json.loads((prior/'trial-000/candidate.json').read_text())
base=HornGeometry.model_validate(saved['design'])
drivers=[DriverRevision.model_validate(d) for d in saved['driver_revisions']]
data=json.loads((prior/'brief.json').read_text())
data.update(trial_budget=1)
data['acoustic_objectives']['observation_distance_m']=20.
brief=SearchBrief.model_validate(data)
assert candidates(brief,base,drivers)[0]['design'].content_hash==base.content_hash
assert brief.acoustic_objectives.minimum_bank_impedance_ohm is None
native=root/'runs/runtime';database=root/'runs/observation-distance-search.sqlite'
output=root/'runs/observation-distance-search'
with Catalogue.create(database) as catalogue:
    for driver in drivers:catalogue.add(driver)
runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',
    native/'julia-1.12.6/bin/julia','coupled_reference',julia_threads=2)
result=optimise(brief,base,database,runtime,output,solver_stage_timeout_s=1800)
provenance={'application_source_commit':'b13c176','source_worktree':'runs/observation-distance-source',
    'reference_candidate_sha256':sha256(prior/'trial-000/candidate.json'),
    'qualification':False,'observation_distance_m':20.,
    'limitations':['Synthetic sources, four diagnostic frequencies; not the user target horn',
        'The 2-ohm screen is explicitly disabled for these synthetic source circuits',
        '20 m is an integration-test radius, not an established audience specification or far-field qualification',
        'No mesh convergence, source calibration or physical/print qualification']}
(output/'experiment-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
load_completed_search(output)
bundle=export_search(output,root/'runs/observation-distance-winner.zip')
(output/'export-verification.json').write_text(json.dumps(bundle,indent=2)+'\n')
print(json.dumps({'search':result,'export':bundle,'provenance':provenance},indent=2))
