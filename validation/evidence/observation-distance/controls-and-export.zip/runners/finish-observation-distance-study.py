"""Archive the completed distance workflow and failed large-candidate stability check."""
from pathlib import Path
import json,zipfile
from meh_studio.search_results import load_completed_search
from meh_studio.boundary_lab import sha256
root=Path.cwd();source=root/'runs/observation-distance-search'
hashes,result,*_=load_completed_search(source)
export=json.loads((source/'export-verification.json').read_text())
bundle=root/'runs/observation-distance-winner.zip'
assert sha256(bundle)==export['sha256']
assert result['trials'][0]['electrical_validation']['passed']
original=root/'runs/reference-backend-search/trial-000/system/project.blab.json'
new=source/'trial-000/system/project.blab.json'
a=json.loads(original.read_text());b=json.loads(new.read_text())
assert b['project_preferences']['polar_observation_distance_m']==20.
b['project_preferences']['polar_observation_distance_m']=1.
assert a==b
field=root/'runs/large-distance-field';distance=json.loads((field/'report.json').read_text())
assert sha256(field/'input.npz')==distance['input_sha256']
assert sha256(field/'result.npz')==distance['result_sha256']
assert distance['reproduction']['passed'] and not distance['distance_stability']['passed']
target=root/'validation/evidence/observation-distance';target.mkdir(parents=True,exist_ok=False)
trial=source/'trial-000'
groups={'native-trial':[(p,str(p.relative_to(source))) for p in sorted(trial.rglob('*')) if p.is_file()],
    'distance-projection':[(p,str(p.relative_to(field))) for p in sorted(field.rglob('*')) if p.is_file()],
    'controls-and-export':[(p,p.name) for p in sorted(source.iterdir()) if p.is_file()]}
for name in ('run-observation-distance-search.py','prepare-observation-distance-field.py',
             'project-large-distance-field.py','analyse-large-distance-field.py','finish-observation-distance-study.py'):
    groups['controls-and-export'].append((root/'runs'/name,'runners/'+name))
groups['controls-and-export'].append((bundle,'exports/'+bundle.name))
archives=[]
for name,files in groups.items():
    path=target/(name+'.zip')
    with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for original,name_in_archive in files:archive.write(original,name_in_archive)
    assert path.stat().st_size<100_000_000
    with zipfile.ZipFile(path) as archive:assert archive.testzip() is None
    archives.append({'file':path.name,'sha256':sha256(path),'size_bytes':path.stat().st_size})
report={'status':'completed_distance_workflow_and_projection_diagnostic','application_source_commit':'b13c176',
    'archives':archives,'search':result,'export':export,
    'compiled_project_comparison':'Byte-equivalent parsed project after restoring only the original 1 m radius; all six mesh hashes identical',
    'large_distance_field':{'reproduction':distance['reproduction'],'distance_stability':distance['distance_stability'],
        'native_source_commit':'a0a604e','native_evidence_commit':'e1696b3c963a44c6f36eb822adee71e99aef58ad',
        'native_trial':7,'projection_source_commit':'b13c176','pinned_boundary_lab':'8cb166226e412877d3f71f2845918e479b97aa85'},
    'physical_validation':False,'mesh_convergence':False,'target_horn_design':False,
    'limitations':['20 m search case uses synthetic circuits, four frequencies and a disabled 2-ohm screen',
        'Large candidate retains historical fixed DSP which fails the later acoustic handover constraint',
        '20-to-40 m stability fails its predeclared limits; neither result is labelled far-field qualified',
        'Distance projection preserves original coupled solver traces and does not improve their mesh/source accuracy',
        'No measured source/speaker comparison or print qualification']}
(target/'report.json').write_text(json.dumps(report,indent=2)+'\n')
assert all(sha256(source/name)==digest for name,digest in hashes.items())
print(json.dumps({'archives':archives,'distance_stability':distance['distance_stability']},indent=2))
