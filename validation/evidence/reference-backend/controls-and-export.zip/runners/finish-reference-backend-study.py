"""Archive the completed native FP64 optimisation/export integration evidence."""
from pathlib import Path
import json,zipfile
from meh_studio.search_results import load_completed_search
from meh_studio.boundary_lab import sha256

root=Path.cwd();source=root/'runs/reference-backend-search'
hashes,result,*_=load_completed_search(source)
comparison=json.loads((root/'runs/reference-backend-comparison.json').read_text())
export=json.loads((source/'export-verification.json').read_text())
bundle=root/'runs/reference-backend-winner.zip'
assert sha256(bundle)==export['sha256']
assert all(t['status']=='complete' and t['electrical_validation']['passed'] for t in result['trials'])
target=root/'validation/evidence/reference-backend';target.mkdir(parents=True,exist_ok=False)
groups={}
for trial in result['trials']:
    directory=source/f'trial-{trial["index"]:03d}'
    groups[directory.name]=[(p,str(p.relative_to(source))) for p in sorted(directory.rglob('*')) if p.is_file()]
groups['controls-and-export']=[(p,p.name) for p in sorted(source.iterdir()) if p.is_file()]
for name in ('run-reference-backend-search.py','run-reference-backend-search-v2.py',
             'compare-reference-backend.py','finish-reference-backend-study.py'):
    groups['controls-and-export'].append((root/'runs'/name,'runners/'+name))
groups['controls-and-export'] += [(bundle,'exports/'+bundle.name),
    (root/'runs/reference-backend-comparison.json','diagnostics/reference-backend-comparison.json'),
    (root/'runs/reference-backend-search.log','diagnostics/rejected-v1-input.log')]
archives=[]
for name,files in groups.items():
    path=target/(name+'.zip')
    with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for original,name_in_archive in files:archive.write(original,name_in_archive)
    assert path.stat().st_size<100_000_000
    with zipfile.ZipFile(path) as archive:assert archive.testzip() is None
    archives.append({'file':path.name,'sha256':sha256(path),'size_bytes':path.stat().st_size})
report={'status':'completed_FP64_search_and_export','application_source_commit':'9ee5b03',
    'validation_cli_fix_source_commit':'cd0191a','validation_cli_fix_native_rerun_required':False,
    'validation_cli_fix_check':'62 focused finalist/partition/reference tests passed; no solver or live experiment inputs changed',
    'search':result,'archives':archives,'export':export,'precision_comparison':comparison,
    'physical_validation':False,'mesh_convergence':False,'target_horn_design':False,
    'limitations':['Two proposals and four frequencies with synthetic sources; not a global optimum',
        'Diagnostic explicitly disables the 2-ohm screen; this is not a user amplifier-compatible design',
        'Electrical consistency passes at the unchanged 1e-8 tolerance, but does not establish acoustic field accuracy',
        'Historical freeform reference failure remains failed; this is a different five-driver geometry',
        'No measured speaker/source calibration or print qualification']}
(target/'report.json').write_text(json.dumps(report,indent=2)+'\n')
assert all(sha256(source/name)==digest for name,digest in hashes.items())
print(json.dumps({'archives':archives,'winner_index':result['winner_index'],
    'trials':[{k:t[k] for k in ('index','status','ripple_db','objective')} for t in result['trials']],
    'export':export},indent=2))
