"""Compare native FP32/FP64 full pressure bases on byte-identical baseline meshes."""
from pathlib import Path
import json
import numpy as np
from meh_studio.optimisation import verified_assessment
from meh_studio.boundary_lab import _contained,sha256
from compare_exterior_refinement import compare

root=Path.cwd()
old=root/'runs/eccentric-sphere-search-v3/trial-000'
new=root/'runs/reference-backend-search/trial-000'
identities=[verified_assessment(p/'system/project.blab.json',p/'evaluation') for p in (old,new)]
raws=[p/'evaluation/upstream' for p in (old,new)]
manifests=[json.loads((p/'manifest.json').read_text()) for p in raws]
assert [m['backend_id'] for m in manifests]==['beat_cpu','coupled_reference']
meshes=[{v['id']:v['sha256'] for v in m['meshes']} for m in manifests]
assert meshes[0]==meshes[1]
assert manifests[0]['frequencies_hz']==manifests[1]['frequencies_hz']
assert manifests[0]['excitation_port_ids']==manifests[1]['excitation_port_ids']
assert all(m['phasor_convention']=='exp(-i omega t)' for m in manifests)
for name in ('design','sources','driver_revisions'):
    assert json.loads((old/'candidate.json').read_text())[name]==json.loads((new/'candidate.json').read_text())[name]
domains=[json.loads(_contained(p,m['domains_metadata_file']).read_text())['domains'] for p,m in zip(raws,manifests)]
rows=[]
for index,frequency in enumerate(manifests[0]['frequencies_hz']):
    metadata=[json.loads(_contained(p,m['results'][index]['metadata_file']).read_text()) for p,m in zip(raws,manifests)]
    assert all(v['diagnostics']['transducer_reference_voltage_v']==2.83 for v in metadata)
    for label in ('horizontal-polar','vertical-polar','sphere'):
        quantities=[next(q for q in v['quantities'] if q['id']=='acoustic:pressure:'+label) for v in metadata]
        selected=[next(d for d in items if d['id']=='observation:'+label) for items in domains]
        for coordinate in selected[0]['coordinates']:
            with np.load(_contained(raws[0],manifests[0]['domains_file'])) as a,np.load(_contained(raws[1],manifests[1]['domains_file'])) as b:
                assert np.array_equal(a[selected[0]['coordinates'][coordinate]],b[selected[1]['coordinates'][coordinate]])
        values=[]
        for p,m,q in zip(raws,manifests,quantities):
            with np.load(_contained(p,m['results'][index]['arrays_file'])) as a:
                values.append(a[q['key']].copy())
        assert values[0].dtype==np.dtype('complex64') and values[1].dtype==np.dtype('complex128')
        rows.append({'frequency_hz':frequency,'observation':label,
            **compare(values[1],values[0],relative_null_floor=.001)})
report={'application_source_commit':'9ee5b03','native_source_commits':['1187c25','9ee5b03'],
    'script_sha256':sha256(Path(__file__)),'byte_identical_mesh_sha256':meshes[0],
    'same_observation_coordinates':True,'same_physical_sources':True,
    'relative_null_floor_per_excitation':.001,'DSP_applied':False,'fitted_gain_or_phase':False,
    'definition':'FP32 minus FP64 native full voltage-basis pressure; FP64 is the numerical reference',
    'rows':rows,'electrical_checks':{'FP32':identities[0]['checks'],'FP64':identities[1]['checks']},
    'physical_validation':False,'mesh_convergence':False,
    'limitations':['Four frequencies and synthetic drivers do not validate the user horn',
        'Precision sensitivity on identical meshes, not mesh convergence or physical accuracy',
        'Relative complex matrix norm retains all samples; magnitude/phase excludes declared relative nulls']}
assert [verified_assessment(p/'system/project.blab.json',p/'evaluation') for p in (old,new)]==identities
(root/'runs/reference-backend-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
