"""Small native FP64 integration campaign; synthetic freeform five-driver ring."""
from pathlib import Path
import json
from meh_studio.boundary_lab import BoundaryLabRuntime,sha256
from meh_studio.catalogue import Catalogue
from meh_studio.domain import DriverRevision
from meh_studio.geometry import HornGeometry
from meh_studio.optimisation import SearchBrief,candidates,optimise
from meh_studio.build_bundle import export_search
from meh_studio.search_results import load_completed_search

root=Path.cwd();prior=root/'runs/eccentric-sphere-search-v3'
saved=json.loads((prior/'trial-000/candidate.json').read_text())
base=HornGeometry.model_validate(saved['design'])
drivers=[DriverRevision.model_validate(d) for d in saved['driver_revisions']]
data=json.loads((prior/'brief.json').read_text())
data.update(trial_budget=2,seed=20260912)
brief=SearchBrief.model_validate(data)
rows=candidates(brief,base,drivers)
assert rows[0]['design'].content_hash==base.content_hash
assert brief.acoustic_objectives.minimum_bank_impedance_ohm is None
native=root/'runs/runtime';database=root/'runs/reference-backend-search.sqlite'
output=root/'runs/reference-backend-search'
with Catalogue.create(database) as catalogue:
    for driver in drivers:catalogue.add(driver)
runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',
    native/'julia-1.12.6/bin/julia','coupled_reference',julia_threads=2)
result=optimise(brief,base,database,runtime,output,solver_stage_timeout_s=1800)
provenance={'application_source_commit':'9ee5b03','source_worktree':'runs/reference-backend-source',
    'reference_candidate_sha256':sha256(prior/'trial-000/candidate.json'),
    'status':'completed_FP64_workflow_diagnostic','qualification':False,
    'previous_input_check': 'v1 omitted the 350 Hz high-pass sample and was rejected before output/database creation',
    'limitations':['Synthetic sources, four diagnostic frequencies; not the user target horn',
        'The 2-ohm screen is explicitly disabled for these synthetic source circuits',
        'No mesh convergence, physical source or print qualification',
        'FP64 storage permits strict electrical checks, but their actual results must still be inspected']}
(output/'experiment-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
verified=load_completed_search(output)
bundle=export_search(output,root/'runs/reference-backend-winner.zip')
(output/'export-verification.json').write_text(json.dumps(bundle,indent=2)+'\n')
print(json.dumps({'search':result,'export':bundle,'provenance':provenance},indent=2))
