"""Predeclare a two-candidate screening-mesh comparison against completed fields."""
from pathlib import Path
import argparse
import json
import subprocess
import time
from meh_studio.boundary_lab import BoundaryLabRuntime, SolveRequest, sha256
from meh_studio.geometry import HornGeometry, export_geometry, mesh_geometry
from meh_studio.generated_system import HornSources
from meh_studio.optimisation import SearchBrief, response_score, verified_assessment
from meh_studio.radiating_system import compile_radiating_system
from meh_studio.radiation_geometry import surface_integrity

root = Path.cwd(); runs = root / 'runs'
parser = argparse.ArgumentParser(); parser.add_argument('--prepare', action='store_true'); args = parser.parse_args()
source = runs / 'quadrature-source'
commit = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
assert commit == '852a5a33af9617ac3a40f9956ca12f744e3d0ba8'
assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'], text=True)
import meh_studio.geometry
assert Path(meh_studio.geometry.__file__).resolve().is_relative_to(source)
original = runs / 'quarter-turn-vocal-search'
brief = SearchBrief.model_validate_json((original / 'brief.json').read_text())
assert json.loads((original / 'search.json').read_text())['status'] == 'complete'
cases = []
for index in (0, 2):
    folder = original / f'trial-{index:03d}'
    candidate = json.loads((folder / 'candidate.json').read_text())
    geometry = json.loads((folder / 'geometry/geometry.json').read_text())
    design = HornGeometry.model_validate(candidate['design'] | {'mesh_size_m': .016})
    assert {k: v for k, v in design.model_dump(mode='json').items() if k != 'mesh_size_m'} == {k: v for k, v in candidate['design'].items() if k != 'mesh_size_m'}
    score = response_score(folder / 'system/project.blab.json', folder / 'evaluation', brief.side_gains, brief.acoustic_objectives)
    cases.append({'index': index, 'candidate_sha256': sha256(folder / 'candidate.json'),
                  'geometry_manifest_sha256': sha256(folder / 'geometry/geometry.json'),
                  'fine_evidence': verified_assessment(folder / 'system/project.blab.json', folder / 'evaluation'),
                  'fine_score': score, 'design': design.model_dump(mode='json'),
                  'sources': candidate['sources'], 'fine_volumes': geometry['air_volume_m3'],
                  'fine_material_volume_m3': geometry['material_volume_m3'], 'fine_source_locations': geometry['sources']})
controls = {'application_source_commit': commit, 'fine_source_commit': 'ab6714f',
            'runner_sha256': sha256(Path(__file__)), 'brief_sha256': sha256(original / 'brief.json'),
            'cases': cases, 'frequencies_hz': list(brief.frequencies_hz),
            'coarse_interior_mesh_size_m': .016, 'coarse_exterior_mesh_size_m': .02,
            'maximum_coarse_exterior_triangles': 5000,
            'maximum_coarse_total_tetrahedra': 500000,
            'unchanged_cad_volume_relative_limit': 1e-6,
            'score_absolute_difference_limit_db': .5,
            'common_observation_or_transducer_relative_l2_limit': .1,
            'ranking_rule': 'Both completed candidates must preserve the ordering of the original acoustic objectives; ties fail the ranking screen',
            'backend': 'beat_cpu', 'julia_threads': 2, 'solver_timeout_s': 3600,
            'original_preparation_failure_controls_sha256': sha256(runs / 'coarse-screening-controls.json'),
            'qualified': False,
            'limitations': ['Two retrospectively selected synthetic-HF candidates cannot establish general ranking reliability',
                           'Interior and exterior mesh targets both change; source geometry and physical parameters do not',
                           'Fine reference uses ab6714f and coarse preparation uses 852a5a3, including later mouth-conforming preservation fixes; this assesses the current screening pipeline against the retained reference and does not isolate mesh-size effects alone',
                           'Existing source-area, topology and volume gates remain unchanged',
                           'Complex64 screening does not establish the separate 1e-8 electrical gate',
                           'Passing screening agreement would not qualify a horn; finalists still need independent finer-mesh and held-out checks']}
control_path = runs / 'coarse-screening-verified-controls.json'
if args.prepare:
    with control_path.open('x') as stream: stream.write(json.dumps(controls, indent=2) + '\n')
    print(json.dumps({'controls_sha256': sha256(control_path), 'candidate_indices': [c['index'] for c in cases]}, indent=2))
    raise SystemExit
assert json.loads(control_path.read_text()) == controls
output = runs / 'coarse-screening-verified'; output.mkdir(exist_ok=False)
native = runs / 'runtime'
runtime = BoundaryLabRuntime(native / 'boundary-lab', native / 'blab-env/bin/python',
                             native / 'julia-1.12.6/bin/julia', 'beat_cpu', julia_threads=2)
rows = []
for case in cases:
    folder = output / f"trial-{case['index']:03d}"; folder.mkdir()
    row = {'index': case['index'], 'status': 'running'}; start = time.monotonic()
    try:
        geometry = export_geometry(HornGeometry.model_validate(case['design']), folder / 'geometry')
        assert geometry['sources'] == case['fine_source_locations']
        for name, volume in case['fine_volumes'].items():
            assert abs(geometry['air_volume_m3'][name] / volume - 1) <= 1e-6
        assert geometry['material_volume_m3'].keys() == case['fine_material_volume_m3'].keys()
        for name, volume in case['fine_material_volume_m3'].items():
            assert abs(geometry['material_volume_m3'][name] / volume - 1) <= 1e-6
        mesh = mesh_geometry(folder / 'geometry')
        total = sum(r['tetrahedra'] for r in mesh['regions'])
        row['total_tetrahedra'] = total
        assert total <= controls['maximum_coarse_total_tetrahedra'], 'coarse diagnostic exceeds concurrent-workload budget'
        compile_radiating_system(folder / 'geometry', HornSources.model_validate(case['sources']), folder / 'system', runtime,
                                 exterior_mesh_size_m=.02, observation_distance_m=20., sphere_angle_deg=10.)
        integrity = surface_integrity(folder / 'system/meshes/exterior.msh', maximum_triangles=32000)
        row['exterior_surface'] = integrity
        assert integrity['triangles'] <= controls['maximum_coarse_exterior_triangles'], 'coarse diagnostic exceeds concurrent BEM budget'
        request = SolveRequest(frequencies_hz=brief.frequencies_hz, include_project_observations=True,
                               retain=('fem_nodal_pressure', 'bem_boundary_traces'))
        solve_start = time.monotonic()
        runtime.solve(folder / 'system/project.blab.json', request, folder / 'evaluation', timeout_s=3600)
        row['native_stage_wall_s'] = time.monotonic() - solve_start
        row.update(status='complete', evidence=verified_assessment(folder / 'system/project.blab.json', folder / 'evaluation'),
                   score=response_score(folder / 'system/project.blab.json', folder / 'evaluation', brief.side_gains, brief.acoustic_objectives))
    except Exception as exc:
        row.update(status='failed', error=f'{type(exc).__name__}: {exc}')
    row['total_wall_s'] = time.monotonic() - start; rows.append(row)
    (output / 'progress.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(json.dumps({k: v for k, v in row.items() if k not in ('evidence', 'score')}), flush=True)
for case in cases:
    folder = original / f"trial-{case['index']:03d}"
    assert verified_assessment(folder / 'system/project.blab.json', folder / 'evaluation') == case['fine_evidence']
with (output / 'run-summary.json').open('x') as stream:
    stream.write(json.dumps({'controls_sha256': sha256(control_path), 'rows': rows}, indent=2) + '\n')
