"""Assess declared screening accuracy and ranking; preserve failed preparations."""
from pathlib import Path
import json
import numpy as np
from meh_studio.boundary_lab import _contained, sha256
from meh_studio.optimisation import verified_assessment

root = Path.cwd(); runs = root / 'runs'; folder = runs / 'coarse-screening-study'
control_path = runs / 'coarse-screening-controls.json'
controls = json.loads(control_path.read_text())
assert controls['runner_sha256'] == sha256(runs / 'run-coarse-screening-study.py')
summary = json.loads((folder / 'run-summary.json').read_text())
assert summary['controls_sha256'] == sha256(control_path)
assert [r['index'] for r in summary['rows']] == [c['index'] for c in controls['cases']]

def compare_fields(coarse, fine):
    roots = [p / 'upstream' for p in (coarse, fine)]
    manifests = [json.loads((p / 'manifest.json').read_text()) for p in roots]
    assert manifests[0]['frequencies_hz'] == manifests[1]['frequencies_hz'] == controls['frequencies_hz']
    assert manifests[0]['excitation_port_ids'] == manifests[1]['excitation_port_ids']
    domains = [{d['id']: d for d in json.loads(_contained(p, m['domains_metadata_file']).read_text())['domains']}
               for p, m in zip(roots, manifests, strict=True)]
    with np.load(_contained(roots[0], manifests[0]['domains_file']), allow_pickle=False) as a, np.load(_contained(roots[1], manifests[1]['domains_file']), allow_pickle=False) as b:
        for key, domain in domains[0].items():
            if not key.startswith('observation:'): continue
            other = domains[1][key]
            assert domain['coordinates'].keys() == other['coordinates'].keys()
            for name, array_key in domain['coordinates'].items():
                assert np.array_equal(a[array_key], b[other['coordinates'][name]])
    rows = []
    for ar, br in zip(manifests[0]['results'], manifests[1]['results'], strict=True):
        assert ar['freq_hz'] == br['freq_hz']
        metas = [json.loads(_contained(p, r['metadata_file']).read_text()) for p, r in zip(roots, (ar, br), strict=True)]
        quantities = [{q['id']: q for q in m['quantities'] if q['axes'] in (['excitation', 'transducer'], ['excitation', 'observation'])} for m in metas]
        assert quantities[0].keys() == quantities[1].keys()
        with np.load(_contained(roots[0], ar['arrays_file']), allow_pickle=False) as a, np.load(_contained(roots[1], br['arrays_file']), allow_pickle=False) as b:
            for key, aq in quantities[0].items():
                bq = quantities[1][key]; assert aq == bq
                av, bv = a[aq['key']], b[bq['key']]
                assert av.shape == bv.shape and av.dtype == bv.dtype == np.complex64
                for i, excitation in enumerate(manifests[0]['excitation_port_ids']):
                    # Accumulate the comparison in FP64; keep original FP32 fields.
                    delta = float(np.linalg.norm(av[i].astype(complex) - bv[i].astype(complex)))
                    norm = float(np.linalg.norm(bv[i].astype(complex)))
                    relative = delta / norm if norm else (0. if delta == 0 else None)
                    rows.append({'frequency_hz': ar['freq_hz'], 'quantity': key, 'excitation': excitation, 'relative_l2': relative})
    maximum = max(r['relative_l2'] for r in rows) if all(r['relative_l2'] is not None for r in rows) else None
    limit = controls['common_observation_or_transducer_relative_l2_limit']
    return {'rows': rows, 'maximum_relative_l2': maximum, 'limit': limit, 'passed': maximum is not None and maximum <= limit}

rows = []
for case, run in zip(controls['cases'], summary['rows'], strict=True):
    fine = runs / 'quarter-turn-vocal-search' / f"trial-{case['index']:03d}"
    assert verified_assessment(fine / 'system/project.blab.json', fine / 'evaluation') == case['fine_evidence']
    assert sha256(fine / 'candidate.json') == case['candidate_sha256']
    record = {'index': case['index'], 'status': run['status'], 'run': run}
    if run['status'] == 'complete':
        coarse = folder / f"trial-{case['index']:03d}"
        assert verified_assessment(coarse / 'system/project.blab.json', coarse / 'evaluation') == run['evidence']
        score_difference = {k: run['score'][k] - case['fine_score'][k] for k in ('ripple_db', 'directivity_error_db', 'acoustic_objective')}
        record.update(score_difference_db=score_difference,
                      score_screen_passed=all(abs(v) <= controls['score_absolute_difference_limit_db'] for v in score_difference.values()),
                      fields=compare_fields(coarse / 'evaluation', fine / 'evaluation'))
    rows.append(record)
complete = all(r['status'] == 'complete' for r in rows)
ranking_passed = False
if complete:
    fine_difference = controls['cases'][0]['fine_score']['acoustic_objective'] - controls['cases'][1]['fine_score']['acoustic_objective']
    coarse_difference = rows[0]['run']['score']['acoustic_objective'] - rows[1]['run']['score']['acoustic_objective']
    ranking_passed = fine_difference * coarse_difference > 0
report = {'controls_sha256': sha256(control_path), 'postprocessor_sha256': sha256(Path(__file__)),
          'application_source_commit': controls['application_source_commit'], 'rows': rows,
          'ranking_screen_passed': ranking_passed,
          'screening_study_passed': complete and ranking_passed and all(r['score_screen_passed'] and r['fields']['passed'] for r in rows),
          'qualified': False, 'limitations': controls['limitations']}
with (folder / 'comparison.json').open('x') as stream: stream.write(json.dumps(report, indent=2) + '\n')
print(json.dumps({'ranking_screen_passed': ranking_passed, 'screening_study_passed': report['screening_study_passed'],
                  'rows': [{k: v for k, v in r.items() if k not in ('run', 'fields')} | ({'field_maximum_relative_l2': r['fields']['maximum_relative_l2']} if 'fields' in r else {'error': r['run'].get('error')}) for r in rows]}, indent=2))
