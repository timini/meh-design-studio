"""Preserve the failed first preparation and the completed screening assessment."""
from pathlib import Path
import json
import zipfile
from meh_studio.boundary_lab import sha256
from meh_studio.optimisation import verified_assessment
from meh_studio.search_results import load_completed_search

root = Path.cwd(); runs = root / 'runs'; original = runs / 'coarse-screening-study'; current = runs / 'coarse-screening-verified'
controls = json.loads((runs / 'coarse-screening-verified-controls.json').read_text())
comparison = json.loads((current / 'comparison.json').read_text())
old_comparison = json.loads((original / 'comparison.json').read_text())
assert all(r['status'] == 'failed' for r in old_comparison['rows'])
assert controls['original_preparation_failure_controls_sha256'] == sha256(runs / 'coarse-screening-controls.json')
assert controls['runner_sha256'] == sha256(runs / 'run-coarse-screening-verified.py')
assert comparison['controls_sha256'] == sha256(runs / 'coarse-screening-verified-controls.json')
assert comparison['postprocessor_sha256'] == sha256(runs / 'finish-coarse-screening-verified.py')
assert old_comparison['postprocessor_sha256'] == sha256(runs / 'finish-coarse-screening-study.py')
fine_hashes, *_ = load_completed_search(runs / 'quarter-turn-vocal-search')
for row in comparison['rows']:
    if row['status'] == 'complete':
        folder = current / f"trial-{row['index']:03d}"
        assert row['run']['evidence'] == verified_assessment(folder / 'system/project.blab.json', folder / 'evaluation')
fine_archive_root = root / 'validation/evidence/quarter-turn-vocal-search'
fine_report = json.loads((fine_archive_root / 'report.json').read_text())
for item in fine_report['archives']: assert sha256(fine_archive_root / item['file']) == item['sha256']
paths = sorted(p for directory in (original, current) for p in directory.rglob('*') if p.is_file())
paths += [runs / name for name in ('run-coarse-screening-study.py', 'coarse-screening-controls.json',
          'coarse-screening-study.log', 'finish-coarse-screening-study.py', 'coarse-screening-comparison.log',
          'run-coarse-screening-verified.py', 'coarse-screening-verified-controls.json', 'coarse-screening-verified.log',
          'finish-coarse-screening-verified.py', 'coarse-screening-verified-comparison.log', 'archive-coarse-screening-study.py')]
inventory = {str(p.relative_to(runs)): sha256(p) for p in paths}
groups = []; pending = []; size = 0
for path in paths:
    n = path.stat().st_size; assert n < 90_000_000
    if pending and size + n > 75_000_000:
        groups.append(pending); pending = []; size = 0
    pending.append(path); size += n
if pending: groups.append(pending)
target = root / 'validation/evidence/coarse-screening'; target.mkdir(parents=True, exist_ok=False)
archives = []
for index, files in enumerate(groups):
    archive_path = target / f'evidence-{index:02d}.zip'
    with zipfile.ZipFile(archive_path, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in files: archive.write(path, str(path.relative_to(runs)))
    assert archive_path.stat().st_size < 100_000_000
    with zipfile.ZipFile(archive_path) as archive: assert archive.testzip() is None
    archives.append({'file': archive_path.name, 'size_bytes': archive_path.stat().st_size, 'sha256': sha256(archive_path)})
assert inventory == {str(p.relative_to(runs)): sha256(p) for p in paths}
assert load_completed_search(runs / 'quarter-turn-vocal-search')[0] == fine_hashes
report = {'status': 'complete_screening_pipeline_comparison',
          'application_source_commit': controls['application_source_commit'], 'fine_source_commit': controls['fine_source_commit'],
          'comparison': comparison, 'original_preparation_failure': old_comparison,
          'fine_reference': {'report': '../quarter-turn-vocal-search/report.json',
                             'report_sha256': sha256(fine_archive_root / 'report.json'), 'archives': fine_report['archives']},
          'archives': archives, 'archived_file_sha256': inventory,
          'qualified': False, 'physical_validation': False, 'limitations': controls['limitations']}
(target / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'screening_study_passed': comparison['screening_study_passed'], 'archives': archives}, indent=2))
