from pathlib import Path
import json,zipfile
from meh_studio.boundary_lab import sha256
root=Path.cwd();out=root/'validation/evidence/whole-sphere-reference';out.mkdir(parents=True,exist_ok=False)
archive=out/'raw-run.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name in ('sphere-whole-reference','sphere-whole-evaluation'):
  for p in sorted((root/'runs'/name).rglob('*')):
   if p.is_file():z.write(p,str(Path(name)/p.relative_to(root/'runs'/name)))
 for name in ('generate_pulsating_sphere.py','compare_pulsating_sphere.py'):
  z.write(root/'runs/full-sphere-source/validation/fixtures'/name,'runners/'+name)
 for name in ('solve-sphere-whole.py','archive-sphere-whole.py'):
  z.write(root/'runs'/name,'runners/'+name)
report=json.loads((root/'runs/sphere-whole-report.json').read_text());report.update(application_source_commit='952e0e6',source_scope='Native adapter, generator and comparator from clean detached application source; exact runners and raw outputs archived',raw_archive={'file':archive.name,'sha256':sha256(archive),'size_bytes':archive.stat().st_size})
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(report['raw_archive'])
