"""Whole-sphere analytical reference; application source frozen at 952e0e6."""
from pathlib import Path
from meh_studio.boundary_lab import BoundaryLabRuntime,SolveRequest
root=Path.cwd();native=root/'runs/runtime'
runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',native/'julia-1.12.6/bin/julia',julia_threads=1)
runtime.solve(root/'runs/sphere-whole-reference/project.blab.json',SolveRequest(frequencies_hz=(350.,2000.,5000.,7500.),include_project_observations=True,retain=('bem_boundary_traces',)),root/'runs/sphere-whole-evaluation',timeout_s=900)
