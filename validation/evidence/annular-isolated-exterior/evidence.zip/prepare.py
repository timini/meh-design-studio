from pathlib import Path
import json,hashlib,shutil
import numpy as np
import meshio
from meh_studio.radiation_geometry import surface_integrity,verify_exterior_groups
root=Path(__file__).resolve().parent
base=root.parent/'annular-fixed-mesh-quadrature'
shutil.copytree(base/'system',root/'system')
# Retain parent compilation separately, not as a compilation of this derived input.
(root/'parent-input').mkdir()
(root/'system/compilation.json').rename(root/'parent-input/compilation.json')
source=base/'system/meshes/exterior.msh';dest=root/'system/meshes/exterior.msh'
m=meshio.read(source);points=m.points.tolist();faces=[];physical=[];geometrical=[]
for cell,tags,entities in zip(m.cells,m.cell_data['gmsh:physical'],m.cell_data['gmsh:geometrical']):
 assert cell.type=='triangle'
 for face,tag,entity in zip(cell.data,tags,entities):
  if tag==10:
   faces.append(face.tolist());physical.append(int(tag));geometrical.append(int(entity))
  else:
   assert tag==99
   centre=np.mean(m.points[face],axis=0);index=len(points);points.append(centre.tolist())
   for a,b in zip(face,np.roll(face,-1)):
    faces.append([int(a),int(b),index]);physical.append(int(tag));geometrical.append(int(entity))
meshio.write(dest,meshio.Mesh(np.array(points),[('triangle',np.array(faces))],cell_data={'gmsh:physical':[np.array(physical)],'gmsh:geometrical':[np.array(geometrical)]},field_data=m.field_data),file_format='gmsh22',binary=False)
verify_exterior_groups(dest,root/'system/meshes/front.msh')
a=surface_integrity(source,symmetry='xy');b=surface_integrity(dest,maximum_triangles=10000,symmetry='xy')
assert abs(a['enclosed_volume_m3']-b['enclosed_volume_m3'])/a['enclosed_volume_m3']<1e-12
project=root/'system/project.blab.json';p=json.loads(project.read_text());p['physical_system']['metadata']['generated_mesh_sha256']['mesh:exterior']=hashlib.sha256(dest.read_bytes()).hexdigest();project.write_text(json.dumps(p,indent=2)+'\n')
for mesh in p['physical_system']['meshes']:
 data=(root/'system'/mesh['file']).read_bytes()
 assert hashlib.sha256(data).hexdigest()==p['physical_system']['metadata']['generated_mesh_sha256'][mesh['id']]
 if mesh['id']!='mesh:exterior':assert data==(base/'system'/mesh['file']).read_bytes()
shutil.copyfile(base/'request-baseline.json',root/'request.json')
report={'source_commit':'a31597a8c320dd751d19e2d0bb625edc0d962a7e','operation':'Three coplanar centroid subtriangles per rigid exterior facet; mouth facets, original edges and every FEM mesh unchanged.','parent_surface':a,'derived_surface':b,'qualified':False,'limitations':['Fixed geometric surface enrichment, not CAD curvature convergence.','Original edges and mouth are not refined, so this is a limited rigid-surface basis sensitivity diagnostic.','No native evaluation yet.']}
(root/'preparation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
