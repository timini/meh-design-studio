import json
from pathlib import Path
from meh_studio.boundary_lab import BoundaryLabRuntime
from meh_studio.optimisation import SearchBrief,optimise
from meh_studio.geometry import HornGeometry
from meh_studio.catalogue import Catalogue
from meh_studio.domain import DriverRevision
root=Path.cwd();source=root/'runs/adaptive-source';native=root/'runs/runtime'
data=json.loads((source/'examples/synthetic-compact-search-brief.json').read_text())
data.update(frequencies_hz=[1000,2000,3000],trial_budget=4,entry_fractions=[[.45]],
    evolution={'elite_size':1,'explore_every':3,'geometry_bounds':{'length_m':[.12,.14],'entry_fraction_0':[.36,.5]}})
brief=SearchBrief.model_validate(data)
base=HornGeometry.model_validate_json((source/'examples/freeform-ring-geometry.json').read_text())
db=root/'runs/adaptive-drivers.sqlite'
with Catalogue.create(db) as catalogue:
 for value in json.loads((source/'examples/synthetic-search-drivers.json').read_text()):catalogue.add(DriverRevision.model_validate(value))
runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',native/'julia-1.12.6/bin/julia',julia_threads=1)
result=optimise(brief,base,db,runtime,root/'runs/adaptive-first')
print(json.dumps(result,indent=2))
