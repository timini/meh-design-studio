"""Preserve the failed and compacted ground-reference experiments."""
from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();runs=root/'runs';failed=runs/'cram-ground-reference';complete=runs/'cram-ground-compact-reference'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
comparison=json.loads((complete/'comparison.json').read_text())
assert comparison['status']=='complete_conditional_comparison'
assert json.loads((failed/'evaluation/evaluation.json').read_text())['status']=='failed'
assert json.loads((complete/'evaluation/evaluation.json').read_text())['status']=='complete'
assert not any(json.loads((failed/'evaluation/upstream/manifest.json').read_text())['completion_mask'])
controls=json.loads((runs/'cram-ground-compact-reference-controls.json').read_text())
assert digest(runs/'cram-ground-compact-reference-controls.json')==comparison['controls_sha256']
assert controls['removed_unused_bem_vertices']==62
paths=[p for directory in (failed,complete) for p in directory.rglob('*') if p.is_file()]
paths += [runs/name for name in ('run-cram-ground-reference.py','finish-cram-ground-reference.py','cram-ground-reference-controls.json',
 'cram-ground-reference-prepare.log','cram-ground-reference-native.log','run-cram-ground-compact-reference.py',
 'finish-cram-ground-compact-reference.py','cram-ground-compact-reference-controls.json','cram-ground-compact-reference-prepare.log',
 'cram-ground-compact-reference-native.log','cram-ground-compact-reference-comparison.log','archive-cram-ground-reference.py')]
paths=sorted(set(paths));ids={p.relative_to(runs).as_posix():digest(p) for p in paths}
out=root/'validation/evidence/cram-ground-reference';out.mkdir(exist_ok=False);archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in paths:z.write(p,p.relative_to(runs).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,sha in ids.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha
assert ids=={p.relative_to(runs).as_posix():digest(p) for p in paths}
assert archive.stat().st_size<100000000
baseline=root/'validation/evidence/measured-cram-reference/report.json'
report={'status':'complete','scope':'Rigid-ground and zero-height microphone hypothesis for the supplied low-frequency CRAM reference; includes initial singular-matrix failure and compacted retry.',
 'application_source_commit':controls['application_source_commit'],
 'archives':[{'file':'evidence.zip','size_bytes':archive.stat().st_size,'sha256':digest(archive)}],
 'archived_file_sha256':ids,'original_reference_report':str(baseline.relative_to(root)),'original_reference_report_sha256':digest(baseline),
 'removed_rigid_ground_facets':133,'removed_unused_bem_vertices':62,'final_bem_triangles':1905,'total_tetrahedra':81691,
 'heldout_maximum_absolute_error_db':comparison['heldout_maximum_absolute_error_db'],
 'heldout_rms_error_db':comparison['heldout_rms_error_db'],'level_offset_db':comparison['level_offset_db'],
 'conditional_shape_screen_passed':comparison['conditional_shape_screen_passed'],
 'electrical_validation_passed':comparison['source_evidence']['checks']['passed'],
 'maximum_electrical_reciprocity_residual':max(r['electrical_reciprocity_relative_residual'] for r in comparison['source_evidence']['checks']['rows']),
 'qualified':False,'physical_validation':False,'limitations':controls['limitations']}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'archives':report['archives'],'files':len(paths),'heldout_maximum_absolute_error_db':report['heldout_maximum_absolute_error_db']},indent=2))
