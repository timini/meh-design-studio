"""Ground-plane image-model check of the public CRAM measured reference.

No driver, damping, geometry-size or frequency-dependent fitting. The added Y
reflection represents rigid ground; its image coils are not purchased drivers.
"""
from pathlib import Path
import argparse,json,shutil,subprocess
import numpy as np
import meshio
from meh_studio.boundary_lab import BoundaryLabRuntime,SolveRequest,sha256
root=Path.cwd();runs=root/'runs';native=runs/'runtime';source=runs/'focused-entry-source'
p=argparse.ArgumentParser();p.add_argument('--prepare',action='store_true');args=p.parse_args()
commit=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip();assert commit=='93344da6eb9f944541be07c979f9f6d721414169'
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True)
example=native/'boundary-lab/examples/2x12_CRAM';out=runs/'cram-ground-reference';cp=runs/'cram-ground-reference-controls.json'
if args.prepare:
 out.mkdir(exist_ok=False);folder=out/'project';folder.mkdir()
 old_control=runs/'cram-measured-reference-verified-controls.json';prior=json.loads(old_control.read_text())
 names=list(prior['original_file_sha256'])
 for name in names:
  target=folder/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(example/name,target)
  assert sha256(target)==prior['original_file_sha256'][name]
 project=json.loads((example/'2x12_CRAM.blab.json').read_text())
 assert project['symmetry']=='x'
 path=example/'2x12CRAMExterior_interface_conformed.msh';mesh=meshio.read(path)
 assert len(mesh.cells)==1 and mesh.cells[0].type=='triangle'
 triangles=mesh.cells[0].data;ground=float(mesh.points[:,1].min());front=float(mesh.points[:,2].max())
 assert abs(ground+213.2)<1e-8 and abs(front-13.)<1e-8
 plane=np.max(abs(mesh.points[triangles,1]-ground),axis=1)<1e-7
 assert int(plane.sum())==133
 assert np.array_equal(np.unique(mesh.cell_data['gmsh:physical'][0][plane]),[1])
 # Preserve every non-ground facet's coordinates, connectivity and physical tag.
 masked=meshio.Mesh(mesh.points.copy(),[('triangle',triangles[~plane].copy())],
  cell_data={name:[values[0][~plane].copy()] for name,values in mesh.cell_data.items()},field_data=mesh.field_data)
 target=folder/'ground-exterior.msh';meshio.write(target,masked,file_format='gmsh22',binary=False)
 check=meshio.read(target);assert np.array_equal(check.points,mesh.points)
 assert np.array_equal(check.cells[0].data,triangles[~plane])
 assert np.array_equal(check.cell_data['gmsh:physical'][0],mesh.cell_data['gmsh:physical'][0][~plane])
 project['symmetry']='xy'
 project['project_preferences'].update(spherical_sampling_enabled=False,polar_angle_step_deg=15.,polar_observation_distance_m=10.)
 for resource in project['physical_system']['meshes']:
  assert resource['scale_to_m']==.001 and resource['translation_m']==[0.,0.,0.]
  resource['translation_m']=[0.,-ground*.001,-front*.001]
  if resource['purpose']=='bem_surface':resource['file']=target.name
  actual=meshio.read(folder/resource['file']).points*.001+np.asarray(resource['translation_m'])
  assert actual[:,0].min()>-1e-9 and actual[:,1].min()>-1e-9
 for component in project['physical_system']['components']:
  params=component['parameters'];assert params['surface_completion_factor']==2 and params['physical_driver_orbit_count']==1
  params['physical_driver_orbit_count']=2
 project['physical_system']['metadata']['ground_reference']={'plane':'y=0','condition':'infinite rigid Neumann plane',
  'real_physical_coils':2,'native_geometric_image_coils':4,'meaning':'Y images enforce the ground boundary, not additional real drivers.'}
 project_path=folder/'reference.blab.json';project_path.write_text(json.dumps(project,indent=2)+'\n')
 controls={'application_source_commit':commit,'runner_sha256':sha256(Path(__file__)),
  'upstream_revision':'8cb166226e412877d3f71f2845918e479b97aa85','baseline_controls_sha256':sha256(old_control),
  'baseline_comparison_sha256':sha256(runs/'cram-measured-reference-verified/comparison.json'),
  'original_file_sha256':prior['original_file_sha256'],'project':project,'project_sha256':sha256(project_path),
  'ground_exterior_sha256':sha256(target),'removed_rigid_ground_facets':int(plane.sum()),'remaining_bem_triangles':int((~plane).sum()),
  'translation_m':[0.,-ground*.001,-front*.001],
  'source':{'measurement_notes':'https://github.com/JWSound/boundary-lab/blob/8cb166226e412877d3f71f2845918e479b97aa85/examples/2x12_CRAM/Measured/info.txt',
   'rigid_plane_method':'https://doc.comsol.com/6.3/doc/com.comsol.help.aco/aco_ug_pressure.05.078.html'},
  'frequencies_hz':prior['frequencies_hz'],'calibration_frequencies_hz':prior['calibration_frequencies_hz'],
  'heldout_frequencies_hz':prior['heldout_frequencies_hz'],'calibration':prior['calibration'],
  'heldout_maximum_absolute_error_limit_db':3.,'electrical_relative_limit':1e-8,
  'measurement_interpolation':prior['measurement_interpolation'],'prediction_drive':'Both real drivers and their rigid-ground images share coherent 1 V; sum the two native 2.83 V excitation bases divided by 2.83. No multiplication by image coil count.',
  'native_backend':'coupled_reference','julia_threads':2,'timeout_s':1800,
  'qualified':False,'physical_validation':False,'limitations':[
   'Ground is assumed perfectly rigid and the cabinet upright on its minimum-Y base; notes do not specify floor impedance, exact pose, feet or microphone capsule height.',
   'Microphone is taken on the ground plane 10m ahead of the maximum-Z cabinet front; this is an explicit reference-condition hypothesis.',
   'Only the on-ground on-axis observation is compared; negative-Y polar points are mathematical image extensions, not physical below-ground observations.',
   'Added Y-image coils represent a boundary condition, not extra real drivers, amp channels or hardware cost.',
   'Original mesh, dry-mass circuits, air properties and bulk losses are unchanged; their own numerical/source uncertainty remains.',
   'Earlier free-space heldout failure remains failed. Nine frequencies, uncalibrated voltage and absent timing/build traceability do not qualify absolute SPL, phase or the target MEH.']}
 with cp.open('x') as f:f.write(json.dumps(controls,indent=2)+'\n')
 print(json.dumps({'controls_sha256':sha256(cp),'remaining_bem_triangles':controls['remaining_bem_triangles'],'translation_m':controls['translation_m']},indent=2));raise SystemExit
controls=json.loads(cp.read_text());assert controls['runner_sha256']==sha256(Path(__file__)) and controls['application_source_commit']==commit
folder=out/'project';project_path=folder/'reference.blab.json';assert sha256(project_path)==controls['project_sha256']
assert sha256(folder/'ground-exterior.msh')==controls['ground_exterior_sha256']
for name,digest in controls['original_file_sha256'].items():assert sha256(folder/name)==digest and sha256(example/name)==digest
request=SolveRequest(frequencies_hz=tuple(controls['frequencies_hz']),include_project_observations=True,retain=('bem_boundary_traces','fem_nodal_pressure'))
runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',native/'julia-1.12.6/bin/julia','coupled_reference',julia_threads=2)
result=runtime.solve(project_path,request,out/'evaluation',timeout_s=controls['timeout_s'])
print(json.dumps({'status':result['status'],'controls_sha256':sha256(cp)},indent=2))
