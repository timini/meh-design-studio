"""Archive actual fixed-mesh integration results and the unchanged reference."""
from pathlib import Path
import json
import zipfile
from meh_studio.boundary_lab import sha256
from meh_studio.optimisation import verified_assessment

root = Path.cwd(); runs = root / 'runs'; folder = runs / 'cram-quadrature-study'
controls = json.loads((runs / 'cram-quadrature-controls.json').read_text())
comparison = json.loads((folder / 'comparison.json').read_text())
assert comparison['controls_sha256'] == sha256(runs / 'cram-quadrature-controls.json')
assert comparison['postprocessor_sha256'] == sha256(runs / 'finish-cram-quadrature-study.py')
assert controls['runner_sha256'] == sha256(runs / 'run-cram-quadrature-study.py')
original = runs / 'cram-measured-reference-verified'
assert controls['baseline_evidence'] == verified_assessment(original / 'project/reference.blab.json', original / 'evaluation')
for case in comparison['cases']:
    assert case['status'] == 'complete'
    assert case['evidence'] == verified_assessment(folder / 'project/reference.blab.json', folder / case['name'])
paths = sorted(p for directory in (folder, original) for p in directory.rglob('*') if p.is_file())
paths += [runs / name for name in ('run-cram-quadrature-study.py', 'cram-quadrature-controls.json',
           'cram-quadrature-study.log', 'finish-cram-quadrature-study.py', 'cram-quadrature-comparison.log',
           'archive-cram-quadrature-study.py', 'quadrature-tests.log', 'quadrature-unit-tests.log',
           'run-cram-measured-reference-verified.py', 'cram-measured-reference-verified-controls.json',
           'finish-cram-measured-reference-verified.py')]
license_path = runs / 'runtime/boundary-lab/LICENSE'
inventory = {str(p.relative_to(runs)): sha256(p) for p in paths}
inventory['upstream/LICENSE'] = sha256(license_path)
target = root / 'validation/evidence/bem-quadrature'
target.mkdir(parents=True, exist_ok=False)
archive_path = target / 'evidence.zip'
with zipfile.ZipFile(archive_path, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for p in paths: archive.write(p, str(p.relative_to(runs)))
    archive.write(license_path, 'upstream/LICENSE')
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
assert inventory == {**{str(p.relative_to(runs)): sha256(p) for p in paths}, 'upstream/LICENSE': sha256(license_path)}
report = {'status': 'completed_integration_sensitivity_with_retained_reciprocity_failure',
          'application_source_commit': controls['application_source_commit'],
          'upstream_revision': controls['upstream_revision'],
          'upstream_source': 'https://github.com/JWSound/boundary-lab/tree/' + controls['upstream_revision'] + '/examples/2x12_CRAM',
          'upstream_license': 'GPL-3.0, included in evidence.zip/upstream/LICENSE',
          'comparison': comparison, 'archived_file_sha256': inventory,
          'archives': [{'file': archive_path.name, 'sha256': sha256(archive_path), 'size_bytes': archive_path.stat().st_size}],
          'qualified': False, 'physical_validation': False}
(target / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k not in ('comparison', 'archived_file_sha256')}, indent=2))
