"""Evaluate the predeclared held-out relative-response comparison without refitting."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from meh_studio.boundary_lab import _contained, sha256
from meh_studio.optimisation import verified_assessment

root=Path.cwd(); folder=root/'runs/cram-measured-reference-verified'; evaluation=folder/'evaluation'; raw=evaluation/'upstream'
control_path=root/'runs/cram-measured-reference-verified-controls.json';controls=json.loads(control_path.read_text())
assert controls['runner_sha256']==sha256(root/'runs/run-cram-measured-reference-verified.py')
for name,digest in controls['original_file_sha256'].items(): assert sha256(folder/'project'/name)==digest
project=folder/'project/reference.blab.json'
assert json.loads(project.read_text())==controls['project']
identity=verified_assessment(project,evaluation)
manifest=json.loads((raw/'manifest.json').read_text())
assert manifest['status']=='complete' and all(manifest['completion_mask'])
assert manifest['frequencies_hz']==controls['frequencies_hz']
assert manifest['phasor_convention']=='exp(-i omega t)' and manifest['backend_id']=='coupled_reference'
domains=json.loads(_contained(raw,manifest['domains_metadata_file']).read_text())['domains']
domain=next(d for d in domains if d['id']=='observation:horizontal-polar')
with np.load(_contained(raw,manifest['domains_file']),allow_pickle=False) as arrays:
    indices=np.flatnonzero(arrays[domain['coordinates']['angle_deg']]==0)
    assert len(indices)==1
    index=int(indices[0]); coordinates={k:np.asarray(arrays[v])[index].tolist() for k,v in domain['coordinates'].items()}
components={p['id']:p['component_id'] for p in controls['project']['physical_system']['excitation_ports']}
ids=[components[p] for p in manifest['excitation_port_ids']]
assert len(ids)==len(set(ids))==2
pressures=[]
for row in manifest['results']:
    meta=json.loads(_contained(raw,row['metadata_file']).read_text())
    assert meta['diagnostics']['transducer_reference_voltage_v']==2.83
    assert meta['excitation_port_ids']==manifest['excitation_port_ids']
    quantity=next(q for q in meta['quantities'] if q['id']=='acoustic:pressure:horizontal-polar')
    assert quantity['unit']=='Pa' and quantity['axes']==['excitation','observation']
    with np.load(_contained(raw,row['arrays_file']),allow_pickle=False) as arrays:
        basis=arrays[quantity['key']]
        assert basis.dtype==np.complex128 and basis.shape[0]==2
        pressures.append(np.sum(basis[:,index])/2.83)
frequencies=np.array(controls['frequencies_hz']); pressure=np.array(pressures)
assert np.isfinite(pressure).all() and np.all(abs(pressure)>0)
predicted=20*np.log10(abs(pressure)/20e-6)
measured=np.loadtxt(folder/'project/Measured/Onaxis.txt',comments='*')
assert measured.shape[1]==3 and np.isfinite(measured).all() and np.all(np.diff(measured[:,0])>0)
assert measured[0,0]<=frequencies.min() and measured[-1,0]>=frequencies.max()
observed=np.interp(np.log(frequencies),np.log(measured[:,0]),measured[:,1])
cal=np.isin(frequencies,controls['calibration_frequencies_hz'])
holdout=np.isin(frequencies,controls['heldout_frequencies_hz'])
assert not np.any(cal&holdout) and np.all(cal|holdout)
offset=float(np.mean(observed[cal]-predicted[cal])); adjusted=predicted+offset; error=adjusted-observed
limit=controls['heldout_maximum_absolute_error_limit_db']; maximum=float(np.max(abs(error[holdout])))
report={'status':'complete_conditional_comparison','application_source_commit':controls['application_source_commit'],
    'controls_sha256':sha256(control_path),'runner_sha256':sha256(Path(__file__)),
    'source_evidence':identity,'component_ids':ids,'observation_coordinates':coordinates,
    'level_offset_db':offset,'offset_definition':controls['calibration'],
    'heldout_maximum_absolute_error_db':maximum,
    'heldout_rms_error_db':float(np.sqrt(np.mean(error[holdout]**2))),
    'heldout_limit_db':limit,'conditional_shape_screen_passed':maximum<=limit,
    'rows':[{'frequency_hz':float(f),'subset':'calibration' if c else 'heldout',
        'raw_predicted_level_db_at_1_v_rms':float(p),'measured_interpolated_level_db':float(m),
        'offset_adjusted_predicted_level_db':float(a),'error_db':float(e)}
        for f,c,p,m,a,e in zip(frequencies,cal,predicted,observed,adjusted,error,strict=True)],
    'qualified':False,'physical_validation':False,'limitations':controls['limitations']}
fig,(top,bottom)=plt.subplots(2,1,figsize=(9,6),sharex=True,layout='constrained',height_ratios=[2,1])
band=(measured[:,0]>=frequencies.min())&(measured[:,0]<=frequencies.max())
top.semilogx(measured[band,0],measured[band,1],color='.5',lw=1,label='Upstream measurement')
top.semilogx(frequencies,adjusted,'o-',label='Fixed model + calibration-band offset')
top.scatter(frequencies[cal],adjusted[cal],s=80,facecolors='none',edgecolors='C1',label='Level-offset calibration points',zorder=4)
top.set_ylabel('Level (dB; model offset applied)');top.legend(fontsize=9)
bottom.semilogx(frequencies[holdout],error[holdout],'o',label='Held-out error')
bottom.axhline(0,color='.5',lw=.7);bottom.axhline(limit,color='C3',ls='--');bottom.axhline(-limit,color='C3',ls='--')
bottom.set(xlabel='Frequency (Hz)',ylabel='Model − measured (dB)');bottom.legend(fontsize=9)
for axis in (top,bottom):axis.grid(True,which='both',alpha=.2)
fig.suptitle('2×12 CRAM: conditional low-frequency response-shape check\nGround/microphone conditions unmatched; no voltage or phase qualification',fontsize=11)
figure=folder/'comparison.png';fig.savefig(figure,dpi=170)
report['figure_sha256']=sha256(figure)
assert verified_assessment(project,evaluation)==identity
with (folder/'comparison.json').open('x') as stream:stream.write(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='source_evidence'},indent=2))
