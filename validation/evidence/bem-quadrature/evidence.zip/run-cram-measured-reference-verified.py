"""A predeclared, conditional measured-response shape check of an upstream example."""
from pathlib import Path
import argparse
import json
import shutil
import subprocess
from meh_studio.boundary_lab import BoundaryLabRuntime, SolveRequest, sha256

root=Path.cwd(); parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');args=parser.parse_args()
source=root/'runs/named-volume-source'
commit=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
assert commit=='c217b86ba76a2c10c6032091bfded518180fa5d4'
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True)
native=root/'runs/runtime'; example=native/'boundary-lab/examples/2x12_CRAM'
original=example/'2x12_CRAM.blab.json'
project=json.loads(original.read_text())
project['project_preferences'].update(spherical_sampling_enabled=False,polar_angle_step_deg=15.)
names=['2x12_CRAM.blab.json','2x12CRAMInterior.msh','2x12CRAMExterior.msh',
       '2x12CRAMExterior_interface_conformed.msh','Measured/Onaxis.txt','Measured/info.txt']
controls={'application_source_commit':commit,'runner_sha256':sha256(Path(__file__)),
    'upstream_revision':'8cb166226e412877d3f71f2845918e479b97aa85',
    'original_file_sha256':{name:sha256(example/name) for name in names},
    'project':project,'frequencies_hz':[63.,80.,100.,125.,160.,200.,250.,315.,400.],
    'calibration_frequencies_hz':[100.,125.,160.],
    'heldout_frequencies_hz':[63.,80.,200.,250.,315.,400.],
    'calibration':'One additive dB offset: mean(measured minus predicted) at the three calibration frequencies only; no source, loss, geometry or frequency-dependent fitting',
    'measurement_interpolation':'Piecewise linear SPL in log-frequency; no phase comparison',
    'heldout_maximum_absolute_error_limit_db':3.,
    'prediction_drive':'Both independent physical components driven coherently at 1 V RMS, reconstructed from the native 2.83 V bases',
    'native_backend':'coupled_reference','julia_threads':2,'timeout_s':1800,
    'project_change':'Observation sampling only: sphere disabled and H/V step 15 degrees; physical system and meshes unchanged',
    'qualified':False,'physical_validation':False,
    'limitations':['Source and measurement are co-located in the upstream example; exact measured build revision is not independently established',
        'Measurement is ground-plane at 10 m from DUT front, without voltage calibration or timing reference',
        'Supplied physical model is free exterior air with x symmetry; ground loading and microphone height are not matched',
        'Supplied air and bulk-loss parameters are held fixed; they are not independently calibrated here',
        'This is a conditional low-frequency response-shape comparison, not target-horn, HF, absolute-SPL or phase qualification']}
control_path=root/'runs/cram-measured-reference-verified-controls.json'
if args.prepare:
    with control_path.open('x') as stream:stream.write(json.dumps(controls,indent=2)+'\n')
    print(json.dumps(controls,indent=2));raise SystemExit
assert json.loads(control_path.read_text())==controls
folder=root/'runs/cram-measured-reference-verified';folder.mkdir(exist_ok=False)
copy=folder/'project';copy.mkdir()
for name in names:
    target=copy/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(example/name,target)
    assert sha256(target)==controls['original_file_sha256'][name]
path=copy/'reference.blab.json';path.write_text(json.dumps(project,indent=2)+'\n')
request=SolveRequest(frequencies_hz=tuple(controls['frequencies_hz']),include_project_observations=True,
    retain=('bem_boundary_traces','fem_nodal_pressure'))
runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',native/'julia-1.12.6/bin/julia',
    'coupled_reference',julia_threads=2)
result=runtime.solve(path,request,folder/'evaluation',timeout_s=controls['timeout_s'])
assert {name:sha256(example/name) for name in names}==controls['original_file_sha256']
print(json.dumps(result,indent=2))
