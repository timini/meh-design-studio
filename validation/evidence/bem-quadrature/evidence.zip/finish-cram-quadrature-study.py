"""Compare the predeclared integration levels without changing acceptance limits."""
from pathlib import Path
import json
import numpy as np
from meh_studio.boundary_lab import _contained, sha256
from meh_studio.optimisation import verified_assessment

root = Path.cwd()
folder = root / 'runs/cram-quadrature-study'
control_path = root / 'runs/cram-quadrature-controls.json'
controls = json.loads(control_path.read_text())
assert sha256(root / 'runs/run-cram-quadrature-study.py') == controls['runner_sha256']
summary = json.loads((folder / 'run-summary.json').read_text())
assert summary['controls_sha256'] == sha256(control_path)
assert [r['name'] for r in summary['rows']] == [c['name'] for c in controls['cases']]
for name, digest in controls['project_files_sha256'].items():
    assert sha256(folder / 'project' / name) == digest

def load(evaluation):
    raw = evaluation / 'upstream'
    manifest = json.loads((raw / 'manifest.json').read_text())
    row = next(r for r in manifest['results'] if r['freq_hz'] == 125.)
    meta = json.loads(_contained(raw, row['metadata_file']).read_text())
    values = {}
    with np.load(_contained(raw, row['arrays_file']), allow_pickle=False) as arrays:
        for q in meta['quantities']:
            assert q['axes'][0] == 'excitation'
            value = arrays[q['key']]
            assert value.dtype == np.complex128 and np.isfinite(value).all()
            values[q['id']] = (q, value.copy())
    return manifest, values

def compare(coarser, finer):
    a_manifest, a = load(coarser)
    b_manifest, b = load(finer)
    assert a_manifest['excitation_port_ids'] == b_manifest['excitation_port_ids']
    assert a.keys() == b.keys()
    # The physical project and mesh bytes are separately bound by each verified
    # assessment. Domain arrays must also be identical for pointwise comparison.
    assert sha256(coarser / 'upstream' / a_manifest['domains_file']) == sha256(finer / 'upstream' / b_manifest['domains_file'])
    rows = []
    for key in a:
        aq, av = a[key]
        bq, bv = b[key]
        assert aq == bq and av.shape == bv.shape
        for i, excitation in enumerate(a_manifest['excitation_port_ids']):
            delta = float(np.linalg.norm(av[i] - bv[i]))
            scale = float(np.linalg.norm(bv[i]))
            relative = delta / scale if scale else (0. if delta == 0 else None)
            rows.append({'quantity': key, 'excitation': excitation,
                         'relative_l2': relative, 'exactly_equal': bool(np.array_equal(av[i], bv[i]))})
    finite = all(r['relative_l2'] is not None for r in rows)
    return {'rows': rows, 'maximum_relative_l2': max(r['relative_l2'] for r in rows) if finite else None}

original = root / 'runs/cram-measured-reference-verified'
assert verified_assessment(original / 'project/reference.blab.json', original / 'evaluation') == controls['baseline_evidence']
cases = []
complete = {}
for case, row in zip(controls['cases'], summary['rows'], strict=True):
    record = {'name': case['name'], 'solver_options': case['solver_options'], 'status': row['status']}
    if row['status'] == 'complete':
        evidence = verified_assessment(folder / 'project/reference.blab.json', folder / case['name'])
        assert evidence == row['evidence']
        record['evidence'] = evidence
        manifest, _ = load(folder / case['name'])
        assert manifest['frequencies_hz'] == controls['frequencies_hz']
        assert all(manifest['solver_options'][k] == v for k, v in case['solver_options'].items())
        complete[case['name']] = folder / case['name']
    else:
        record['error'] = row['error']
    cases.append(record)
comparisons = []
pairs = [('previous-reference', 'q2-s2', original / 'evaluation', complete.get('q2-s2'), controls['baseline_repeat_relative_l2_limit'])]
names = [c['name'] for c in controls['cases']]
for i in range(1, len(names)):
    pairs.append((names[i-1], names[i], complete.get(names[i-1]), complete.get(names[i]),
                  controls['last_two_levels_relative_l2_limit'] if i == len(names)-1 else None))
for a_name, b_name, a_path, b_path, limit in pairs:
    record = {'coarser': a_name, 'finer': b_name, 'limit': limit}
    if a_path is None or b_path is None:
        record['status'] = 'unavailable_due_to_failed_case'
    else:
        record.update(status='complete', **compare(a_path, b_path))
        if limit is not None:
            record['passed'] = record['maximum_relative_l2'] is not None and record['maximum_relative_l2'] <= limit
    comparisons.append(record)
report = {'application_source_commit': controls['application_source_commit'],
          'controls_sha256': sha256(control_path), 'postprocessor_sha256': sha256(Path(__file__)),
          'cases': cases, 'comparisons': comparisons, 'qualified': False,
          'physical_validation': False, 'limitations': controls['limitations']}
with (folder / 'comparison.json').open('x') as stream:
    stream.write(json.dumps(report, indent=2) + '\n')
print(json.dumps({'cases': [{k: v for k, v in c.items() if k != 'evidence'} | ({'checks': c['evidence']['checks']} if 'evidence' in c else {}) for c in cases],
                  'comparisons': [{k: v for k, v in c.items() if k != 'rows'} for c in comparisons]}, indent=2))
