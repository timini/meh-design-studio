"""Predeclared fixed-mesh integration sensitivity study; no physical fitting."""
from pathlib import Path
import argparse
import json
import shutil
import subprocess
from meh_studio.boundary_lab import BEMQuadrature, BoundaryLabRuntime, SolveRequest, sha256
from meh_studio.optimisation import verified_assessment

root = Path.cwd()
parser = argparse.ArgumentParser()
parser.add_argument('--prepare', action='store_true')
args = parser.parse_args()
source = root / 'runs/quadrature-source'
commit = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
assert commit == '852a5a33af9617ac3a40f9956ca12f744e3d0ba8'
assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'], text=True)
original = root / 'runs/cram-measured-reference-verified'
project = original / 'project/reference.blab.json'
baseline = verified_assessment(project, original / 'evaluation')
files = {str(p.relative_to(original / 'project')): sha256(p)
         for p in sorted((original / 'project').rglob('*')) if p.is_file()}
controls = {
    'application_source_commit': commit, 'runner_sha256': sha256(Path(__file__)),
    'upstream_revision': '8cb166226e412877d3f71f2845918e479b97aa85',
    'baseline_source_commit': 'c217b86ba76a2c10c6032091bfded518180fa5d4',
    'baseline_evidence': baseline, 'project_files_sha256': files,
    'frequencies_hz': [125.0],
    'frequency_selection': 'Largest observed electrical reciprocity residual in the previously completed nine-frequency CRAM reference; diagnostic selection, not a held-out test',
    'cases': [{'name': f'q{q}-s{s}', 'solver_options': BEMQuadrature(quadrature_order=q, singular_order=s).model_dump(mode='json')}
              for q, s in [(2, 2), (4, 2), (4, 4), (4, 8)]],
    'baseline_repeat_relative_l2_limit': 1e-10,
    'last_two_levels_relative_l2_limit': 0.01,
    'field_comparison': 'Every native complex acoustic and transducer quantity; relative L2 difference divided by finer/reference quantity norm, separately per quantity and excitation; exact equality required when reference norm is zero',
    'electrical_reciprocity_relative_limit': 1e-8,
    'native_backend': 'coupled_reference', 'julia_threads': 2, 'timeout_s': 1800,
    'physical_model_or_mesh_changes': False, 'qualified': False,
    'limitations': ['One diagnostic frequency and one fixed mesh only',
                   'Field stability does not establish mesh convergence or physical accuracy',
                   'Existing measured-response failure and unmatched measurement conditions remain unchanged']}
control_path = root / 'runs/cram-quadrature-controls.json'
if args.prepare:
    with control_path.open('x') as stream:
        stream.write(json.dumps(controls, indent=2) + '\n')
    print(json.dumps({'controls_sha256': sha256(control_path), 'cases': controls['cases']}, indent=2))
    raise SystemExit
assert json.loads(control_path.read_text()) == controls
folder = root / 'runs/cram-quadrature-study'
folder.mkdir(exist_ok=False)
copy = folder / 'project'
shutil.copytree(original / 'project', copy)
for name, digest in files.items():
    assert sha256(copy / name) == digest
native = root / 'runs/runtime'
runtime = BoundaryLabRuntime(native / 'boundary-lab', native / 'blab-env/bin/python',
                             native / 'julia-1.12.6/bin/julia', 'coupled_reference', julia_threads=2)
rows = []
for case in controls['cases']:
    request = SolveRequest(frequencies_hz=(125.,), include_project_observations=True,
                           retain=('bem_boundary_traces', 'fem_nodal_pressure'),
                           solver_options=BEMQuadrature.model_validate(case['solver_options']))
    evaluation = folder / case['name']
    try:
        result = runtime.solve(copy / 'reference.blab.json', request, evaluation, timeout_s=1800)
        evidence = verified_assessment(copy / 'reference.blab.json', evaluation)
        row = {'name': case['name'], 'status': 'complete', 'evidence': evidence}
    except Exception as exc:
        row = {'name': case['name'], 'status': 'failed', 'error': f'{type(exc).__name__}: {exc}'}
    rows.append(row)
    (folder / 'progress.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(json.dumps(row), flush=True)
assert verified_assessment(project, original / 'evaluation') == baseline
for name, digest in files.items():
    assert sha256(copy / name) == digest
    assert sha256(original / 'project' / name) == digest
with (folder / 'run-summary.json').open('x') as stream:
    stream.write(json.dumps({'controls_sha256': sha256(control_path), 'rows': rows}, indent=2) + '\n')
