"""Fresh native search and export for an exactly equivalent synthetic outlet circuit."""
from pathlib import Path
import argparse,json
import numpy as np
from meh_studio.boundary_lab import BoundaryLabRuntime,sha256,_contained
from meh_studio.catalogue import Catalogue
from meh_studio.domain import DriverRevision
from meh_studio.geometry import HornGeometry
from meh_studio.optimisation import SearchBrief,candidates,optimise,verified_assessment
from meh_studio.build_bundle import export_search
from meh_studio.search_results import load_completed_search
from meh_studio.operating import search_operating_report
root=Path.cwd();prior=root/'runs/periodic-symmetry-search';old_trial=prior/'trial-000'
load_completed_search(prior)
saved_path=old_trial/'candidate.json';saved=json.loads(saved_path.read_text())
base=HornGeometry.model_validate(saved['design']);drivers=[]
for raw in saved['driver_revisions']:
    data=json.loads(json.dumps(raw))
    if data['id']=='synthetic-throat':
        data['revision']+=1
        data['model']='Synthetic ideal-area-transformer coordinate reference'
        source=data['source_model'];assert source['provenance']['kind']=='synthetic'
        source['ideal_outlet_area_m2']=source['sd_m2'];source['sd_m2']*=2.
        source['bl_n_a']*=2.;source['mmd_kg']*=4.;source['rms_ns_m']*=4.;source['cms_m_n']/=4.
        source['provenance']['source']='Synthetic coordinate-equivalence fixture: twice the diaphragm area and outlet velocity ratio two; not commercial driver data'
    drivers.append(DriverRevision.model_validate(data))
controls=json.loads((prior/'brief.json').read_text());controls.update(trial_budget=1);controls.pop('evolution')
brief=SearchBrief.model_validate(controls);candidate=candidates(brief,base,drivers)[0]
assert candidate['design']==base
old_parameters=next(c['parameters'] for c in json.loads((old_trial/'system/project.blab.json').read_text())['physical_system']['components'] if c['id']=='component:throat')
assert all(old_parameters[k]==v for k,v in candidate['sources'].throat.outlet_piston_parameters().items())
parser=argparse.ArgumentParser();parser.add_argument('--source-commit',required=True);parser.add_argument('--prepare',action='store_true');args=parser.parse_args()
provenance={'application_source_commit':args.source_commit,'reference_candidate_sha256':sha256(saved_path),
    'reference_source_commit':'ab6714f','native_backend':'coupled_reference','native_threads':2,
    'reference_construction':'New synthetic physical throat has twice the diaphragm area with parameters transformed so the outlet circuit and generated geometry exactly equal the archived baseline',
    'predeclared_limits':{'all_quantity_relative_complex_l2':1e-8,'frozen_score_absolute_difference':1e-8,
        'electrical_consistency':1e-8,'operating_relative_complex_l2':1e-8},
    'required_identical_native_inputs':['mesh hashes by mesh id','frequency grid','quantity ids and shapes'],
    'qualified':False,'physical_validation':False,
    'limitations':['Coordinate equivalence is not validation of an actual compression driver or phase plug',
        'Small synthetic four-frequency case, no mesh convergence, disabled 2-ohm screen; not target horn',
        'No physical source, manufacturing, print or maximum-output qualification']}
controls_path=root/'runs/compression-outlet-controls.json'
controls_path.write_text(json.dumps({'brief':brief.model_dump(mode='json'),'base':base.model_dump(mode='json'),
    'drivers':[d.model_dump(mode='json') for d in drivers],'provenance':provenance},indent=2)+'\n')
if args.prepare:
    print(json.dumps(provenance,indent=2));raise SystemExit
native=root/'runs/runtime';output=root/'runs/compression-outlet-search';database=root/'runs/compression-outlet-search.sqlite'
with Catalogue.create(database) as catalogue:
    for driver in drivers:catalogue.add(driver)
runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',native/'julia-1.12.6/bin/julia','coupled_reference',julia_threads=2)
result=optimise(brief,base,database,runtime,output,solver_stage_timeout_s=1800)
(output/'experiment-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
load_completed_search(output)
trial=output/'trial-000';evidence=verified_assessment(trial/'system/project.blab.json',trial/'evaluation')
assert evidence['checks']['passed']
old_evidence=verified_assessment(old_trial/'system/project.blab.json',old_trial/'evaluation')
old_project=json.loads((old_trial/'system/project.blab.json').read_text())['physical_system']
new_project=json.loads((trial/'system/project.blab.json').read_text())['physical_system']
assert old_project['metadata']['generated_mesh_sha256']==new_project['metadata']['generated_mesh_sha256']
# Verify every compiled mesh, including the conformed exterior, at its actual path.
for a,b in zip(old_project['meshes'],new_project['meshes'],strict=True):
    assert a['id']==b['id'] and sha256(old_trial/'system'/a['file'])==sha256(trial/'system'/b['file'])
old_raw=old_trial/'evaluation/upstream';new_raw=trial/'evaluation/upstream'
a=json.loads((old_raw/'manifest.json').read_text());b=json.loads((new_raw/'manifest.json').read_text())
assert a['frequencies_hz']==b['frequencies_hz'] and a['excitation_port_ids']==b['excitation_port_ids']
errors=[]
for ar,br in zip(a['results'],b['results'],strict=True):
    am=json.loads(_contained(old_raw,ar['metadata_file']).read_text());bm=json.loads(_contained(new_raw,br['metadata_file']).read_text())
    aq={q['id']:q for q in am['quantities']};bq={q['id']:q for q in bm['quantities']};assert aq.keys()==bq.keys()
    with np.load(_contained(old_raw,ar['arrays_file']),allow_pickle=False) as aa,np.load(_contained(new_raw,br['arrays_file']),allow_pickle=False) as ba:
        for name in aq:
            av=aa[aq[name]['key']];bv=ba[bq[name]['key']];assert av.shape==bv.shape
            norm=float(np.linalg.norm(av));error=float(np.linalg.norm(av-bv)/norm) if norm else (0. if not np.any(bv) else float('inf'))
            errors.append({'frequency_hz':ar['freq_hz'],'quantity':name,'relative_complex_l2':error})
assert max(r['relative_complex_l2'] for r in errors)<=1e-8
old_score=json.loads((old_trial/'score.json').read_text())
assert abs(result['winner']['ripple_db']-old_score['ripple_db'])<=1e-8
operating=search_operating_report(output,1.)
(output/'operating-1vrms.json').write_text(json.dumps(operating,indent=2)+'\n')
# Native outlet motion is reported separately; physical HF excursion uses half of it.
def complex_array(value):return np.array(value['real'])+1j*np.array(value['imag'])
physical=complex_array(operating['component_velocity_rms_m_s']);outlet=complex_array(operating['component_outlet_velocity_rms_m_s'])
ratio=np.ones(physical.shape[1]);ratio[list(operating['component_ids']).index('component:throat')]=2.
assert np.linalg.norm(outlet-physical*ratio)<=1e-8*np.linalg.norm(outlet)
bundle=export_search(output,root/'runs/compression-outlet-winner.zip')
(output/'export-verification.json').write_text(json.dumps(bundle,indent=2)+'\n')
validation={'status':'complete','controls_sha256':sha256(controls_path),'source_commit':args.source_commit,
    'search_sha256':sha256(output/'search.json'),'reference_evidence':old_evidence,'new_evidence':evidence,
    'quantity_errors':errors,'maximum_relative_complex_l2':max(r['relative_complex_l2'] for r in errors),
    'equivalent_native_circuit_and_meshes':True,'physical_hf_velocity_equals_outlet_divided_by_two':True,
    'export':bundle,'qualified':False,'physical_validation':False}
(output/'coordinate-validation.json').write_text(json.dumps(validation,indent=2)+'\n')
print(json.dumps({'maximum_relative_complex_l2':validation['maximum_relative_complex_l2'],'export':bundle},indent=2))
