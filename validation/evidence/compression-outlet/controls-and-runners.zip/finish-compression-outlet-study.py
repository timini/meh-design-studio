"""Archive the completed native outlet-coordinate equivalence check."""
from pathlib import Path
import json,zipfile
from meh_studio.boundary_lab import sha256
from meh_studio.search_results import load_completed_search
root=Path.cwd();search=root/'runs/compression-outlet-search'
hashes,result,*_=load_completed_search(search)
validation=json.loads((search/'coordinate-validation.json').read_text())
assert validation['search_sha256']==sha256(search/'search.json')
assert validation['controls_sha256']==sha256(root/'runs/compression-outlet-controls.json')
assert validation['maximum_relative_complex_l2']<=1e-8
assert validation['new_evidence']['checks']['passed']
bundle=root/'runs/compression-outlet-winner.zip';assert sha256(bundle)==validation['export']['sha256']
target=root/'validation/evidence/compression-outlet';target.mkdir(parents=True,exist_ok=False)
groups={};files=[];total=0;part=0
for path in sorted(search.rglob('*')):
    if not path.is_file():continue
    size=path.stat().st_size;assert size<90_000_000
    if total+size>85_000_000 and files:
        groups[f'native-search-{part:02d}']=files;files=[];total=0;part+=1
    files.append((path,str(path.relative_to(root/'runs'))));total+=size
if files:groups[f'native-search-{part:02d}']=files
names=('run-compression-outlet-reference.py','compression-outlet-controls.json','compression-outlet-prepare.log',
    'compression-outlet-reference.log','finish-compression-outlet-study.py','outlet-source-unit-tests.log')
groups['controls-and-runners']=[(root/'runs'/name,name) for name in names]+[(bundle,bundle.name)]
archives=[]
for label,files in groups.items():
    path=target/(label+'.zip')
    with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for source,name in files:archive.write(source,name)
    assert path.stat().st_size<100_000_000
    with zipfile.ZipFile(path) as archive:assert archive.testzip() is None
    archives.append({'file':path.name,'sha256':sha256(path),'size_bytes':path.stat().st_size})
report={'status':'completed_native_outlet_coordinate_equivalence','application_source_commit':'b7255b0',
    'reference_source_commit':'ab6714f','reference_archive_report':'../periodic-profile-symmetry/report.json',
    'archives':archives,'maximum_relative_complex_l2':validation['maximum_relative_complex_l2'],
    'strict_electrical_checks_passed':validation['new_evidence']['checks']['passed'],
    'physical_hf_velocity_equals_outlet_divided_by_two':validation['physical_hf_velocity_equals_outlet_divided_by_two'],
    'selected_response_variation_db':result['winner']['ripple_db'],
    'export':validation['export'],'qualified':False,'physical_validation':False,
    'limitations':['Equivalent synthetic circuits with identical native meshes, four frequencies; not a commercial compression-driver validation',
        'Small reference with disabled 2-ohm screen; not the full-size target horn, convergence, physical or print qualification']}
(target/'report.json').write_text(json.dumps(report,indent=2)+'\n')
assert all(sha256(search/name)==digest for name,digest in hashes.items())
print(json.dumps(report,indent=2))
