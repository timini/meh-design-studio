from pathlib import Path
import json,io,zipfile,hashlib,sys
import numpy as np
from meh_studio.optimisation import verified_assessment
from meh_studio.validation import validate_electrical_basis
root=Path(__file__).resolve().parent;project=root/'system/project.blab.json'
rows={};loaded={};identities={};checks={}
archive_report=json.loads(Path(sys.argv[2]).read_text()) if len(sys.argv)==3 else None
if archive_report is not None:
 for name,digest in archive_report['archive_members_sha256'].items():
  rel=Path(name);assert not rel.is_absolute() and '..' not in rel.parts
  assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==digest
 checks=archive_report['electrical_checks']
for name in ('evaluation-baseline','evaluation-4-4'):
 p=root/name
 if archive_report is None:
  verified_assessment(project,p);checks[name]=validate_electrical_basis(project,p)
 raw=p/'upstream';m=json.loads((raw/'manifest.json').read_text());identities[name]=m
 q={x['id']:x for x in json.loads((raw/'frequencies/000000.json').read_text())['quantities']}
 with np.load(raw/'frequencies/000000.npz',allow_pickle=False) as a:
  loaded[name]={k:a[v['key']].copy() for k,v in q.items()}
 ids=q['mechanical:diaphragm-velocity']['metadata']['component_ids'];assert ids==['component:throat','component:entry_0_positive','component:entry_0_positive_y']
a,b=(identities[n] for n in ('evaluation-baseline','evaluation-4-4'))
assert a['reference_runtime']['identity']==b['reference_runtime']['identity']
assert a['project_sha256']==b['project_sha256']==hashlib.sha256(project.read_bytes()).hexdigest()
assert a['solver_options']['quadrature_order']==a['solver_options']['singular_order']==2
assert b['solver_options']['quadrature_order']==b['solver_options']['singular_order']==4
assert b['solver_options']['regular_quadrature_mode']=='fixed'
with np.load(root/'evaluation-baseline/upstream/domains.npz',allow_pickle=False) as x, np.load(root/'evaluation-4-4/upstream/domains.npz',allow_pickle=False) as y:
 assert set(x.files)==set(y.files)
 for key in x.files: np.testing.assert_array_equal(x[key],y[key])
for k in ('mechanical:diaphragm-velocity','electrical:voice-coil-current','acoustic:pressure:horizontal-polar','acoustic:pressure:vertical-polar'):
 x=loaded['evaluation-baseline'][k];y=loaded['evaluation-4-4'][k];rows[k]=float(np.linalg.norm(y-x)/np.linalg.norm(x))
x=np.concatenate([loaded['evaluation-baseline'][f'acoustic:pressure:{p}-polar'][1:].sum(axis=0) for p in ('horizontal','vertical')])
y=np.concatenate([loaded['evaluation-4-4'][f'acoustic:pressure:{p}-polar'][1:].sum(axis=0) for p in ('horizontal','vertical')])
rows['common_mid_pressure']=float(np.linalg.norm(y-x)/np.linalg.norm(x))
archive=Path(sys.argv[1]).resolve()
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='974ecbdfac9341d57746c01b6a0ba37c3104aa9cf08299a0ad44e0c2df300061'
with zipfile.ZipFile(archive) as z:
 prefix='annular-entry-refinement-resumed/refined/evaluation/upstream/frequencies/'
 q={x['id']:x for x in json.loads(z.read(prefix+'000000.json'))['quantities']}
 with np.load(io.BytesIO(z.read(prefix+'000000.npz')),allow_pickle=False) as old:
  historical={k:float(np.linalg.norm(loaded['evaluation-baseline'][k]-old[q[k]['key']])/np.linalg.norm(old[q[k]['key']])) for k in rows if k!='common_mid_pressure'}
report={'source_commit':'084547174cbb4450ec52e9876c1064ba14c31c9d','frequency_hz':4000,'project_sha256':a['project_sha256'],'runtime_identical_between_new_runs':True,'historical_to_new_baseline_errors':historical,'baseline_to_4_4_relative_errors':rows,'electrical_checks':checks,'qualified':False,'limitations':['One-frequency quadrature sensitivity does not establish mesh convergence.','Original 51.07% common-bank mesh change remains failed.']}
(root/('reproduced-comparison.json' if archive_report is not None else 'comparison.json')).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'historical':historical,'quadrature':rows,'electrical':{k:v['passed'] for k,v in checks.items()}}))
