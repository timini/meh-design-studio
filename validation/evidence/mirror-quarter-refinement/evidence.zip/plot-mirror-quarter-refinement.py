"""Plot retained raw complex-field differences, without smoothing or fitting."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter
from meh_studio.boundary_lab import sha256

root = Path.cwd(); runs = root / 'runs'
paths = [runs / 'mirror-quarter-refinement/comparison.json', runs / 'mirror-quarter-fine/comparison.json']
reports = [json.loads(path.read_text()) for path in paths]
comparisons = {(c['reference'], c['value']): c for r in reports for c in r['comparisons']}
fig, axes = plt.subplots(1, 2, figsize=(12, 4.6), constrained_layout=True)
for ax, pairs, title in [
    (axes[0], [('full', size) for size in ['10mm', '8mm', '6mm', '4mm']], 'Quarter models versus retained full model'),
    (axes[1], [('8mm', '10mm'), ('6mm', '8mm'), ('4mm', '6mm')], 'Adjacent quarter-mesh levels')]:
    for ref, value in pairs:
        case = comparisons[(ref, value)]
        frequencies = sorted({row['frequency_hz'] for row in case['rows']})
        errors = [100 * max(row['relative_l2'] for row in case['rows'] if row['frequency_hz'] == f) for f in frequencies]
        label = value.replace('mm', ' mm') if ref == 'full' else value.replace('mm', '') + ' / ' + ref.replace('mm', ' mm')
        ax.plot(frequencies, errors, marker='o', label=label)
    ax.axhline(2, color='#ad2935', linestyle='--', linewidth=1.2, label='2% acceptance limit')
    ax.set(xscale='log', title=title, xlabel='Frequency (Hz)', ylabel='Maximum relative complex L2 difference (%)', ylim=(0, None))
    ax.set_xticks([350, 1000, 2000, 3000], labels=['350', '1,000', '2,000', '3,000'])
    ax.xaxis.set_minor_formatter(NullFormatter())
    ax.grid(alpha=.2); ax.legend(fontsize=8)
fig.suptitle('Mirror-quarter mesh refinement — fixed CAD and source parameters\nFour diagnostic frequencies; synthetic drivers; no physical qualification', fontsize=12)
path = runs / 'mirror-quarter-refinement-comparison.png'
fig.savefig(path, dpi=170)
metadata = {'runner_sha256': sha256(Path(__file__)), 'source_reports_sha256': {str(p.relative_to(runs)): sha256(p) for p in paths},
            'image_sha256': sha256(path), 'statistic': 'Maximum relative complex L2 over all corresponding observation/transducer vectors and supported excitation groups, separately per frequency',
            'fitting_or_smoothing': False, 'qualified': False, 'physical_validation': False}
(runs / 'mirror-quarter-refinement-plot.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps(metadata, indent=2))
