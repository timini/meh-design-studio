"""Archive every completed refinement, its frozen inputs and failed comparisons."""
from pathlib import Path
import json
import zipfile
from meh_studio.boundary_lab import sha256
from meh_studio.optimisation import verified_assessment

root = Path.cwd(); runs = root / 'runs'; reports = {}
for name in ['refinement', 'fine']:
    cp = runs / ('mirror-quarter-' + name + '-controls.json')
    controls = json.loads(cp.read_text()); folder = runs / ('mirror-quarter-' + name)
    result = json.loads((folder / 'report.json').read_text())
    comparison = json.loads((folder / 'comparison.json').read_text())
    assert result['status'] == 'complete' and result['controls_sha256'] == sha256(cp) == comparison['controls_sha256']
    assert controls['runner_sha256'] == sha256(runs / ('run-mirror-quarter-' + name + '.py'))
    assert controls['mesher_sha256'] == sha256(runs / ('mesh-mirror-quarter-' + name + '.py'))
    assert comparison['runner_sha256'] == sha256(runs / ('compare-mirror-quarter-' + name + '.py'))
    for row in result['rows']:
        level = row['level']['name']; mesh = runs / ('mirror-quarter-refinement-' + level + '-mesh')
        assert verified_assessment(mesh / 'project.blab.json', folder / level) == row['evidence']
        assert all(sha256(mesh / file) == digest for file, digest in row['inputs_sha256'].items())
        assert row['preparation_report_sha256'] == sha256(mesh / 'report.json')
    reports[name] = {'controls_sha256': sha256(cp), 'native': result, 'comparison': comparison}
plot = json.loads((runs / 'mirror-quarter-refinement-plot.json').read_text())
assert all(sha256(runs / p) == digest for p, digest in plot['source_reports_sha256'].items())
assert plot['image_sha256'] == sha256(runs / 'mirror-quarter-refinement-comparison.png')
assert plot['runner_sha256'] == sha256(runs / 'plot-mirror-quarter-refinement.py')
paths = set()
for pattern in ['*mirror-quarter-refinement*', '*mirror-quarter-fine*']:
    for path in runs.glob(pattern):
        if path.is_file(): paths.add(path)
        elif path.is_dir(): paths.update(p for p in path.rglob('*') if p.is_file())
paths.discard(runs / 'archive-mirror-quarter-refinement.log')
paths.add(Path(__file__).resolve())
inventory = {str(p.relative_to(runs)): sha256(p) for p in sorted(paths)}
target = root / 'validation/evidence/mirror-quarter-refinement'; target.mkdir(parents=True, exist_ok=False)
path = target / 'evidence.zip'
with zipfile.ZipFile(path, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for p in sorted(paths): archive.write(p, str(p.relative_to(runs)))
with zipfile.ZipFile(path) as archive: assert archive.testzip() is None
assert path.stat().st_size < 100_000_000
assert inventory == {str(p.relative_to(runs)): sha256(p) for p in sorted(paths)}
report = {'status': 'complete_four_level_mirror_refinement',
          'application_source_commit': '25e69a8575077df2c533ccab6db13ee4a823cc53',
          'studies': reports, 'plot': plot,
          'archives': [{'file': path.name, 'size_bytes': path.stat().st_size, 'sha256': sha256(path)}],
          'archived_file_sha256': inventory,
          'coarse_quarter_reference_archive': '../mirror-driver-validation/report.json',
          'full_reference_archive': '../tilted-entry-search/report.json',
          'qualified': False, 'physical_validation': False}
(target / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'archives': report['archives'], 'archived_files': len(inventory)}, indent=2))
