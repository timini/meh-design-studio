"""Prepare a quarter FEM/BEM project; do not launch a native simulation."""
from pathlib import Path
import argparse, json, math, subprocess
import numpy as np
import gmsh, meshio
from meh_studio.boundary_lab import sha256, _execute
from meh_studio.cad_runtime import load_cadquery
from meh_studio.geometry import HornGeometry, source_area_checks, CURVATURE_ELEMENTS
from meh_studio.waveguide_profile import imported_volume
from meh_studio.interface_coordinates import restore_fem_interface_coordinates
from meh_studio.radiation_geometry import surface_integrity, verify_exterior_groups

root=Path.cwd();runs=root/'runs';cad=runs/'mirror-quarter-reference-adaptive'
parser=argparse.ArgumentParser();parser.add_argument('--level',choices=['8mm','6mm'],required=True);args=parser.parse_args()
interior_size,exterior_size={'8mm':(.008,.016),'6mm':(.006,.012)}[args.level]
out=runs/('mirror-quarter-refinement-'+args.level+'-mesh')
out.mkdir(exist_ok=False);(out/'meshes').mkdir()
report=json.loads((cad/'report.json').read_text());assert report['status']=='complete_cad_preparation'
controls=json.loads((cad/'controls.json').read_text());full=runs/'tilted-entry-10mm/trial-000'
g=json.loads((full/'geometry/geometry.json').read_text());design=HornGeometry.model_validate(g['design'] | {'mesh_size_m':interior_size})
assert sha256(cad/'controls.json')==report['controls_sha256']
for k,v in report['files'].items():assert sha256(cad/k)==v
study={'runner_sha256':sha256(Path(__file__)), 'source_commit':'25e69a8575077df2c533ccab6db13ee4a823cc53',
       'original_mesher_sha256':sha256(runs/'mesh-mirror-quarter-reference.py'),'cad_report_sha256':sha256(cad/'report.json'),
       'full_project_sha256':sha256(full/'system/project.blab.json'),'native_conform_helper_sha256':sha256(runs/'native-quarter-mouth-conform.py'),
       'original_conform_helper_sha256':sha256(runs/'tilted-entry-source/src/meh_studio/native_mouth_conform.py'),
       'interior_mesh_size_m':design.mesh_size_m,'exterior_mesh_size_m':exterior_size,'maximum_final_triangles':5000,
       'maximum_total_tetrahedra':500000,'native_simulation_executed':False,'qualified':False}
(out/'controls.json').write_text(json.dumps(study,indent=2)+'\n')
result={'status':'running','controls_sha256':sha256(out/'controls.json'),'regions':[]}
try:
 for region,boundaries in report['boundary_descriptors'].items():
  gmsh.initialize()
  try:
   gmsh.option.setNumber('General.Terminal',0);gmsh.option.setString('Geometry.OCCTargetUnit','M')
   gmsh.model.occ.importShapes(str(cad/(region+'.step')));gmsh.model.occ.synchronize()
   volumes=gmsh.model.getEntities(3);assert len(volumes)==1
   volume=imported_volume(design,gmsh.model.occ.getMass(*volumes[0]),out/(region+'-imported.step'))
   assert math.isclose(volume,report['volumes_m3'][region],rel_tol=1e-6)
   groups={k:[] for k in boundaries};walls=[]
   for dim,tag in gmsh.model.getBoundary(volumes,oriented=False):
    centre=np.array(gmsh.model.occ.getCenterOfMass(dim,tag))
    matches=[k for k,v in boundaries.items() if gmsh.model.getType(dim,tag)=='Plane' and np.linalg.norm(centre-v['center_m'])<1e-7]
    assert len(matches)<=1
    (groups[matches[0]] if matches else walls).append(tag)
   assert all(len(v)==1 for v in groups.values()) and walls
   gmsh.model.addPhysicalGroup(3,[volumes[0][1]],1,name='air_'+region)
   for tag,(name,surfaces) in enumerate(groups.items(),start=10):gmsh.model.addPhysicalGroup(2,surfaces,tag,name=name)
   gmsh.model.addPhysicalGroup(2,walls,99,name='rigid_walls')
   gmsh.option.setNumber('Mesh.MeshSizeMin',min(design.mesh_size_m,math.pi*min(design.throat_radius_m,design.port_radius_m,design.front_radius_m)/CURVATURE_ELEMENTS))
   gmsh.option.setNumber('Mesh.MeshSizeFromCurvature',CURVATURE_ELEMENTS);gmsh.option.setNumber('Mesh.MeshSizeMax',design.mesh_size_m)
   gmsh.option.setNumber('Mesh.ElementOrder',1);gmsh.option.setNumber('Mesh.MshFileVersion',4.1);gmsh.option.setNumber('Mesh.Binary',0)
   gmsh.model.mesh.generate(3);tets,_=gmsh.model.mesh.getElementsByType(4);quality=gmsh.model.mesh.getElementQualities(tets)
   assert len(tets)>0 and len(tets)<=500000 and min(quality)>0
   path=out/'meshes'/(region+'.msh');gmsh.write(str(path))
   areas=source_area_checks(path,{k:math.sqrt(v['area_m2']/math.pi) for k,v in boundaries.items()})
   result['regions'].append({'id':region,'tetrahedra':len(tets),'minimum_quality':float(min(quality)),'volume_m3':volume,'source_area_checks':areas,'sha256':sha256(path)})
  finally:gmsh.finalize()
 assert sum(v['tetrahedra'] for v in result['regions'])<=500000
 cq=load_cadquery();front=cq.importers.importStep(str(cad/'front.step')).val()
 mouth=next(f for f in front.Faces() if f.geomType()=='PLANE' and abs(f.Center().z/1000-design.length_m)<1e-9)
 cq.exporters.export(mouth,str(out/'mouth.step'))
 gmsh.initialize()
 try:
  gmsh.option.setNumber('General.Terminal',0);gmsh.option.setString('Geometry.OCCTargetUnit','M')
  body=gmsh.model.occ.importShapes(str(cad/'envelope.step'));cap=gmsh.model.occ.importShapes(str(out/'mouth.step'))
  gmsh.model.occ.fragment(body,cap);gmsh.model.occ.synchronize();volumes=gmsh.model.getEntities(3);assert len(volumes)==1
  volume=imported_volume(design,gmsh.model.occ.getMass(*volumes[0]),out/'envelope-imported.step')
  assert math.isclose(volume,report['volumes_m3']['envelope'],rel_tol=1e-6)
  mouths=[];walls=[];cuts=[]
  expected=np.array(report['boundary_descriptors']['front']['mouth_interface']['center_m'])
  for dim,tag in gmsh.model.getBoundary(volumes,oriented=False):
   box=gmsh.model.getBoundingBox(dim,tag);centre=np.array(gmsh.model.occ.getCenterOfMass(dim,tag));plane=gmsh.model.getType(dim,tag)=='Plane'
   if plane and np.linalg.norm(centre-expected)<1e-7:mouths.append(tag)
   elif plane and (max(abs(box[0]),abs(box[3]))<1e-6 or max(abs(box[1]),abs(box[4]))<1e-6):cuts.append(tag)
   else:walls.append(tag)
  assert len(mouths)==1 and walls and len(cuts)==2
  gmsh.model.addPhysicalGroup(2,mouths,10,name='mouth_interface');gmsh.model.addPhysicalGroup(2,walls,99,name='rigid_exterior')
  for dim,curve in gmsh.model.getBoundary([(2,mouths[0])],oriented=False):
   length=gmsh.model.occ.getMass(dim,curve);gmsh.model.mesh.setTransfiniteCurve(curve,max(3,math.ceil(length/(design.mesh_size_m/2))+1))
  gmsh.option.setNumber('Mesh.MeshSizeMin',exterior_size);gmsh.option.setNumber('Mesh.MeshSizeMax',exterior_size)
  gmsh.option.setNumber('Mesh.ElementOrder',1);gmsh.option.setNumber('Mesh.MshFileVersion',2.2);gmsh.option.setNumber('Mesh.Binary',0)
  gmsh.model.mesh.generate(2);gmsh.write(str(out/'exterior-raw.msh'))
 finally:gmsh.finalize()
 native=runs/'runtime';helper=runs/'native-quarter-mouth-conform.py';raw=out/'exterior-conformed-raw.msh';cp=out/'conform-interface.json'
 _execute([str(native/'blab-env/bin/python'),'-I',str(helper),str(out/'meshes/front.msh'),str(out/'exterior-raw.msh'),str(raw),str(cp),'--mouth-z',str(design.length_m)],native/'boundary-lab',out/'conform-interface.log',600)
 conform=json.loads(cp.read_text());assert conform['status']=='complete' and conform['symmetry_mode']=='xy'
 assert conform['helper_sha256']==study['native_conform_helper_sha256']
 result['interface_coordinate_restoration']=restore_fem_interface_coordinates(raw,out/'meshes/front.msh',out/'meshes/exterior.msh')
 verify_exterior_groups(out/'meshes/exterior.msh',out/'meshes/front.msh')
 mesh=meshio.read(out/'meshes/exterior.msh');faces=np.concatenate([c.data for c in mesh.cells]);assert len(faces)<=5000
 assert all(c.type=='triangle' for c in mesh.cells)
 # Reconstruct a closed diagnostic surface by reflection. Snap only symmetry
 # plane roundoff below 1e-12m; the native input remains byte-for-byte unchanged.
 points=mesh.points.copy();snap=np.abs(points[:,:2])<1e-12;max_snap=float(np.max(np.abs(points[:,:2][snap]))) if snap.any() else 0.;points[:,:2][snap]=0.
 assert points[:,:2].min()>=0
 lookup={};vertices=[];reflected=[]
 for sx,sy in [(1,1),(-1,1),(1,-1),(-1,-1)]:
  transformed=points*np.array([sx,sy,1]);indices=[]
  for p in transformed:
   key=tuple(p)
   if key not in lookup:lookup[key]=len(vertices);vertices.append(p)
   indices.append(lookup[key])
  mapped=np.array(indices)[faces]
  if sx*sy<0:mapped=mapped[:,[0,2,1]]
  reflected.extend(mapped)
 diagnostic=out/'reflected-exterior-diagnostic.msh'
 meshio.write(diagnostic,meshio.Mesh(np.array(vertices),[('triangle',np.array(reflected))]),file_format='gmsh22',binary=False)
 integrity=surface_integrity(diagnostic,maximum_triangles=20000)
 assert math.isclose(integrity['enclosed_volume_m3'],4*volume,rel_tol=.02)
 result['reflected_surface_validation']=integrity|{'maximum_plane_roundoff_snap_m':max_snap,'native_input_unchanged':True}
 project=json.loads((full/'system/project.blab.json').read_text());system=project['physical_system']
 region_names={'front','rear_entry_0_positive','rear_entry_0_positive_y','exterior'}
 component_names={'throat','entry_0_positive','entry_0_positive_y'}
 system['meshes']=[v for v in system['meshes'] if v['name'] in region_names]
 system['regions']=[v for v in system['regions'] if v['id'].removeprefix('region:') in region_names]
 boundary_names={k for v in report['boundary_descriptors'].values() for k in v}|{'rigid_walls','rigid_exterior'}
 system['boundaries']=[v for v in system['boundaries'] if v['region_id'].removeprefix('region:') in region_names and v['name'] in boundary_names]
 for boundary in system['boundaries']:
  region=boundary['region_id'].removeprefix('region:');m=meshio.read(out/'meshes'/(region+'.msh'))
  boundary['group']['tag']=int(m.field_data[boundary['name']][0])
 system['components']=[v for v in system['components'] if v['name'] in component_names]
 system['excitation_ports']=[v for v in system['excitation_ports'] if v['component_id'].removeprefix('component:') in component_names]
 system['metadata']['generated_mesh_sha256']={v['id']:sha256(out/v['file']) for v in system['meshes']}
 project['symmetry']='xy';project['component_channel_by_id']={k:v for k,v in project['component_channel_by_id'].items() if k.removeprefix('component:') in component_names}
 (out/'project.blab.json').write_text(json.dumps(project,indent=2)+'\n')
 assert sha256(full/'system/project.blab.json')==study['full_project_sha256']
 result.update(status='complete_quarter_mesh_preparation',project_sha256=sha256(out/'project.blab.json'),native_simulation_executed=False,qualified=False)
except BaseException as e:
 result.update(status='failed',error=f'{type(e).__name__}: {e}');raise
finally:(out/'report.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'total_tetrahedra':sum(v['tetrahedra'] for v in result['regions']),'exterior_triangles':len(faces)},indent=2))
