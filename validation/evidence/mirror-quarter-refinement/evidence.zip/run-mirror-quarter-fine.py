"""Fixed-geometry three-level mirror-quarter discretisation experiment."""
from pathlib import Path
import argparse
import json
import subprocess
import time
from meh_studio.boundary_lab import BoundaryLabRuntime, SolveRequest, sha256, _execute
from meh_studio.optimisation import verified_assessment

root = Path.cwd(); runs = root / 'runs'
parser = argparse.ArgumentParser(); parser.add_argument('--prepare', action='store_true'); args = parser.parse_args()
source = runs / 'symmetry-validation-source'
commit = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
assert commit == '25e69a8575077df2c533ccab6db13ee4a823cc53'
assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'], text=True)
full = runs / 'tilted-entry-10mm/trial-000'
coarse_project = runs / 'mirror-quarter-refinement-6mm-mesh/project.blab.json'
coarse_evaluation = runs / 'mirror-quarter-refinement/6mm'
request = SolveRequest.model_validate_json((full / 'evaluation/request.json').read_text())
assert request.frequencies_hz == (350., 1000., 2000., 3000.)
controls = {
    'source_commit': commit, 'runner_sha256': sha256(Path(__file__)),
    'mesher_sha256': sha256(runs / 'mesh-mirror-quarter-fine.py'),
    'geometry_preparation_sha256': sha256(runs / 'mirror-quarter-reference-adaptive/report.json'),
    'full_reference': verified_assessment(full / 'system/project.blab.json', full / 'evaluation'),
    'coarse_reference': verified_assessment(coarse_project, coarse_evaluation),
    'levels': [{'name': '4mm', 'interior_m': .004, 'exterior_m': .008}],
    'existing_coarse_level': {'interior_m': .006, 'exterior_m': .012},
    'previous_refinement_controls_sha256': sha256(runs / 'mirror-quarter-refinement-controls.json'),
    'request': request.model_dump(mode='json'),
    'field_relative_l2_limit': .02, 'bank_impedance_relative_limit': .02,
    'electrical_relative_tolerance': 1e-8,
    'comparison': 'All matching observation and transducer complex vectors, separately per frequency and excitation; each adjacent mesh pair and each quarter model versus coherent full-model groups. No gain, phase or delay fitting.',
    'backend': 'coupled_reference', 'julia_threads': 2, 'solver_timeout_s': 1800,
    'maximum_exterior_triangles': 5000, 'maximum_total_tetrahedra': 500000,
    'qualified': False, 'physical_validation': False,
    'limitations': ['Four diagnostic frequencies and synthetic sources only',
                   'The existing full reference has not itself demonstrated mesh convergence',
                   'Agreement of two meshes cannot independently establish physical accuracy',
                   'Only even-XY excitation groups are represented; individual asymmetric mid excitation is unavailable']}
cp = runs / 'mirror-quarter-fine-controls.json'
if args.prepare:
    with cp.open('x') as stream: stream.write(json.dumps(controls, indent=2) + '\n')
    print(json.dumps({'controls_sha256': sha256(cp), 'levels': controls['levels']}, indent=2))
    raise SystemExit
assert json.loads(cp.read_text()) == controls
native = runs / 'runtime'
runtime = BoundaryLabRuntime(native / 'boundary-lab', native / 'blab-env/bin/python',
                             native / 'julia-1.12.6/bin/julia', 'coupled_reference', julia_threads=2)
out = runs / 'mirror-quarter-fine'; out.mkdir(exist_ok=False)
rows = []
for level in controls['levels']:
    name = level['name']; mesh = runs / ('mirror-quarter-refinement-' + name + '-mesh')
    row = {'level': level, 'status': 'running'}; start = time.monotonic()
    try:
        if not mesh.exists():
            _execute([str(root / '.venv/bin/python'), str(runs / 'mesh-mirror-quarter-fine.py'),
                      '--level', name], root, out / (name + '-mesh.log'), 900)
        prepared = json.loads((mesh / 'report.json').read_text())
        assert prepared['status'] == 'complete_quarter_mesh_preparation'
        inputs = {'project.blab.json': sha256(mesh / 'project.blab.json')} | {
            str(p.relative_to(mesh)): sha256(p) for p in sorted((mesh / 'meshes').glob('*.msh'))}
        assert prepared['project_sha256'] == inputs['project.blab.json']
        row.update(preparation_report_sha256=sha256(mesh / 'report.json'), inputs_sha256=inputs)
        (out / (name + '-inputs.json')).write_text(json.dumps(row, indent=2) + '\n')
        runtime.solve(mesh / 'project.blab.json', request, out / name, timeout_s=controls['solver_timeout_s'])
        row.update(status='complete', evidence=verified_assessment(mesh / 'project.blab.json', out / name))
        assert all(sha256(mesh / path) == digest for path, digest in inputs.items())
    except Exception as error:
        row.update(status='failed', error=f'{type(error).__name__}: {error}')
    row['wall_s'] = time.monotonic() - start; rows.append(row)
    (out / 'progress.json').write_text(json.dumps({'controls_sha256': sha256(cp), 'rows': rows}, indent=2) + '\n')
assert verified_assessment(full / 'system/project.blab.json', full / 'evaluation') == controls['full_reference']
assert verified_assessment(coarse_project, coarse_evaluation) == controls['coarse_reference']
assert sha256(runs / 'mirror-quarter-reference-adaptive/report.json') == controls['geometry_preparation_sha256']
(out / 'report.json').write_text(json.dumps({'controls_sha256': sha256(cp), 'rows': rows,
    'status': 'complete' if all(row['status'] == 'complete' for row in rows) else 'failed',
    'qualified': False, 'physical_validation': False}, indent=2) + '\n')
print(json.dumps([{'level': row['level'], 'status': row['status'], 'wall_s': row['wall_s'],
                   'error': row.get('error')} for row in rows], indent=2))
