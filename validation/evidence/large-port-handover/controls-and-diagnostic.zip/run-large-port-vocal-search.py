"""A bounded native geometry experiment after the dense vocal sweep failed.

Larger ports and reduced idealised front volume are a hypothesis, not a validated
commercial cavity. The 20 m observation radius is explicit, not far-field qualified.
"""
from pathlib import Path
import argparse,json
from meh_studio.boundary_lab import BoundaryLabRuntime,sha256
from meh_studio.catalogue import Catalogue
from meh_studio.domain import DriverRevision
from meh_studio.geometry import HornGeometry
from meh_studio.optimisation import SearchBrief,candidates,optimise
root=Path.cwd();prior=root/'runs/wide-vocal-search'
saved_path=prior/'trial-000/candidate.json';saved=json.loads(saved_path.read_text())
design=saved['design']|{'port_radius_m':.032,'front_depth_m':.0015}
base=HornGeometry.model_validate(design)
drivers=[DriverRevision.model_validate(d) for d in saved['driver_revisions']]
controls=json.loads((prior/'brief.json').read_text());controls.update(trial_budget=1)
controls['acoustic_objectives']['observation_distance_m']=20.
brief=SearchBrief.model_validate(controls)
assert candidates(brief,base,drivers)[0]['design'].content_hash==base.content_hash
assert brief.acoustic_objectives.minimum_bank_impedance_ohm==2.
assert brief.acoustic_objectives.acoustic_handover_hz==(3000.,5000.)
provenance={'application_source_commit':'c36e357','source_worktree':'runs/partial-frequency-reviewed-source',
    'reference_candidate_sha256':sha256(saved_path),'reference_derived_score_sha256':sha256(root/'runs/wide-vocal-derived-score.json'),
    'geometry_changes':{'port_radius_m':[saved['design']['port_radius_m'],base.port_radius_m],
        'front_depth_m':[saved['design']['front_depth_m'],base.front_depth_m]},
    'observation_distance_m':20.,'trial_budget':1,'solver_stage_timeout_s':7200,
    'hypothesis':'Larger ports and less idealised front-cavity volume may reduce midband attenuation; geometry and distance effects require separate comparison',
    'response_screen_limit_db':6.,'qualified':False,
    'limitations':['Reported mid circuits, synthetic HF and idealised source/cavity shapes',
        'Front depth is not a measured cone/phase-plug air volume; no commercial fit claim',
        '15 training frequencies, no holdout, no mesh convergence, no established far-field distance',
        'One guided mutation is not a completed evolutionary search or a global optimum']}
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');args=parser.parse_args()
    (root/'runs/large-port-vocal-controls.json').write_text(json.dumps({'brief':brief.model_dump(mode='json'),
        'base':base.model_dump(mode='json'),'provenance':provenance},indent=2)+'\n')
    if args.prepare:print(json.dumps(provenance,indent=2))
    else:
        database=root/'runs/large-port-vocal-search.sqlite';native=root/'runs/runtime'
        with Catalogue.create(database) as catalogue:
            for driver in drivers:catalogue.add(driver)
        runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',native/'julia-1.12.6/bin/julia',
            'beat_cpu',julia_threads=4)
        output=root/'runs/large-port-vocal-search'
        result=optimise(brief,base,database,runtime,output,solver_stage_timeout_s=7200)
        (output/'experiment-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
        print(json.dumps(result,indent=2))
