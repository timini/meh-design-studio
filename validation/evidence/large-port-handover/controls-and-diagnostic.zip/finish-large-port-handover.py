"""Preserve the failed target experiment; never promote it to a completed search."""
from pathlib import Path
import json
import zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter
from meh_studio.boundary_lab import sha256
from meh_studio.optimisation import verified_assessment
from meh_studio.partial_results import verify_frequency_assembly

root = Path.cwd()
search = root / 'runs/large-port-vocal-search'
trial = search / 'trial-000'
diagnostic_path = root / 'runs/large-port-handover-diagnostic.json'
diagnostic = json.loads(diagnostic_path.read_text())
state = json.loads((search / 'search.json').read_text())
assert state['status'] == state['trials'][0]['status'] == 'failed'
assert '252 handover rejections' in state['trials'][0]['error']
assert sha256(search / 'search.json') == diagnostic['search_sha256']
assert sha256(search / 'brief.json') == diagnostic['brief_sha256']
identity = verified_assessment(trial / 'system/project.blab.json', trial / 'evaluation')
assert identity == diagnostic['evidence_identity']
manifest = json.loads((trial / 'evaluation/upstream/manifest.json').read_text())
assert manifest['status'] == 'complete'
assert len(manifest['results']) == len(diagnostic['frequencies_hz']) == 15
assert all(not row['continuous_interval_exists'] for row in diagnostic['gain_feasibility'])

old_path = root / 'runs/wide-vocal-midbank-diagnostic.json'
old = json.loads(old_path.read_text())
assembly_path = root / 'runs/wide-vocal-frequency-assembly-reviewed.json'
assembly = json.loads(assembly_path.read_text())
verify_frequency_assembly(assembly)
assert sha256(assembly_path) == old['assembly_sha256']
distance = root / 'runs/wide-vocal-distance'
projection = json.loads((distance / 'report.json').read_text())
assert sha256(distance / 'report.json') == old['projection_report_sha256']
assert sha256(distance / 'trial-000/result.npz') == projection['projection_result_sha256']
assert sha256(distance / 'controls.json') == projection['controls_sha256']
assert old['frequencies_hz'] == diagnostic['frequencies_hz']
freq = np.asarray(old['frequencies_hz'])
new_mid = np.asarray(diagnostic['unfiltered_common_mid_magnitude_pa_per_native_basis']) / 2.83
old_mid = np.asarray(old['mid_excitation_coherent_sum_pa_per_v'])

fig, axes = plt.subplots(2, 1, figsize=(9, 6.8), sharex=True, layout='constrained')
for label, magnitude, cancellation, color in (
    ('Original ports / cavity', old_mid, old['coherent_sum_relative_to_magnitude_sum_db'], '#27639c'),
    ('32 mm ports / 1.5 mm front depth', new_mid, diagnostic['mid_excitation_cancellation_db'], '#ba4a28'),
):
    axes[0].semilogx(freq, 20*np.log10(magnitude), '.-', label=label, color=color)
    axes[1].semilogx(freq, cancellation, '.-', color=color)
axes[0].set_ylabel('Mid pressure transfer\ndB re 1 Pa per native volt')
axes[0].legend(loc='lower left', fontsize=9)
axes[1].set_ylabel('Coherent sum / magnitude sum (dB)')
axes[1].set_xlabel('Frequency (Hz) — sampled points joined for readability')
for ax in axes:
    ax.grid(alpha=.25)
    ax.axvspan(3000, 5000, color='grey', alpha=.1)
axes[1].set_xticks([350, 700, 1000, 1500, 2000, 3000, 5000, 7500],
                  ['350', '700', '1,000', '1,500', '2,000', '3,000', '5,000', '7,500'])
axes[1].xaxis.set_minor_formatter(NullFormatter())
fig.suptitle('Larger ports and a shallower cavity did not solve the handover\n'
             '20 m axis; four coupled mid excitations; before DSP; synthetic HF', fontsize=12)
plot = root / 'docs/assets/large-port-handover.png'
fig.savefig(plot, dpi=160)
plt.close(fig)

target = root / 'validation/evidence/large-port-handover'
target.mkdir(parents=True, exist_ok=True)
groups = {}
files, total, part = [], 0, 0
for path in sorted(search.rglob('*')):
    if not path.is_file():
        continue
    size = path.stat().st_size
    assert size < 90_000_000
    if total + size > 85_000_000 and files:
        groups[f'failed-search-{part:02d}'] = files
        files, total, part = [], 0, part + 1
    files.append((path, str(path.relative_to(root / 'runs'))))
    total += size
if files:
    groups[f'failed-search-{part:02d}'] = files
names = ('run-large-port-vocal-search.py', 'large-port-vocal-controls.json',
         'large-port-vocal-search.log', 'diagnose-large-port-handover.py',
         'large-port-handover-diagnostic.json', 'large-port-handover-diagnostic.log',
         'finish-large-port-handover.py', 'wide-vocal-midbank-diagnostic.json')
groups['controls-and-diagnostic'] = [(root / 'runs' / name, name) for name in names]
archives = []
for label, files in groups.items():
    path = target / (label + '.zip')
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for source, name in files:
            archive.write(source, name)
    assert path.stat().st_size < 100_000_000
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
    archives.append({'file': path.name, 'sha256': sha256(path), 'size_bytes': path.stat().st_size})
report = {
    'status': 'completed_native_solve_rejected_by_handover',
    'application_source_commits': {'native_search': 'c36e357', 'diagnostic': 'ab6714f',
                                   'archival_runner_base': '014e047'},
    'archives': archives, 'search_status': state['status'], 'trial_status': state['trials'][0]['status'],
    'native_status': manifest['status'], 'frequencies_hz': diagnostic['frequencies_hz'],
    'gain_feasibility': diagnostic['gain_feasibility'],
    'minimum_parallel_mid_impedance_magnitude_ohm': diagnostic['parallel_mid_bank']['minimum_impedance_magnitude_ohm'],
    'diagnostic_sha256': sha256(diagnostic_path), 'comparison_baseline_sha256': sha256(old_path),
    'comparison_baseline_archive_report': '../periodic-profile-symmetry/report.json',
    'plot_sha256': sha256(plot), 'winner': None, 'qualified': False, 'physical_validation': False,
    'limitations': [
        'The native solve completed all 15 frequencies, but the search and trial failed scoring and remain failed',
        'No gain can satisfy this LR4 family and the declared sampled 3-to-5 kHz handover; other filter families are not excluded',
        'No selected DSP, valid winning response score, or winning export is asserted',
        'Port radius and idealised cavity depth changed together; this does not isolate their physical effects',
        'Exploratory complex64 storage does not qualify the unchanged 1e-8 electrical consistency gate',
        'Reported mid circuits, synthetic HF, idealised cavities, finite 20 m observations; no commercial source, fit, print, convergence or physical qualification',
    ],
}
(target / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
assert verified_assessment(trial / 'system/project.blab.json', trial / 'evaluation') == identity
assert sha256(search / 'search.json') == diagnostic['search_sha256']
print(json.dumps({'archives': archives, 'gain_feasibility': report['gain_feasibility']}, indent=2))
