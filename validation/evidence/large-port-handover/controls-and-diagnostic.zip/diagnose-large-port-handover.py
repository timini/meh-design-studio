"""Diagnose a completed native solve whose declared DSP grid has no feasible result."""
from pathlib import Path
import json
import numpy as np
from meh_studio.boundary_lab import sha256,_contained
from meh_studio.optimisation import verified_assessment
from meh_studio.acoustic_objectives import AcousticObjectives,lr4,parallel_bank
root=Path.cwd();search=root/'runs/large-port-vocal-search';trial=search/'trial-000';project_path=trial/'system/project.blab.json';evaluation=trial/'evaluation';raw=evaluation/'upstream'
evidence=verified_assessment(project_path,evaluation)
brief_path=search/'brief.json';brief=json.loads(brief_path.read_text());objectives=AcousticObjectives.model_validate(brief['acoustic_objectives'])
project=json.loads(project_path.read_text());manifest=json.loads((raw/'manifest.json').read_text())
ports={p['id']:p['component_id'] for p in project['physical_system']['excitation_ports']};ids=[ports[p] for p in manifest['excitation_port_ids']]
domains=json.loads(_contained(raw,manifest['domains_metadata_file']).read_text())['domains']
with np.load(_contained(raw,manifest['domains_file']),allow_pickle=False) as data:
    d=next(d for d in domains if d['id']=='observation:horizontal-polar');angles=data[d['coordinates']['angle_deg']].copy()
axis=np.flatnonzero(angles==0);assert len(axis)==1
pressure=[];currents=[]
for row in manifest['results']:
    meta=json.loads(_contained(raw,row['metadata_file']).read_text());q={v['id']:v for v in meta['quantities']}
    assert meta['diagnostics']['transducer_reference_voltage_v']==2.83
    with np.load(_contained(raw,row['arrays_file']),allow_pickle=False) as data:
        pressure.append(data[q['acoustic:pressure:horizontal-polar']['key']][:,axis[0]].astype(complex))
        quantity=q['electrical:voice-coil-current'];order=quantity['metadata']['component_ids']
        currents.append(data[quantity['key']][:,[order.index(c) for c in ids]].copy())
freq=np.array(manifest['frequencies_hz']);pressure=np.asarray(pressure)
hf_index=ids.index('component:throat');mids=[i for i in range(len(ids)) if i!=hf_index]
mid=pressure[:,mids].sum(axis=1);hf=pressure[:,hf_index];low,high=objectives.acoustic_handover_hz
mid_mask=(freq>=objectives.mid_highpass_hz)&(freq<=low);hf_mask=freq>=high
intervals=[]
for crossover in objectives.upper_crossovers_hz:
    mid_unit=abs(mid*lr4(freq,objectives.mid_highpass_hz,'highpass')*lr4(freq,crossover,'lowpass'))
    hf_unit=abs(hf*lr4(freq,crossover,'highpass'))
    assert np.all(mid_unit>0) and np.all(hf_unit>0)
    ratio=hf_unit/mid_unit;minimum=float(ratio[mid_mask].max());maximum=float(ratio[hf_mask].min())
    lower=max(minimum,min(brief['side_gains']));upper=min(maximum,max(brief['side_gains']))
    intervals.append({'upper_crossover_hz':crossover,'minimum_mid_gain_for_mid_dominance':minimum,
        'maximum_mid_gain_for_hf_dominance':maximum,'lower_bound_frequency_hz':float(freq[mid_mask][ratio[mid_mask].argmax()]),
        'upper_bound_frequency_hz':float(freq[hf_mask][ratio[hf_mask].argmin()]),
        'continuous_interval_exists':minimum<=maximum,'interval_within_declared_gain_span_exists':lower<=upper,
        'feasible_declared_gains':[g for g in brief['side_gains'] if minimum<=g<=maximum]})
report={'status':'complete','application_source_commit':'ab6714f','runner_sha256':sha256(Path(__file__)),
    'evidence_identity':evidence,'search_sha256':sha256(search/'search.json'),'brief_sha256':sha256(brief_path),
    'frequencies_hz':freq.tolist(),'gain_feasibility':intervals,
    'unfiltered_common_mid_magnitude_pa_per_native_basis':abs(mid).tolist(),'unfiltered_hf_magnitude_pa_per_native_basis':abs(hf).tolist(),
    'mid_excitation_cancellation_db':(20*np.log10(abs(mid)/abs(pressure[:,mids]).sum(axis=1))).tolist(),
    'parallel_mid_bank':parallel_bank(currents,ids),'qualified':False,'physical_validation':False,
    'definition':'Channel magnitude handover bounds before polarity/delay selection; phases cannot change each separate channel magnitude. These are not output or amplifier power limits.',
    'original_failed_search_modified':False}
assert verified_assessment(project_path,evaluation)==evidence
(root/'runs/large-port-handover-diagnostic.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(intervals,indent=2))
