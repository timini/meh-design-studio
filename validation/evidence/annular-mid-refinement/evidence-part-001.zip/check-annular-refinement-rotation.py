"""Independent C4 checks on the declared plain/annular coupled native cases."""
from pathlib import Path
import json
import numpy as np
from meh_studio.boundary_lab import sha256,_contained
from meh_studio.optimisation import verified_assessment
root=Path.cwd();cp=root/'runs/annular-entry-refinement-resume-controls.json';controls=json.loads(cp.read_text());limit=controls['rotational_field_relative_limit'];reports=[]
def difference(left,right):
 norm=float(np.linalg.norm(left));absolute=float(np.linalg.norm(right-left))
 error=absolute/norm if norm else None
 return {'relative_complex_norm_error':error,'reference_norm':norm,'absolute_error':absolute,'passed':bool(np.isfinite(error) and error<=limit) if error is not None else absolute==0.}
for case in ['refined']:
 p=root/'runs/annular-entry-refinement-resumed'/case;raw=p/'evaluation/upstream';project=p/'system/project.blab.json'
 evidence=verified_assessment(project,p/'evaluation');manifest=json.loads((raw/'manifest.json').read_text())
 domains=json.loads(_contained(raw,manifest['domains_metadata_file']).read_text())['domains']
 with np.load(_contained(raw,manifest['domains_file']),allow_pickle=False) as arrays:
  points=np.vstack([arrays[next(d for d in domains if d['id']==f'observation:{plane}-polar')['coordinates']['points_m']] for plane in ['horizontal','vertical']])
 rotated=points[:,[1,0,2]].copy();rotated[:,0]*=-1
 distances=np.linalg.norm(rotated[:,None,:]-points[None,:,:],axis=2);mapping=distances.argmin(axis=1)
 assert float(distances.min(axis=1).max())<1e-10
 rows=[]
 for result in manifest['results']:
  metadata=json.loads(_contained(raw,result['metadata_file']).read_text());q={v['id']:v for v in metadata['quantities']}
  ids=q['mechanical:diaphragm-velocity']['metadata']['component_ids'];perm=[ids.index({'component:throat':'component:throat','component:entry_0_positive':'component:entry_0_positive_y','component:entry_0_positive_y':'component:entry_0_positive'}[x]) for x in ids]
  with np.load(_contained(raw,result['arrays_file']),allow_pickle=False) as arrays:
   pressure=np.concatenate([arrays[q[f'acoustic:pressure:{plane}-polar']['key']] for plane in ['horizontal','vertical']],axis=1)
   checks={name:difference(pressure[i],pressure[perm[i],mapping]) for i,name in enumerate(ids)}
   for name in ['mechanical:diaphragm-velocity','electrical:voice-coil-current']:
    matrix=arrays[q[name]['key']];assert q[name]['metadata']['component_ids']==ids
    checks[name]=difference(matrix,matrix[perm][:,perm])
  rows.append({'frequency_hz':result['freq_hz'],'checks':checks,'passed':all(x['passed'] for x in checks.values())})
 assert verified_assessment(project,p/'evaluation')==evidence
 reports.append({'case':case,'native_evidence':evidence,'frequencies':rows,'passed':all(r['passed'] for r in rows)})
report={'application_source_commit':controls['application_source_commit'],'controls_sha256':sha256(cp),'runner_sha256':sha256(Path(__file__)),'relative_limit':limit,'cases':reports,'passed':all(r['passed'] for r in reports),'qualified':False,'limitations':controls['limitations']}
with (root/'runs/annular-refinement-rotation.json').open('x') as f:f.write(json.dumps(report,indent=2)+'\n')
for r in reports:
 print(r['case'],r['passed'],max(v['relative_complex_norm_error'] for row in r['frequencies'] for v in row['checks'].values() if v['relative_complex_norm_error'] is not None))
