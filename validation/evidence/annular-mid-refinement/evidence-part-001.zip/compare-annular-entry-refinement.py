"""Same-CAD 4 kHz native field comparison at the predeclared 2% limit."""
from pathlib import Path
import json
import numpy as np
from meh_studio.boundary_lab import sha256
from meh_studio.optimisation import verified_assessment
from meh_studio.radiation_geometry import step_geometry_sha256

root = Path.cwd()
cp = root / 'runs/annular-entry-refinement-resume-controls.json'
controls = json.loads(cp.read_text())
paths = {'coarse': root / 'runs/annular-entry-native/annular',
         'refined': root / 'runs/annular-entry-refinement-resumed/refined'}
steps = {}
original = json.loads((paths['coarse'] / 'geometry/geometry.json').read_text())
for row in original['files']:
    if row['path'].endswith('.step'):
        a = step_geometry_sha256(paths['coarse'] / 'geometry' / row['path'])
        b = step_geometry_sha256(paths['refined'] / 'geometry' / row['path'])
        assert a == b
        steps[row['path']] = a
values, evidence, coordinates, orders = {}, {}, {}, {}
for name, p in paths.items():
    prepared = json.loads((p / 'prepared.json').read_text())
    assert all(sha256(p / rel) == value for rel, value in prepared['input_sha256'].items())
    evidence[name] = verified_assessment(p / 'system/project.blab.json', p / 'evaluation')
    raw = p / 'evaluation/upstream'
    manifest = json.loads((raw / 'manifest.json').read_text())
    result = next(row for row in manifest['results'] if row['freq_hz'] == 4000.)
    metadata = json.loads((raw / result['metadata_file']).read_text())
    q = {v['id']: v for v in metadata['quantities']}
    orders[name] = [manifest['excitation_port_ids'],
        q['mechanical:diaphragm-velocity']['metadata']['component_ids'],
        q['electrical:voice-coil-current']['metadata']['component_ids']]
    with np.load(raw / result['arrays_file'], allow_pickle=False) as arrays:
        values[name] = {key: arrays[q[key]['key']].copy() for key in [
            'mechanical:diaphragm-velocity', 'electrical:voice-coil-current',
            'acoustic:pressure:horizontal-polar', 'acoustic:pressure:vertical-polar']}
    domains = json.loads((raw / manifest['domains_metadata_file']).read_text())['domains']
    with np.load(raw / manifest['domains_file'], allow_pickle=False) as arrays:
        coordinates[name] = [arrays[next(d for d in domains if d['id'] == f'observation:{plane}-polar')['coordinates']['points_m']].copy()
                             for plane in ['horizontal', 'vertical']]
assert orders['coarse'] == orders['refined']
assert all(np.array_equal(a, b) for a, b in zip(coordinates['coarse'], coordinates['refined']))
checks = {}
for key, value in values['coarse'].items():
    norm = float(np.linalg.norm(value))
    difference = float(np.linalg.norm(values['refined'][key] - value))
    error = difference / norm if norm else None
    checks[key] = {'reference_norm': norm, 'difference_norm': difference,
        'relative_complex_norm_error': error,
        'passed': bool(np.isfinite(error) and error <= controls['field_change_relative_limit']) if error is not None else difference == 0.}
assert evidence == {name: verified_assessment(p / 'system/project.blab.json', p / 'evaluation') for name, p in paths.items()}
report = {'application_source_commit': controls['application_source_commit'],
    'runner_sha256': sha256(Path(__file__)), 'controls_sha256': sha256(cp),
    'frequency_hz': 4000., 'unchanged_step_geometry_sha256': steps,
    'native_evidence': evidence, 'checks': checks,
    'relative_limit': controls['field_change_relative_limit'],
    'passed': all(v['passed'] for v in checks.values()), 'qualified': False,
    'limitations': controls['limitations']}
with (root / 'runs/annular-refinement-comparison.json').open('x') as stream:
    stream.write(json.dumps(report, indent=2) + '\n')
print(json.dumps({'passed': report['passed'], 'checks': checks}, indent=2))
