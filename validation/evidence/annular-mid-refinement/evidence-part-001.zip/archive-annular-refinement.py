"""Retain failed preparation, reused native refinement, and unchanged limits."""
from pathlib import Path
import hashlib
import json
import zipfile

root = Path.cwd(); runs = root / 'runs'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
controls = json.loads((runs / 'annular-entry-refinement-resume-controls.json').read_text())
comparison = json.loads((runs / 'annular-refinement-comparison.json').read_text())
rotation = json.loads((runs / 'annular-refinement-rotation.json').read_text())
force = json.loads((runs / 'annular-refinement-refined-force-balance.json').read_text())
prior = runs / 'annular-entry-refinement/refined'
native = runs / 'annular-entry-refinement-resumed/refined'
assert all(digest(prior / name) == value == digest(native / name)
           for name, value in controls['retained_input_sha256'].items())
assert comparison['application_source_commit'] == controls['application_source_commit']
assert comparison['controls_sha256'] == rotation['controls_sha256'] == force['controls_sha256'] == digest(runs / 'annular-entry-refinement-resume-controls.json')
paths = [p for folder in [prior.parent, native.parent] for p in folder.rglob('*') if p.is_file()]
paths += [runs / name for name in [
    'run-annular-entry-refinement.py', 'annular-entry-refinement-controls.json', 'annular-entry-refinement.log',
    'resume-annular-entry-refinement.py', 'annular-entry-refinement-resume-controls.json', 'annular-entry-refinement-resumed.log',
    'check-annular-refinement-force.py', 'annular-refinement-refined-force-balance.json', 'annular-refinement-force.log',
    'check-annular-refinement-rotation.py', 'annular-refinement-rotation.json', 'annular-refinement-rotation.log',
    'compare-annular-entry-refinement.py', 'annular-refinement-comparison.json', 'annular-refinement-comparison.log',
    'archive-annular-refinement.py']]
members = {p.relative_to(runs).as_posix(): p for p in sorted(set(paths))}
members['upstream-LICENSE'] = runs / 'runtime/boundary-lab/LICENSE'
identities = {name: digest(p) for name, p in members.items()}
out = root / 'validation/evidence/annular-mid-refinement'; out.mkdir(exist_ok=False)
groups = [[]]; size = 0
for name, p in members.items():
    if groups[-1] and size + p.stat().st_size > 60_000_000:
        groups.append([]); size = 0
    groups[-1].append((name, p)); size += p.stat().st_size
archives, verified = [], {}
for index, group in enumerate(groups):
    archive = out / f'evidence-part-{index:03d}.zip'
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, p in group: z.write(p, name)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        verified.update({name: hashlib.sha256(z.read(name)).hexdigest() for name in z.namelist()})
    archives.append({'file': archive.name, 'size_bytes': archive.stat().st_size, 'sha256': digest(archive)})
assert identities == verified == {name: digest(p) for name, p in members.items()}
summary = {'tetrahedra': controls['actual_tetrahedra'],
    'exterior_triangles': controls['actual_final_exterior_triangles'],
    'original_preparation_compute_cap': 3000, 'resumed_compute_cap': 4000,
    'pressure_force_passed': force['passed'],
    'maximum_force_relative_residual': max(row['force_equation_relative_residual'] for row in force['rows']),
    'rotation_passed': rotation['passed'],
    'maximum_rotational_relative_error': max(v['relative_complex_norm_error'] for c in rotation['cases'] for row in c['frequencies'] for v in row['checks'].values()),
    'coarse_refined_comparison_passed': comparison['passed'], 'field_checks': comparison['checks'],
    'unchanged_step_files': len(comparison['unchanged_step_geometry_sha256'])}
report = {'status': 'evidence_preserved', 'application_source_commit': controls['application_source_commit'],
    'controls_sha256': digest(runs / 'annular-entry-refinement-resume-controls.json'),
    'coarse_reference': {'report': '../annular-mid-entry/report.json',
        'report_sha256': digest(root / 'validation/evidence/annular-mid-entry/report.json'),
        'archive_sha256': digest(root / 'validation/evidence/annular-mid-entry/evidence.zip')},
    'archives': archives, 'archived_file_sha256': identities, 'summary': summary,
    'qualified': False, 'physical_validation': False, 'limitations': controls['limitations']}
(out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'archives': archives, 'files': len(members), 'summary': summary}, indent=2))
