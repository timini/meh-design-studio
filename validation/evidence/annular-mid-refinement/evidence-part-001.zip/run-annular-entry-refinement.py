"""Single-frequency declared mesh refinement of the failed annular native field."""
EXPECTED_SOURCE_COMMIT = '381eb8cb8ef14b1feb27bb7586bbcb34f50ff093'
from pathlib import Path
import argparse,json,subprocess
from meh_studio.geometry import HornGeometry,export_geometry,mesh_geometry
from meh_studio.generated_system import HornSources
from meh_studio.radiating_system import compile_radiating_system
from meh_studio.boundary_lab import BoundaryLabRuntime,SolveRequest,sha256
from meh_studio.optimisation import verified_assessment
root=Path.cwd();runs=root/'runs';source=runs/'annular-entry-source'
args=argparse.ArgumentParser();args.add_argument('stage',choices=['controls','run']);args=args.parse_args()
commit=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
assert commit == EXPECTED_SOURCE_COMMIT
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True)
import meh_studio.geometry
assert Path(meh_studio.geometry.__file__).resolve().is_relative_to(source)
gp=runs/'annular-entry-native-controls.json'
original=json.loads(gp.read_text())
base=original['designs']['annular'] | {'mesh_size_m':.006,'rear_axial_mesh_size_m':.001}
refined=HornGeometry.model_validate(base)
sources=HornSources.model_validate(original['sources'])
request=SolveRequest(frequencies_hz=(4000.,),include_project_observations=True,
    retain=('fem_nodal_pressure','bem_boundary_traces'))
controls={'application_source_commit':commit,'runner_sha256':sha256(Path(__file__)),
 'prior_controls_sha256':sha256(gp),'sources':sources.model_dump(mode='json'),
 'designs':{'refined':refined.model_dump(mode='json')},
 'request':request.model_dump(mode='json'),'backend':'coupled_reference','julia_threads':1,
 'maximum_total_tetrahedra':220000,'maximum_final_exterior_triangles':3000,'exterior_mesh_size_m':.02,
 'electrical_relative_limit':1e-8,'force_balance_relative_limit':1e-8,'rotational_field_relative_limit':.02,
 'qualified':False,
 'scope':'One 4kHz refinement of the retained annular case: front8to6mm, rear2to1mm, exterior20mmunchanged. Same physical CAD and source circuits. Test whether the failed rotational field check improves; retain the original failure.',
 'hypothesis':'The annular 4kHz dip and 108.6% rotational relative error require mesh investigation before any quantitative acoustic use.',
 'field_change_relative_limit':.02,
 'limitations':['One frequency and one refinement do not establish band convergence.',
 'Both front and rear meshes change; this does not isolate either contribution.',
 'Public T/S data with rigid pistons and provisional HF outlet transform; no physical or print qualification.']}
cp=runs/'annular-entry-refinement-controls.json'
if args.stage=='controls':
 with cp.open('x') as f:f.write(json.dumps(controls,indent=2)+'\n')
 print(sha256(cp));raise SystemExit
assert json.loads(cp.read_text())==controls
out=runs/'annular-entry-refinement';out.mkdir(exist_ok=False)
native=runs/'runtime';runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',native/'julia-1.12.6/bin/julia','coupled_reference',julia_threads=1)
for name,design in [('refined',refined)]:
 p=out/name;p.mkdir()
 export_geometry(design,p/'geometry');mesh=mesh_geometry(p/'geometry')
 total=sum(r['tetrahedra'] for r in mesh['regions']);assert total<=controls['maximum_total_tetrahedra']
 report=compile_radiating_system(p/'geometry',sources,p/'system',runtime,exterior_mesh_size_m=.02,timeout_s=1800)
 import meshio
 surface=meshio.read(p/'system/meshes/exterior.msh');triangles=sum(len(c.data) for c in surface.cells if c.type=='triangle')
 assert triangles<=controls['maximum_final_exterior_triangles']
 identities={q.relative_to(p).as_posix():sha256(q) for dirname in ('geometry','system') for q in (p/dirname).rglob('*') if q.is_file()}
 (p/'prepared.json').write_text(json.dumps({'controls_sha256':sha256(cp),'tetrahedra':total,'triangles':triangles,'input_sha256':identities},indent=2)+'\n')
 print(name,'prepared',total,triangles,flush=True)
 runtime.solve(p/'system/project.blab.json',request,p/'evaluation',timeout_s=1800)
 assert identities=={rel:sha256(p/rel) for rel in identities}
 assessment=verified_assessment(p/'system/project.blab.json',p/'evaluation')
 (p/'native-assessment.json').write_text(json.dumps({'controls_sha256':sha256(cp),'assessment':assessment,'qualified':False},indent=2)+'\n')
 print(name,'complete','electrical',assessment['checks']['passed'],flush=True)
