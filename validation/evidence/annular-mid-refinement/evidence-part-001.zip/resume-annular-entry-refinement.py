"""Reuse retained prepared meshes under a separately declared compute cap."""
from pathlib import Path
import json
import shutil
import subprocess
import meshio
from meh_studio.boundary_lab import BoundaryLabRuntime, SolveRequest, sha256
from meh_studio.optimisation import verified_assessment
from meh_studio.radiation_geometry import step_geometry_sha256

root = Path.cwd(); runs = root / 'runs'
source = runs / 'annular-entry-source'
prior = runs / 'annular-entry-refinement/refined'
controls_path = runs / 'annular-entry-refinement-controls.json'
controls = json.loads(controls_path.read_text())
assert subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip() == controls['application_source_commit']
assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'], text=True)
assert not (prior / 'evaluation').exists()
mesh = json.loads((prior / 'geometry/analysis/mesh.json').read_text())
total = sum(row['tetrahedra'] for row in mesh['regions'])
surface = meshio.read(prior / 'system/meshes/exterior.msh')
triangles = sum(len(cell.data) for cell in surface.cells if cell.type == 'triangle')
assert total <= controls['maximum_total_tetrahedra']
assert controls['maximum_final_exterior_triangles'] < triangles <= 4000
identities = {p.relative_to(prior).as_posix(): sha256(p) for folder in ['geometry', 'system'] for p in (prior / folder).rglob('*') if p.is_file()}
coarse = runs / 'annular-entry-native/annular/geometry'
original_geometry = json.loads((coarse / 'geometry.json').read_text())
for row in original_geometry['files']:
    if row['path'].endswith('.step'):
        assert step_geometry_sha256(coarse / row['path']) == step_geometry_sha256(prior / 'geometry' / row['path'])
controls.update(runner_sha256=sha256(Path(__file__)),
    failed_preparation_controls_sha256=sha256(controls_path),
    failed_preparation_log_sha256=sha256(runs / 'annular-entry-refinement.log'),
    retained_input_sha256=identities, maximum_final_exterior_triangles=4000,
    actual_tetrahedra=total, actual_final_exterior_triangles=triangles,
    preparation_reused=True,
    resource_change='Explicit 3000-to-4000 exterior triangle compute cap; no acceptance limits changed.')
controls['limitations'].append('The exterior target stays20mm but its actual triangulation changes with the refined mouth interface (2254to3332panels); this is a combined discretisation comparison.')
cp = runs / 'annular-entry-refinement-resume-controls.json'
with cp.open('x') as stream: stream.write(json.dumps(controls, indent=2) + '\n')
p = runs / 'annular-entry-refinement-resumed/refined'
p.mkdir(parents=True, exist_ok=False)
for folder in ['geometry', 'system']: shutil.copytree(prior / folder, p / folder)
assert identities == {name: sha256(p / name) for name in identities}
(p / 'prepared.json').write_text(json.dumps({'controls_sha256': sha256(cp),
    'tetrahedra': total, 'triangles': triangles, 'input_sha256': identities}, indent=2) + '\n')
native = runs / 'runtime'
runtime = BoundaryLabRuntime(native / 'boundary-lab', native / 'blab-env/bin/python',
    native / 'julia-1.12.6/bin/julia', 'coupled_reference', julia_threads=1)
print('reused preparation', total, triangles, sha256(cp), flush=True)
runtime.solve(p / 'system/project.blab.json', SolveRequest.model_validate(controls['request']), p / 'evaluation', timeout_s=1800)
assert identities == {name: sha256(prior / name) for name in identities}
assert identities == {name: sha256(p / name) for name in identities}
assessment = verified_assessment(p / 'system/project.blab.json', p / 'evaluation')
(p / 'native-assessment.json').write_text(json.dumps({'controls_sha256': sha256(cp),
    'assessment': assessment, 'qualified': False}, indent=2) + '\n')
print('complete electrical', assessment['checks']['passed'], flush=True)
