"""Predeclare two curved commercial-circuit searches; execute one at a time."""
from pathlib import Path
import argparse
import json
import subprocess
from meh_studio.boundary_lab import BoundaryLabRuntime, sha256
from meh_studio.catalogue import Catalogue
from meh_studio.domain import DriverRevision
from meh_studio.geometry import HornGeometry
from meh_studio.generated_system import HornSources
from meh_studio.optimisation import SearchBrief, candidates, optimise
from meh_studio.evolution import validate_bounds

root = Path.cwd()
parser = argparse.ArgumentParser()
parser.add_argument('--prepare', action='store_true')
parser.add_argument('--case', choices=['exponential-round', 'quadratic-rounded-square'])
args = parser.parse_args()
assert args.prepare != bool(args.case), 'choose --prepare or one --case'
source = root / 'runs/curved-mouth-source'
commit = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
assert commit == '5c5fab109c7ae169582d7330b157bf068c46ef0a'
assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'], text=True)
import meh_studio.geometry
assert Path(meh_studio.geometry.__file__).resolve().is_relative_to(source)
seed_path = root / 'runs/nonlinear-flare-rebuild-controls.json'
seed_controls = json.loads(seed_path.read_text())
prepared = root / 'runs/nonlinear-flare-rebuild/report.json'
prepared_report = json.loads(prepared.read_text())
assert prepared_report['status'] == 'complete'
assert all(row['status'] == 'complete' for row in prepared_report['rows'])
baseline = root / 'runs/quarter-turn-vocal-search/trial-000/candidate.json'
saved = json.loads(baseline.read_text())
hf_path = root / 'examples/reported-drivers/peerless-dfm2535-8-ideal-outlet.json'
hf = DriverRevision.model_validate_json(hf_path.read_text())
mid = next(DriverRevision.model_validate(d) for d in saved['driver_revisions'] if d['id']=='faitalpro-4fe32-16')
drivers = [hf, mid]
example_path = root / 'examples/provisional-commercial-wide-mid/brief.json'
cases = []
for index, seed in enumerate(seed_controls['seeds']):
    base = HornGeometry.model_validate(seed['design'])
    data = json.loads(example_path.read_text())
    data.update(trial_budget=2, seed=20260915+index,
        lengths_m=[base.length_m], mouth_radii_m=[base.mouth_radius_m],
        entry_fractions=[[z/base.length_m for z in base.entry_positions_m]],
        exterior_mesh_size_m=.01)
    data['evolution'].update(profile_scale_bounds=[.5,1.7])
    data['evolution']['geometry_bounds']['mouth_radius_m']=[.14,.18]
    brief = SearchBrief.model_validate(data)
    validate_bounds(brief.evolution, base)
    first = candidates(brief, base, drivers)[0]
    assert first['design'].content_hash == seed['design_hash']
    assert first['sources'] == HornSources.model_validate(seed_controls['sources'])
    assert brief.acoustic_objectives.minimum_bank_impedance_ohm == 2.
    assert brief.acoustic_objectives.acoustic_handover_hz == (3000.,5000.)
    assert brief.build_budget.maximum_total_cost == 300.
    cases.append({'label': seed['label'], 'base': base.model_dump(mode='json'),
        'design_hash': base.content_hash, 'brief': brief.model_dump(mode='json')})
controls = {'application_source_commit': commit, 'runner_sha256': sha256(Path(__file__)),
    'seed_controls_sha256': sha256(seed_path), 'seed_preparation_report_sha256': sha256(prepared),
    'baseline_candidate_sha256': sha256(baseline), 'hf_record_sha256': sha256(hf_path),
    'example_brief_sha256': sha256(example_path),
    'drivers': [d.model_dump(mode='json') for d in drivers], 'cases': cases,
    'solver_stage_timeout_s': 7200, 'response_screen_limit_db': 6.,
    'selection': 'Each case starts with its declared curved seed, then one fitness-driven mutation if eligible; the existing search falls back to random exploration after an ineligible seed',
    'limitations': ['Four proposals across two starts are bounded exploration, not a global optimum',
        'Provisional Peerless ideal-outlet circuit and reported Faital mids; no source qualification',
        'Complex64 exploratory solver cannot establish the separate 1e-8 electrical qualification gate',
        '15 training frequencies and 20 m observations are not holdout, convergence or far-field qualification',
        'Idealised cavities and driver interfaces do not establish basket/cone fit, output or print qualification']}
control_path = root / 'runs/nonlinear-commercial-search-controls.json'
if args.prepare:
    with control_path.open('x') as stream: stream.write(json.dumps(controls, indent=2)+'\n')
    print(json.dumps(controls, indent=2))
    raise SystemExit
assert json.loads(control_path.read_text()) == controls
for other in [root/'runs/quarter-turn-vocal-search'] + [root/'runs'/('nonlinear-commercial-'+c['label']) for c in cases]:
    report_path = other/'search.json'
    if report_path.exists():
        assert json.loads(report_path.read_text())['status'] != 'running', f'preserve live search: {other}'
case = next(c for c in cases if c['label'] == args.case)
database = root/'runs'/('nonlinear-commercial-'+args.case+'.sqlite')
output = root/'runs'/('nonlinear-commercial-'+args.case)
assert not output.exists() and not database.exists()
with Catalogue.create(database) as catalogue:
    for driver in drivers: catalogue.add(driver)
native = root/'runs/runtime'
runtime = BoundaryLabRuntime(native/'boundary-lab', native/'blab-env/bin/python',
    native/'julia-1.12.6/bin/julia', 'beat_cpu', julia_threads=4)
result = optimise(SearchBrief.model_validate(case['brief']), HornGeometry.model_validate(case['base']),
    database, runtime, output, solver_stage_timeout_s=controls['solver_stage_timeout_s'])
(output/'experiment-provenance.json').write_text(json.dumps({
    'application_source_commit': commit, 'controls_sha256': sha256(control_path),
    'case': args.case, 'qualified': False, 'limitations': controls['limitations']}, indent=2)+'\n')
print(json.dumps(result, indent=2))
