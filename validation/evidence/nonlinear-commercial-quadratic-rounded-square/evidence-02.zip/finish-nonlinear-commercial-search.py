"""Verify, export and archive one complete predeclared curved commercial search."""
from pathlib import Path
import argparse
import json
import subprocess
import zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from meh_studio.boundary_lab import sha256
from meh_studio.search_results import load_completed_search
from meh_studio.build_bundle import export_search
from meh_studio.operating import search_operating_report
from meh_studio.acoustic_objectives import lr4

root = Path.cwd(); runs = root / 'runs'
parser = argparse.ArgumentParser()
parser.add_argument('--case', required=True, choices=['exponential-round', 'quadratic-rounded-square'])
args = parser.parse_args()
frozen = runs / 'quadrature-source'
import meh_studio
assert Path(meh_studio.__file__).resolve().is_relative_to(frozen)
postprocess_commit = subprocess.check_output(['git', '-C', str(frozen), 'rev-parse', 'HEAD'], text=True).strip()
assert postprocess_commit == '852a5a33af9617ac3a40f9956ca12f744e3d0ba8'
assert not subprocess.check_output(['git', '-C', str(frozen), 'status', '--porcelain'], text=True)
control_path = runs / 'nonlinear-commercial-search-controls.json'
controls = json.loads(control_path.read_text())
assert controls['runner_sha256'] == sha256(runs / 'run-nonlinear-commercial-search.py')
case = next(c for c in controls['cases'] if c['label'] == args.case)
source = runs / ('nonlinear-commercial-' + args.case)
hashes, search, brief, base, winner, gain = load_completed_search(source)
assert search['status'] == 'complete' and len(search['trials']) == 2
assert brief.model_dump(mode='json') == case['brief']
assert base.model_dump(mode='json') == case['base']
assert controls['application_source_commit'] == '5c5fab109c7ae169582d7330b157bf068c46ef0a'
provenance = json.loads((source / 'experiment-provenance.json').read_text())
assert provenance['controls_sha256'] == sha256(control_path) and provenance['case'] == args.case
assert provenance['application_source_commit'] == controls['application_source_commit']
assert brief.acoustic_objectives.minimum_bank_impedance_ohm == 2.
assert brief.acoustic_objectives.acoustic_handover_hz == (3000., 5000.)
assert brief.build_budget.maximum_total_cost == 300.
limit = controls['response_screen_limit_db']; assert limit == 6.
export_path = runs / ('nonlinear-commercial-' + args.case + '-winner.zip')
export_verification = export_search(source, export_path)
operating = search_operating_report(source, 1.)
rows = []
for trial in search['trials']:
    row = {k: trial[k] for k in ('index', 'status', 'ripple_db', 'directivity_error_db', 'objective',
            'acoustic_objective', 'error', 'drive_settings', 'parallel_mid_bank', 'build_cost') if k in trial}
    row['response_screen_passed'] = trial['status'] == 'complete' and trial['ripple_db'] <= limit
    rows.append(row)
frequencies = np.array(brief.frequencies_hz)
fig, axis = plt.subplots(figsize=(9, 4.8), layout='constrained')
for trial in search['trials']:
    if trial['status'] != 'complete': continue
    residual = np.array(trial['relative_response_db']) - 20 * np.log10(abs(lr4(frequencies, brief.acoustic_objectives.mid_highpass_hz, 'highpass')))
    assert abs(float(np.ptp(residual)) - trial['ripple_db']) < 1e-10
    centred = residual - (residual.min() + residual.max()) / 2
    axis.semilogx(frequencies, centred, 'o-', ms=4, label=f"Trial {trial['index']}: {trial['ripple_db']:.2f} dB variation")
axis.axhspan(-limit/2, limit/2, color='C2', alpha=.1, label='6 dB screening span')
axis.set(xlabel='Frequency (Hz)', ylabel='Centred target residual (dB)',
         title=f"{args.case.replace('-', ' ').capitalize()}: completed native search\n15 training samples; provisional commercial circuits; no physical qualification")
axis.grid(True, which='both', alpha=.2); axis.legend(fontsize=9)
figure = runs / ('nonlinear-commercial-' + args.case + '-comparison.png')
fig.savefig(figure, dpi=170)
paths = sorted(p for p in source.rglob('*') if p.is_file())
paths += [control_path, runs / 'run-nonlinear-commercial-search.py', Path(__file__),
          runs / ('nonlinear-commercial-' + args.case + '.log'), export_path, figure,
          runs / 'nonlinear-flare-rebuild-controls.json', runs / 'nonlinear-flare-rebuild/report.json']
inventory = {str(p.relative_to(runs)): sha256(p) for p in paths}
groups = []; pending = []; size = 0
for path in paths:
    n = path.stat().st_size; assert n < 90_000_000
    if pending and size + n > 75_000_000:
        groups.append(pending); pending = []; size = 0
    pending.append(path); size += n
if pending: groups.append(pending)
target = root / 'validation/evidence' / ('nonlinear-commercial-' + args.case)
target.mkdir(parents=True, exist_ok=False)
archives = []
for index, paths_in_group in enumerate(groups):
    archive_path = target / f'evidence-{index:02d}.zip'
    with zipfile.ZipFile(archive_path, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in paths_in_group: archive.write(path, str(path.relative_to(runs)))
    assert archive_path.stat().st_size < 100_000_000
    with zipfile.ZipFile(archive_path) as archive: assert archive.testzip() is None
    archives.append({'file': archive_path.name, 'size_bytes': archive_path.stat().st_size, 'sha256': sha256(archive_path)})
assert inventory == {str(p.relative_to(runs)): sha256(p) for p in paths}
assert load_completed_search(source)[0] == hashes
report = {'status': 'complete_exploratory_search', 'case': args.case,
          'application_source_commit': controls['application_source_commit'],
          'postprocessing_source_commit': postprocess_commit, 'controls_sha256': sha256(control_path),
          'search': search, 'summary': rows, 'response_screen_limit_db': limit,
          'any_response_screen_passed': any(r['response_screen_passed'] for r in rows),
          'winner_index': search['winner_index'], 'export_verification': export_verification,
          'archives': archives, 'archived_file_sha256': inventory,
          'qualified': False, 'physical_validation': False, 'mesh_convergence': False,
          'limitations': controls['limitations'] + [
              'Selection includes coverage and cost; a lower combined objective need not mean flatter axial response',
              'The quarter-turn vocal search used a different HF source; differences from it cannot be attributed to horn shape alone']}
(target / 'operating-1vrms.json').write_text(json.dumps(operating, indent=2) + '\n')
(target / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'case': args.case, 'rows': rows, 'winner_index': search['winner_index'], 'archives': archives}, indent=2))
