from pathlib import Path
import json
import hashlib
import numpy as np
from meh_studio.optimisation import verified_assessment
from meh_studio.validation import validate_electrical_basis
root = Path(__file__).resolve().parent
base = root.parent / 'annular-fixed-mesh-quadrature'
project = root / 'system/project.blab.json'
verified_assessment(project, root / 'evaluation')
electrical = validate_electrical_basis(project, root / 'evaluation')
loaded = {}
manifests = {}
for name, path in [('refined', base / 'evaluation-baseline'), ('coarse_rear', root / 'evaluation')]:
 raw = path / 'upstream'
 manifests[name] = json.loads((raw/'manifest.json').read_text())
 quantities = {q['id']: q for q in json.loads((raw/'frequencies/000000.json').read_text())['quantities']}
 assert quantities['mechanical:diaphragm-velocity']['metadata']['component_ids'] == ['component:throat','component:entry_0_positive','component:entry_0_positive_y']
 with np.load(raw/'frequencies/000000.npz', allow_pickle=False) as a:
  loaded[name] = {k:a[v['key']].copy() for k,v in quantities.items()}
runtime_a = dict(manifests['refined']['reference_runtime']['identity'])
runtime_b = dict(manifests['coarse_rear']['reference_runtime']['identity'])
# Preserve original manifests; only canonicalise the same executable path for comparison.
assert Path(runtime_a['julia_executable']).resolve() == Path(runtime_b['julia_executable']).resolve()
runtime_a.pop('julia_executable'); runtime_b.pop('julia_executable')
assert runtime_a == runtime_b
assert manifests['refined']['solver_options'] == manifests['coarse_rear']['solver_options']
assert manifests['coarse_rear']['project_sha256'] == hashlib.sha256(project.read_bytes()).hexdigest()
rows = {}
for k in ('mechanical:diaphragm-velocity','electrical:voice-coil-current','acoustic:pressure:horizontal-polar','acoustic:pressure:vertical-polar'):
 x,y = loaded['refined'][k],loaded['coarse_rear'][k]
 rows[k] = float(np.linalg.norm(y-x)/np.linalg.norm(x))
x,y = [np.concatenate([loaded[n][f'acoustic:pressure:{p}-polar'][1:].sum(axis=0) for p in ('horizontal','vertical')]) for n in ('refined','coarse_rear')]
rows['common_mid_pressure'] = float(np.linalg.norm(y-x)/np.linalg.norm(x))
report = {'source_commit':'a1ce74dfc604da9441d012a38b729258a915c44e','frequency_hz':4000,'relative_errors_against_refined_baseline':rows,'electrical_check':electrical,'runtime_and_solver_options_match_after_julia_path_canonicalisation':True,'qualified':False,'limitations':['One-frequency isolated rear sensitivity is not mesh convergence.','Original 51.07% all-domain mesh change remains failed.']}
(root/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'errors':rows,'electrical_passed':electrical['passed']},indent=2))
