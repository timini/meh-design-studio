"""Exploratory force decomposition of retained fields; no replacement acoustic solve."""
from pathlib import Path
import json,argparse
import numpy as np
import meshio
from meh_studio.optimisation import verified_assessment
from meh_studio.generated_system import HornSources
from meh_studio.circuit_reanalysis import _circuit
from meh_studio.boundary_lab import sha256
parser=argparse.ArgumentParser();parser.add_argument('--case',required=True,choices=['flat','curved']);args=parser.parse_args()
root=Path.cwd();trial=root/'runs/curved-diaphragm-native'/args.case
controls_path=root/'runs/curved-diaphragm-native-controls.json';controls=json.loads(controls_path.read_text())
project=trial/'system/project.blab.json';raw=trial/'evaluation/upstream'
evidence=verified_assessment(project,trial/'evaluation')
system=json.loads(project.read_text())['physical_system'];manifest=json.loads((raw/'manifest.json').read_text())
meta=json.loads((raw/manifest['results'][0]['metadata_file']).read_text());qs={q['id']:q for q in meta['quantities']}
ids=qs['mechanical:diaphragm-velocity']['metadata']['component_ids']; counts=qs['mechanical:diaphragm-velocity']['metadata']['surface_completion_factors']
components={c['id']:c for c in system['components']};bounds={b['id']:b for b in system['boundaries']}
node_meta=qs['acoustic:pressure:fem-nodes']['metadata'];mesh_ids=node_meta['mesh_ids'];offsets=node_meta['node_offsets'];sizes=node_meta['node_counts']
dom=json.loads((raw/manifest['domains_metadata_file']).read_text())['domains'];dom=next(d for d in dom if d['id']=='domain:fem-volume')
with np.load(raw/manifest['domains_file'],allow_pickle=False) as arrays: xyz=arrays[dom['coordinates']['points_m']].copy()
meshes={m['id']:meshio.read(project.parent/m['file']) for m in system['meshes'] if m['purpose']=='fem_volume'}
for name,offset,size in zip(mesh_ids,offsets,sizes):
 assert np.allclose(meshes[name].points,xyz[offset:offset+size],rtol=0,atol=1e-14)
weights=np.zeros((len(ids),2,len(xyz)));patches=[]
for c,id in enumerate(ids):
 axis=np.asarray(components[id]['parameters']['motion_axis']);axis=axis/np.linalg.norm(axis)
 for bid in components[id]['boundary_ids']:
  b=bounds[bid];g=b['group'];mesh=meshes[g['mesh_id']];offset=offsets[mesh_ids.index(g['mesh_id'])]
  triangles=np.vstack([cell.data[np.asarray(tags)==g['tag']] for cell,tags in zip(mesh.cells,mesh.cell_data['gmsh:physical']) if cell.type=='triangle'])
  opposite={tuple(sorted(map(int,t))):None for t in triangles}
  for cell in mesh.cells:
   if cell.type!='tetra':continue
   for tet in cell.data:
    for j in range(4):
     key=tuple(sorted(int(tet[k]) for k in range(4) if k!=j))
     if key in opposite:
      assert opposite[key] is None
      opposite[key]=int(tet[j])
  side=0 if b['region_id']=='region:front' else 1
  total=0.
  for tri in triangles:
   pts=mesh.points[tri];normal=np.cross(pts[1]-pts[0],pts[2]-pts[0])/2
   inside=opposite[tuple(sorted(map(int,tri)))];assert inside is not None
   if np.dot(normal,mesh.points[inside]-pts.mean(axis=0))>0:normal=-normal
   projected=float(np.dot(normal,axis));total+=projected
   weights[c,side,tri+offset]+=-counts[c]*projected/3
  patches.append({'component':id,'boundary':bid,'completed_projected_area_m2':counts[c]*total})
source=HornSources.model_validate_json((project.parent/'sources.json').read_text());sources=[source.throat if id=='component:throat' else source.side for id in ids]
rows=[]
for row in manifest['results']:
 m=json.loads((raw/row['metadata_file']).read_text());q={v['id']:v for v in m['quantities']}
 with np.load(raw/row['arrays_file'],allow_pickle=False) as a:
  p=a[q['acoustic:pressure:fem-nodes']['key']];v=a[q['mechanical:diaphragm-velocity']['key']].T;i=a[q['electrical:voice-coil-current']['key']].T
  assert q['mechanical:diaphragm-velocity']['metadata']['component_ids']==ids
  force=np.einsum('csn,en->cse',weights,p)
 ze,bl,zm=_circuit(sources,row['freq_hz']);expected=bl[:,None]*i-zm[:,None]*v
 residual=float(np.linalg.norm(force.sum(axis=1)-expected)/np.linalg.norm(expected))
 mids=[j for j,id in enumerate(ids) if id!='component:throat'];midrows=[]
 for j in mids:
  speed=v[j,mids].sum();front=force[j,0,mids].sum();rear=force[j,1,mids].sum()
  midrows.append({'component':ids[j],'velocity_abs_m_s':float(abs(speed)),'front_load_n_s_m':[float((front/speed).real),float((front/speed).imag)],'rear_load_n_s_m':[float((rear/speed).real),float((rear/speed).imag)]})
 rows.append({'frequency_hz':row['freq_hz'],'force_equation_relative_residual':residual,'passed':bool(np.isfinite(residual) and residual<=controls['force_balance_relative_limit']),'mids_common_2_83v_hf_zero':midrows})
assert verified_assessment(project,trial/'evaluation')==evidence
out={'kind':'independent_curved_source_force_balance','qualified':False,
 'case':args.case,'runner_sha256':sha256(Path(__file__)),
 'application_source_commit':controls['application_source_commit'],'controls_sha256':sha256(controls_path),
 'native_evidence':evidence,'patches':patches,'rows':rows,
 'force_balance_relative_limit':controls['force_balance_relative_limit'],
 'passed':all(r['passed'] for r in rows),
 'limitations':controls['limitations']}
path=root/('runs/curved-diaphragm-'+args.case+'-force-balance.json')
with path.open('x') as f:f.write(json.dumps(out,indent=2)+'\n')
print(args.case,'force balance',out['passed'],'maximum residual',max(r['force_equation_relative_residual'] for r in rows))
