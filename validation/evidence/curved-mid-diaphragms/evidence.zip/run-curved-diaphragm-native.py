"""Small declared coupled FP64 flat/curved geometry comparison with synthetic circuits."""
from pathlib import Path
import argparse,json,subprocess
from meh_studio.geometry import HornGeometry,export_geometry,mesh_geometry
from meh_studio.generated_system import HornSources
from meh_studio.radiating_system import compile_radiating_system
from meh_studio.boundary_lab import BoundaryLabRuntime,SolveRequest,sha256
from meh_studio.optimisation import verified_assessment
root=Path.cwd();runs=root/'runs';source=runs/'curved-diaphragm-source'
args=argparse.ArgumentParser();args.add_argument('stage',choices=['controls','run']);args=args.parse_args()
commit=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
assert commit=='4fc55f731c7159131d492cd38e348156edac284c'
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True)
import meh_studio.geometry
assert Path(meh_studio.geometry.__file__).resolve().is_relative_to(source)
gp=source/'examples/curved-diaphragm-ring-geometry.json';sp=source/'examples/synthetic-horn-sources.json'
curved=HornGeometry.model_validate_json(gp.read_text());flat=HornGeometry.model_validate(curved.model_dump()|{'diaphragm_profile_m':[]})
sources=HornSources.model_validate_json(sp.read_text())
request=SolveRequest(frequencies_hz=(350.,2000.,5000.),include_project_observations=True,retain=('fem_nodal_pressure','bem_boundary_traces'))
controls={'application_source_commit':commit,'runner_sha256':sha256(Path(__file__)),
 'geometry_example_sha256':sha256(gp),'sources_sha256':sha256(sp),
 'designs':{name:d.model_dump(mode='json') for name,d in [('flat',flat),('curved',curved)]},
 'request':request.model_dump(mode='json'),'backend':'coupled_reference','julia_threads':1,
 'maximum_total_tetrahedra':80000,'maximum_final_exterior_triangles':2500,'exterior_mesh_size_m':.02,
 'electrical_relative_limit':1e-8,'force_balance_relative_limit':1e-8,'rotational_field_relative_limit':.02,
 'qualified':False,'scope':'One flat and one explicitly curved synthetic-source model; same circuits and projected moving areas. Curvature changes both front cavity and swept rear termination. Test real coupled execution, source-force balance and electrical equations; preserve all failures. No response improvement threshold or commercial design selection.',
 'limitations':['Three frequencies and an 8mm mesh are not band or mesh convergence.','Curved profile is synthetic, not a measured commercial cone.','No basket/motor displacement, breakup, physical mounting, output or print qualification.']}
cp=runs/'curved-diaphragm-native-controls.json'
if args.stage=='controls':
 with cp.open('x') as f:f.write(json.dumps(controls,indent=2)+'\n')
 print(sha256(cp));raise SystemExit
assert json.loads(cp.read_text())==controls
out=runs/'curved-diaphragm-native';out.mkdir(exist_ok=False)
native=runs/'runtime';runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',native/'julia-1.12.6/bin/julia','coupled_reference',julia_threads=1)
for name,design in [('flat',flat),('curved',curved)]:
 p=out/name;p.mkdir()
 export_geometry(design,p/'geometry');mesh=mesh_geometry(p/'geometry')
 total=sum(r['tetrahedra'] for r in mesh['regions']);assert total<=controls['maximum_total_tetrahedra']
 report=compile_radiating_system(p/'geometry',sources,p/'system',runtime,exterior_mesh_size_m=.02,timeout_s=1800)
 import meshio
 surface=meshio.read(p/'system/meshes/exterior.msh');triangles=sum(len(c.data) for c in surface.cells if c.type=='triangle')
 assert triangles<=controls['maximum_final_exterior_triangles']
 identities={q.relative_to(p).as_posix():sha256(q) for dirname in ('geometry','system') for q in (p/dirname).rglob('*') if q.is_file()}
 (p/'prepared.json').write_text(json.dumps({'controls_sha256':sha256(cp),'tetrahedra':total,'triangles':triangles,'input_sha256':identities},indent=2)+'\n')
 print(name,'prepared',total,triangles,flush=True)
 runtime.solve(p/'system/project.blab.json',request,p/'evaluation',timeout_s=1800)
 assert identities=={rel:sha256(p/rel) for rel in identities}
 assessment=verified_assessment(p/'system/project.blab.json',p/'evaluation')
 (p/'native-assessment.json').write_text(json.dumps({'controls_sha256':sha256(cp),'assessment':assessment,'qualified':False},indent=2)+'\n')
 print(name,'complete','electrical',assessment['checks']['passed'],flush=True)
