"""Archive both declared native cases, including the curved C4 failure."""
from pathlib import Path
import json,hashlib,zipfile
import numpy as np
root=Path.cwd();runs=root/'runs';native=runs/'curved-diaphragm-native'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
controls=json.loads((runs/'curved-diaphragm-native-controls.json').read_text())
rotation=json.loads((runs/'curved-diaphragm-rotation.json').read_text())
forces={case:json.loads((runs/f'curved-diaphragm-{case}-force-balance.json').read_text()) for case in ['flat','curved']}
summary=[];observations={};orders={}
for case in ['flat','curved']:
 p=native/case;prepared=json.loads((p/'prepared.json').read_text())
 assert all(digest(p/rel)==sha for rel,sha in prepared['input_sha256'].items())
 evaluation=json.loads((p/'evaluation/evaluation.json').read_text());assert evaluation['status']=='complete'
 assessment=json.loads((p/'native-assessment.json').read_text())['assessment']
 raw=p/'evaluation/upstream';manifest=json.loads((raw/'manifest.json').read_text());metadata=json.loads((raw/manifest['results'][0]['metadata_file']).read_text())
 orders[case]=[manifest['excitation_port_ids'],[q['metadata'].get('component_ids') for q in metadata['quantities'] if q['quantity'] in ['diaphragm_velocity','voice_coil_current']]]
 domains=json.loads((raw/manifest['domains_metadata_file']).read_text())['domains']
 with np.load(raw/manifest['domains_file'],allow_pickle=False) as arrays:
  observations[case]=[arrays[next(d for d in domains if d['id']==f'observation:{plane}-polar')['coordinates']['points_m']].copy() for plane in ['horizontal','vertical']]
 r=next(v for v in rotation['cases'] if v['case']==case)
 errors=[v['relative_complex_norm_error'] for row in r['frequencies'] for v in row['checks'].values() if v['relative_complex_norm_error'] is not None]
 summary.append({'case':case,'tetrahedra':prepared['tetrahedra'],'final_exterior_triangles':prepared['triangles'],
  'electrical_passed':assessment['checks']['passed'],'force_balance_passed':forces[case]['passed'],
  'maximum_force_balance_relative_residual':max(v['force_equation_relative_residual'] for v in forces[case]['rows']),
  'rotational_check_passed':r['passed'],'maximum_rotational_relative_error':max(errors)})
assert orders['flat']==orders['curved']
assert all(np.array_equal(a,b) for a,b in zip(observations['flat'],observations['curved']))
paths=[p for p in native.rglob('*') if p.is_file()]
paths += [runs/name for name in ['run-curved-diaphragm-native.py','curved-diaphragm-native-controls.json','curved-diaphragm-native.log',
 'check-curved-diaphragm-force.py','curved-diaphragm-flat-force-balance.json','curved-diaphragm-curved-force-balance.json',
 'curved-diaphragm-flat-force.log','curved-diaphragm-curved-force.log','check-curved-diaphragm-rotation.py','curved-diaphragm-rotation.json',
 'curved-diaphragm-rotation.log','compare-curved-diaphragm-native.py','curved-diaphragm-comparison.json','curved-diaphragm-comparison.log',
 'curved-diaphragm-tests.log','curved-diaphragm-noncad.log','curved-diaphragm-regression.log','archive-curved-diaphragm-native.py']]
paths=sorted(set(paths));members={p.relative_to(runs).as_posix():p for p in paths}
members['upstream-LICENSE']=runs/'runtime/boundary-lab/LICENSE'
identities={name:digest(p) for name,p in members.items()}
out=root/'validation/evidence/curved-mid-diaphragms';out.mkdir(exist_ok=False);archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,p in members.items():z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert identities=={name:hashlib.sha256(z.read(name)).hexdigest() for name in members}
assert identities=={name:digest(p) for name,p in members.items()}
report={'status':'complete','application_source_commit':controls['application_source_commit'],
 'scope':controls['scope'],'controls_sha256':digest(runs/'curved-diaphragm-native-controls.json'),
 'archives':[{'file':'evidence.zip','size_bytes':archive.stat().st_size,'sha256':digest(archive)}],
 'archived_file_sha256':identities,'summary':summary,
 'flat_curved_observation_coordinates_and_source_orders_equal':True,
 'electrical_relative_limit':controls['electrical_relative_limit'],
 'force_balance_relative_limit':controls['force_balance_relative_limit'],
 'rotational_field_relative_limit':controls['rotational_field_relative_limit'],
 'qualified':False,'physical_validation':False,'limitations':controls['limitations']}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'archives':report['archives'],'files':len(members),'summary':summary},indent=2))
