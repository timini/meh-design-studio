"""Describe the declared geometry change without scoring or selecting a design."""
from pathlib import Path
import json
import numpy as np
from meh_studio.boundary_lab import sha256
from meh_studio.optimisation import verified_assessment
root=Path.cwd();base=root/'runs/curved-diaphragm-native';cp=root/'runs/curved-diaphragm-native-controls.json';controls=json.loads(cp.read_text())
assessments={name:verified_assessment(base/name/'system/project.blab.json',base/name/'evaluation') for name in ['flat','curved']}
manifests={name:json.loads((base/name/'evaluation/upstream/manifest.json').read_text()) for name in assessments}
assert [r['freq_hz'] for r in manifests['flat']['results']]==[r['freq_hz'] for r in manifests['curved']['results']]
rows=[]
for left,right in zip(manifests['flat']['results'],manifests['curved']['results']):
 values={}
 for case,row in [('flat',left),('curved',right)]:
  p=base/case/'evaluation/upstream';meta=json.loads((p/row['metadata_file']).read_text());q={x['id']:x for x in meta['quantities']}
  with np.load(p/row['arrays_file'],allow_pickle=False) as a:
   values[case]={name:a[q[name]['key']].copy() for name in ['mechanical:diaphragm-velocity','electrical:voice-coil-current','acoustic:pressure:horizontal-polar','acoustic:pressure:vertical-polar']}
 changes={name:float(np.linalg.norm(values['curved'][name]-v)/np.linalg.norm(v)) for name,v in values['flat'].items()}
 rows.append({'frequency_hz':left['freq_hz'],'relative_complex_change':changes})
report={'kind':'descriptive_flat_to_curved_geometry_change','application_source_commit':controls['application_source_commit'],'controls_sha256':sha256(cp),'runner_sha256':sha256(Path(__file__)),'native_evidence':assessments,'rows':rows,'qualified':False,'acceptance_criterion':None,'limitations':controls['limitations']}
with (root/'runs/curved-diaphragm-comparison.json').open('x') as f:f.write(json.dumps(report,indent=2)+'\n')
print(json.dumps(rows,indent=2))
