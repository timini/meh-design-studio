"""Preserve the completed entry experiment, with frequency archives below GitHub limits."""
from pathlib import Path
import json
import zipfile
from meh_studio.search_results import load_completed_search
from meh_studio.build_bundle import export_search
from meh_studio.operating import search_operating_report
from meh_studio.boundary_lab import sha256

root = Path.cwd()
source = root / 'runs/target-eccentric-entry'
target = root / 'validation/evidence/target-eccentric-entry'
hashes, result, *_ = load_completed_search(source)
assert len(result['trials']) == 1 and result['winner_index'] == 0
comparison = json.loads((root / 'runs/target-entry-comparison.json').read_text())
handover = json.loads((root / 'runs/target-handover-reanalysis.json').read_text())
assert comparison['new_search_control_sha256'] == hashes
assert handover['unchanged_native_search_control_sha256'] == hashes
export_path = root / 'runs/target-eccentric-entry-winner.zip'
export_report = export_search(source, export_path)
operating = search_operating_report(source, 1.)
target.mkdir(parents=True, exist_ok=False)

groups = {'trial-000-geometry-system': [], 'trial-000-evaluation-metadata': []}
for path in sorted((source / 'trial-000').rglob('*')):
    if not path.is_file():
        continue
    relative = path.relative_to(source)
    if 'frequencies' in relative.parts:
        index = int(path.stem)
        name = f'trial-000-frequencies-{index // 5:02d}'
    elif relative.parts[1] == 'evaluation':
        name = 'trial-000-evaluation-metadata'
    else:
        name = 'trial-000-geometry-system'
    groups.setdefault(name, []).append((path, str(relative)))
groups['controls-and-export'] = [(p, p.name) for p in sorted(source.iterdir()) if p.is_file()]
for name in ('run-target-eccentric-entry.py', 'compare-target-entry-shift.py',
             'reanalyse-target-handover.py', 'finish-target-entry-study.py'):
    groups['controls-and-export'].append((root / 'runs' / name, 'runners/' + name))
groups['controls-and-export'].append((export_path, 'exports/' + export_path.name))
for name in ('target-eccentric-entry-controls.json', 'target-entry-comparison.json',
             'target-handover-reanalysis.json'):
    groups['controls-and-export'].append((root / 'runs' / name, 'diagnostics/' + name))
archives = []
for name, files in groups.items():
    path = target / (name + '.zip')
    with zipfile.ZipFile(path, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for input_path, archive_name in files:
            archive.write(input_path, archive_name)
    assert path.stat().st_size < 100_000_000, path
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
    archives.append({'file': path.name, 'sha256': sha256(path), 'size_bytes': path.stat().st_size})
report = {
    'status': 'completed_single_candidate_diagnostic',
    'native_application_source_commit': '1187c25',
    'frozen_dsp_comparison_source_commit': '1187c25',
    'handover_reanalysis_export_and_operating_source_commit': 'e1a7a42',
    'search': result, 'archives': archives, 'export_verification': export_report,
    'comparison': comparison, 'handover_reanalysis': handover,
    'physical_validation': False, 'mesh_convergence': False,
    'independent_frequency_holdout': False, 'all_commercial_sources': False,
    'limitations': ['Single geometry diagnostic, not an optimisation campaign or global optimum',
        'Compared with historical baseline trial 0, not the mutated winner trial 7',
        'Moving ports 20 mm toward the throat held driver centres and all other geometry controls fixed',
        'Same-candidate DSP reanalysis is distinct from the unchanged native search and its original objective',
        'Reported mids and synthetic HF; no commercial basket/phase-plug/cone or physical qualification',
        'Strict electrical validation remains failed for native complex64 storage',
        'Budget figures are planning allowances; no purchases or print qualification'],
}
(target / 'operating-1vrms.json').write_text(json.dumps(operating, indent=2) + '\n')
(target / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
assert all(sha256(source / name) == digest for name, digest in hashes.items())
print(json.dumps({'archives': archives, 'export': export_report,
    'original_ripple_db': result['winner']['ripple_db'],
    'constrained_ripple_db': None if handover['constrained_score'] is None else handover['constrained_score']['ripple_db']}, indent=2))
