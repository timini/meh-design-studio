"""Target-size 20 mm entry shift; fixed driver centres, reported mids/synthetic HF.

Use a fresh source and output; the older search and its scores remain unchanged.
The denser vocal grid is a diagnostic search grid, not independent holdout evidence.
"""
from pathlib import Path
import argparse,json
from meh_studio.boundary_lab import BoundaryLabRuntime,sha256
from meh_studio.domain import DriverRevision
from meh_studio.catalogue import Catalogue
from meh_studio.optimisation import SearchBrief,optimise,candidates
from meh_studio.geometry import HornGeometry
root=Path.cwd(); native=root/'runs/runtime'
original=root/'runs/larger-wide-mid-32k'
saved=json.loads((original/'trial-000/candidate.json').read_text())
data=saved['design'].copy()
old_entry=data['entry_positions_m'][0]
data['entry_positions_m']=[old_entry-.020]
data['driver_axial_offset_m']=.020
base=HornGeometry.model_validate(data)
drivers=[DriverRevision.model_validate(d) for d in saved['driver_revisions']]
controls=json.loads((original/'brief.json').read_text())
controls.update(frequencies_hz=[350.,700.,1000.,1200.,1500.,1750.,2000.,2250.,2500.,2750.,3000.,3500.,4000.,5000.,7500.],
    entry_fractions=[[base.entry_positions_m[0]/base.length_m]],trial_budget=1,evolution=None)
controls['acoustic_objectives']['sphere']={'angle_precision_deg':10.,'control_from_hz':1000.,'rear_attenuation_db':30.}
brief=SearchBrief.model_validate(controls)
rows=candidates(brief,base,drivers)
assert len(rows)==1
actual=rows[0]['design'].model_dump(mode='json');previous=saved['design']
assert abs(actual['entry_positions_m'][0]+actual['driver_axial_offset_m']-old_entry)<1e-15
assert {k:v for k,v in actual.items() if k not in ('entry_positions_m','driver_axial_offset_m')}=={k:v for k,v in previous.items() if k not in ('entry_positions_m','driver_axial_offset_m')}
assert brief.acoustic_objectives.minimum_bank_impedance_ohm==2.
provenance={'application_source_commit':'1187c25','source_worktree':'runs/eccentric-text-source',
    'reference_candidate':str(original/'trial-000/candidate.json'),
    'reference_candidate_sha256':sha256(original/'trial-000/candidate.json'),
    'reference_application_source_commit':'a0a604e','port_shift_toward_throat_m':.020,
    'driver_centre_z_m':old_entry,'all_other_geometry_controls_identical':True,
    'changes_beyond_geometry':['denser vocal frequency grid','413-point sphere observations',
       'interface coordinate restoration and ASCII preflight compatibility'],
    'limitations':['Reported mids with synthetic HF, no qualified commercial response',
       'Different meshes; source changes and numerical convergence must be considered in comparison',
       'Diagnostic grid is not an independent frequency holdout; DSP is selected on it',
       'No purchased-driver mounting qualification or measured output']}
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');args=parser.parse_args()
    if args.prepare:
        path=root/'runs/target-eccentric-entry-controls.json'
        path.write_text(json.dumps({'brief':brief.model_dump(mode='json'),'base':base.model_dump(mode='json'),'provenance':provenance},indent=2)+'\n')
        print(json.dumps(provenance,indent=2))
    else:
        database=root/'runs/target-eccentric-entry.sqlite'
        with Catalogue.create(database) as catalogue:
            for d in drivers:catalogue.add(d)
        runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',native/'julia-1.12.6/bin/julia',julia_threads=4)
        output=root/'runs/target-eccentric-entry'
        result=optimise(brief,base,database,runtime,output,solver_stage_timeout_s=3600)
        (output/'experiment-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
        print(json.dumps(result,indent=2))
