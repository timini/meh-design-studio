"""Compare the entry shift using the baseline's frozen DSP before reoptimised DSP."""
from pathlib import Path
import json,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from meh_studio.search_results import load_completed_search
from meh_studio.optimisation import verified_assessment
from meh_studio.boundary_lab import _contained,sha256
from meh_studio.acoustic_objectives import drive_weights,lr4
root=Path.cwd();new_search=root/'runs/target-eccentric-entry'
new_hashes,result,*_=load_completed_search(new_search)
old_trial=root/'runs/larger-wide-mid-32k/trial-000';new_trial=new_search/'trial-000'
settings=json.loads((old_trial/'score.json').read_text())['drive_settings']
def load(trial):
    project=trial/'system/project.blab.json';evaluation=trial/'evaluation';raw=evaluation/'upstream'
    identity=verified_assessment(project,evaluation)
    m=json.loads((raw/'manifest.json').read_text())
    assert m['phasor_convention']=='exp(-i omega t)'
    system=json.loads(project.read_text())['physical_system']
    ports={p['id']:p['component_id'] for p in system['excitation_ports']}
    ids=[ports[p] for p in m['excitation_port_ids']]
    domains=json.loads(_contained(raw,m['domains_metadata_file']).read_text())['domains']
    d=next(d for d in domains if d['id']=='observation:horizontal-polar')
    with np.load(_contained(raw,m['domains_file'])) as a:
        axis=np.flatnonzero(a[d['coordinates']['angle_deg']]==0);assert len(axis)==1
        xyz=a[d['coordinates']['points_m']][axis[0]].copy()
    freq=[];basis=[]
    for r in m['results']:
        meta=json.loads(_contained(raw,r['metadata_file']).read_text())
        ref=meta['diagnostics']['transducer_reference_voltage_v'];assert ref==2.83
        q=next(q for q in meta['quantities'] if q['id']=='acoustic:pressure:horizontal-polar');assert q['unit']=='Pa'
        with np.load(_contained(raw,r['arrays_file'])) as a:basis.append(a[q['key']][:,axis[0]].copy()/ref)
        freq.append(r['freq_hz'])
    assert verified_assessment(project,evaluation)==identity
    return np.array(freq),ids,np.array(basis),xyz,identity
old=load(old_trial);new=load(new_trial);assert np.array_equal(old[3],new[3])
def pressure(record,dsp):
    f,ids,basis,*_=record
    return np.sum(drive_weights(f,ids,dsp)*basis,axis=1)
def residual(f,p):
    values=20*np.log10(abs(p)/abs(lr4(f,350,'highpass')))
    return values-(values.max()+values.min())/2
oldp=pressure(old,settings);fixed=pressure(new,settings);selected=pressure(new,result['winner']['drive_settings'])
oldmid=np.sum(old[2][:,[i for i,c in enumerate(old[1]) if c!='component:throat']],axis=1)
newmid=np.sum(new[2][:,[i for i,c in enumerate(new[1]) if c!='component:throat']],axis=1)
common=np.array([list(new[0]).index(f) for f in old[0]])
report={'old_candidate_sha256':sha256(old_trial/'candidate.json'),'new_search_control_sha256':new_hashes,
    'comparison_settings':settings,'new_selected_settings':result['winner']['drive_settings'],
    'observation_xyz_m':old[3].tolist(),'common_frequencies_hz':old[0].tolist(),
    'old_response_range_common_db':float(np.ptp(residual(old[0],oldp))),
    'new_frozen_dsp_response_range_common_db':float(np.ptp(residual(old[0],fixed[common]))),
    'new_frozen_dsp_response_range_dense_db':float(np.ptp(residual(new[0],fixed))),
    'new_selected_dsp_response_range_dense_db':float(np.ptp(residual(new[0],selected))),
    'mid_only_pressure_change_common_db':(20*np.log10(abs(newmid[common])/abs(oldmid))).tolist(),
    'strict_electrical_validation':{'old':old[4]['checks'],'new':new[4]['checks']},
    'limitations':['Reported mids and synthetic HF; no commercial source or physical qualification',
        'Old and new meshes differ; no mesh convergence attribution',
        'The denser grid is a diagnostic search grid, not an independent holdout',
        'Pressure per RMS input voltage at the actual observation point; no maximum-SPL inference']}
(root/'runs/target-entry-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
fig,axes=plt.subplots(1,2,figsize=(12,4.8),layout='constrained')
for f,p,label in ((old[0],oldmid,'Original entries'),(new[0],newmid,'Entries 20 mm closer')):
    axes[0].semilogx(f,20*np.log10(abs(p)/20e-6),'o-',label=label)
axes[0].set(title='Four mids at 1 Vrms; HF held at 0 V',xlabel='Frequency (Hz)',ylabel='Predicted pressure level (dB re 20 µPa)')
for f,p,label in ((old[0],oldp,'Original geometry, baseline DSP'),(new[0],fixed,'Shifted entries, baseline DSP'),(new[0],selected,'Shifted entries, selected DSP')):
    axes[1].semilogx(f,residual(f,p),'o-',label=f'{label} ({np.ptp(residual(f,p)):.2f} dB)')
axes[1].axhspan(-3,3,color='green',alpha=.10)
axes[1].set(title='Full system after intended 350 Hz roll-off',xlabel='Frequency (Hz)',ylabel='Midpoint-centred response residual (dB)')
for ax in axes:ax.grid(alpha=.2);ax.legend(fontsize=8)
fig.suptitle('Target-size entry-position diagnostic: driver centres and other shape controls held fixed\nReported 4FE32 mids + synthetic HF; curves join solved samples; no physical or mesh qualification',fontsize=10)
fig.savefig(root/'runs/target-entry-comparison.png',dpi=150)
assert load_completed_search(new_search)[0]==new_hashes
print(json.dumps(report,indent=2))
