"""Re-score the completed entry diagnostic without changing its native evidence."""
from pathlib import Path
import json
import numpy as np
from meh_studio.search_results import load_completed_search
from meh_studio.acoustic_objectives import AcousticObjectives, score_acoustics, drive_weights
from meh_studio.acoustic_handover import acoustic_handover
from meh_studio.boundary_lab import _contained, sha256

root = Path.cwd()
search = root / 'runs/target-eccentric-entry'
hashes, result, brief, *_ = load_completed_search(search)
trial = search / 'trial-000'
raw = trial / 'evaluation/upstream'
manifest = json.loads((raw / 'manifest.json').read_text())
assert manifest['phasor_convention'] == 'exp(-i omega t)'
system = json.loads((trial / 'system/project.blab.json').read_text())['physical_system']
ports = {p['id']: p['component_id'] for p in system['excitation_ports']}
ids = [ports[p] for p in manifest['excitation_port_ids']]
hf = ids.index('component:throat')
frequencies = np.array([r['freq_hz'] for r in manifest['results']])
weights = drive_weights(frequencies, ids, result['winner']['drive_settings'])
domains = json.loads(_contained(raw, manifest['domains_metadata_file']).read_text())['domains']
domain = next(d for d in domains if d['id'] == 'observation:horizontal-polar')
with np.load(_contained(raw, manifest['domains_file'])) as arrays:
    axes = np.flatnonzero(arrays[domain['coordinates']['angle_deg']] == 0)
    assert len(axes) == 1
    axis = int(axes[0])
mid_pressure, hf_pressure = [], []
for i, row in enumerate(manifest['results']):
    metadata = json.loads(_contained(raw, row['metadata_file']).read_text())
    assert metadata['diagnostics']['transducer_reference_voltage_v'] == 2.83
    quantity = next(q for q in metadata['quantities'] if q['id'] == 'acoustic:pressure:horizontal-polar')
    assert quantity['unit'] == 'Pa'
    with np.load(_contained(raw, row['arrays_file'])) as arrays:
        terms = weights[i] * arrays[quantity['key']][:, axis] / 2.83
    mid_pressure.append(terms[np.arange(len(ids)) != hf].sum())
    hf_pressure.append(terms[hf])

objectives = AcousticObjectives.model_validate(brief.acoustic_objectives.model_dump() |
    {'acoustic_handover_hz': [3000., 5000.]})
old_check = acoustic_handover(frequencies, mid_pressure, hf_pressure, 350., (3000., 5000.))
try:
    score = score_acoustics(trial / 'system/project.blab.json', trial / 'evaluation', brief.side_gains, objectives)
    error = None
except ValueError as exc:
    if 'handover window' not in str(exc):
        raise
    score, error = None, str(exc)
report = {
    'analysis_application_source_commit': 'e1a7a42',
    'native_application_source_commit': '1187c25',
    'analysis_script_sha256': sha256(Path(__file__)),
    'unchanged_native_search_control_sha256': hashes,
    'native_runtime': result['runtime'],
    'original_score': result['winner'],
    'new_acoustic_objectives': objectives.model_dump(mode='json'),
    'original_dsp_handover_check': old_check,
    'constrained_score': score,
    'constraint_error': error,
    'new_native_solve': False, 'native_search_modified': False,
    'physical_validation': False,
    'limitations': ['Same native voltage basis; this is not a second geometry experiment',
        'The 15-frequency grid is a diagnostic grid, not an independent holdout',
        'Channel dominance is on-axis at solved samples, not an exact crossover or diaphragm power split',
        'Reported mid circuits and synthetic HF; no mesh/physical/print qualification',
        'Strict electrical validation remains failed for native complex64 storage'],
}
assert all(sha256(search / name) == digest for name, digest in hashes.items())
with (root / 'runs/target-handover-reanalysis.json').open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({'old_ripple_db': result['winner']['ripple_db'],
    'new_ripple_db': None if score is None else score['ripple_db'],
    'original_handover': old_check, 'new_score': score, 'error': error}, indent=2))
