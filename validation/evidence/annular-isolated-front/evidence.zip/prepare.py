from pathlib import Path
import json
import gmsh
root=Path(__file__).resolve().parent
source=root.parent/'annular-fixed-mesh-quadrature/system/meshes/front.msh'
gmsh.initialize()
try:
 gmsh.option.setNumber('General.Terminal',1)
 gmsh.open(str(source))
 volumes=gmsh.model.getEntities(3)
 assert len(volumes)==1
 before=gmsh.model.mesh.getElements(3)[1]
 print('Original tetrahedra:',sum(len(x) for x in before),flush=True)
 print('Volume boundary:',gmsh.model.getBoundary(volumes),flush=True)
 gmsh.model.mesh.clear(volumes)
 gmsh.option.setNumber('Mesh.MeshOnlyEmpty',1)
 gmsh.option.setNumber('Mesh.MeshSizeMin',.005)
 gmsh.option.setNumber('Mesh.MeshSizeMax',.005)
 gmsh.option.setNumber('Mesh.MeshSizeFromPoints',0)
 gmsh.option.setNumber('Mesh.MeshSizeFromCurvature',0)
 gmsh.option.setNumber('Mesh.MeshSizeExtendFromBoundary',0)
 gmsh.model.mesh.generate(3)
 gmsh.write(str(root/'front-remeshed.msh'))
 print('Output tetrahedra:',sum(len(x) for x in gmsh.model.mesh.getElements(3)[1]),flush=True)
finally:gmsh.finalize()
