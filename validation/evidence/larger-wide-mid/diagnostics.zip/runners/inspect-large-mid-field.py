"""Linear tetrahedron-plane cuts of preserved native common-mid-bank fields."""
from pathlib import Path
import json,itertools
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
from meh_studio.optimisation import verified_assessment
from meh_studio.boundary_lab import _contained
root=Path.cwd();trial=root/'runs/larger-wide-mid-32k/trial-000';e=trial/'evaluation';raw=e/'upstream'
identity=verified_assessment(trial/'system/project.blab.json',e)
man=json.loads((raw/'manifest.json').read_text());domains=json.loads(_contained(raw,man['domains_metadata_file']).read_text())['domains']
d=next(d for d in domains if d['id']=='domain:fem-volume')
with np.load(_contained(raw,man['domains_file'])) as data:
 points=data[d['coordinates']['points_m']].copy();tetra=data[d['topology']['tetrahedra']].copy()
 regions=data[d['topology']['region_index']].copy();tetra=tetra[regions==d['metadata']['region_ids'].index('region:front')]
project=json.loads((trial/'system/project.blab.json').read_text())
ports={p['id']:p['component_id'] for p in project['physical_system']['excitation_ports']}
w=np.array([0. if ports[p]=='component:throat' else 1. for p in man['excitation_port_ids']])/2.83
# Each cut point retains interpolation weights in the original native tetrahedron.
def cut(axis):
 distance=points[:,axis];near=tetra[(distance[tetra].min(axis=1)<=0)&(distance[tetra].max(axis=1)>=0)]
 coords=[];weights=[];faces=[];lookup={}
 display=[2,1 if axis==0 else 0]
 for tet in near:
  candidates=[]
  for a,b in itertools.combinations(tet,2):
   da,db=distance[a],distance[b]
   if da==0:candidates.append((points[a],[(a,1.)]))
   if db==0:candidates.append((points[b],[(b,1.)]))
   if da*db<0:
    t=da/(da-db);candidates.append((points[a]*(1-t)+points[b]*t,[(a,1-t),(b,t)]))
  ids=[]
  for point,interpolation in candidates:
   key=tuple(np.round(point[display],12))
   if key not in lookup:lookup[key]=len(coords);coords.append(point[display]);weights.append(interpolation)
   if lookup[key] not in ids:ids.append(lookup[key])
  if len(ids)<3:continue
  xy=np.array([coords[i] for i in ids]);centre=xy.mean(axis=0)
  ids=[ids[i] for i in np.argsort(np.arctan2(xy[:,1]-centre[1],xy[:,0]-centre[0]))]
  faces.extend((ids[0],ids[j],ids[j+1]) for j in range(1,len(ids)-1))
 faces=np.array(list(dict.fromkeys(tuple(sorted(t)) for t in faces)))
 return np.array(coords),weights,faces
cuts=[cut(1),cut(0)]
fig,axes=plt.subplots(2,3,figsize=(12,7),layout='constrained')
for col,freq in enumerate((1200.,2000.,3000.)):
 row=next(row for row in man['results'] if row['freq_hz']==freq)
 meta=json.loads(_contained(raw,row['metadata_file']).read_text());q=next(q for q in meta['quantities'] if q['id']=='acoustic:pressure:fem-nodes')
 with np.load(_contained(raw,row['arrays_file'])) as data:pressure=w@data[q['key']]
 for rowid,(xy,weights,faces) in enumerate(cuts):
  sampled=np.array([sum(pressure[i]*weight for i,weight in p) for p in weights])
  level=20*np.log10(np.maximum(abs(sampled)/20e-6,1e-6))
  triang=mtri.Triangulation(xy[:,0],xy[:,1],faces)
  im=axes[rowid,col].tripcolor(triang,level,vmin=85,vmax=130,cmap='magma',shading='gouraud')
  axes[rowid,col].set(aspect='equal',title=f'{freq:g} Hz',xlabel='Axial position (m)',ylabel=('Horizontal' if rowid==0 else 'Vertical')+' position (m)')
fig.colorbar(im,ax=list(axes.flat),label='Internal pressure level (dB re 20 µPa) at 1 V RMS common mid drive',shrink=.8)
fig.suptitle('Larger baseline: native front-air pressure field, HF held at zero voltage\nReported mid circuits + synthetic HF; linear tetrahedral cuts; no mesh/physical qualification',fontsize=11)
fig.savefig(root/'runs/larger-mid-field.png',dpi=150)
assert verified_assessment(trial/'system/project.blab.json',e)==identity
print('Saved field cuts from unchanged verified native evidence')
