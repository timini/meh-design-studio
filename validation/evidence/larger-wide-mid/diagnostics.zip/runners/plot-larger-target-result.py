"""Completed baseline/winner comparison with identical selected DSP."""
from pathlib import Path
import json,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator,FixedFormatter,NullLocator
from meh_studio.search_results import load_completed_search
from meh_studio.acoustic_objectives import lr4
root=Path.cwd();path=root/'runs/larger-wide-mid-32k'
hashes,result,brief,*_=load_completed_search(path)
rows=[result['trials'][0],result['winner']]
assert rows[0]['drive_settings']==rows[1]['drive_settings']
f=np.array(brief.frequencies_hz)
fig,ax=plt.subplots(figsize=(9,4.8),layout='constrained')
for row,label in zip(rows,['Declared baseline','Selected mutation']):
    residual=np.array(row['relative_response_db'])-20*np.log10(abs(lr4(f,350.,'highpass')))
    assert abs(np.ptp(residual)-row['ripple_db'])<1e-10
    residual-=(residual.max()+residual.min())/2
    ax.semilogx(f,residual,'o-',label=f'{label}, trial {row["index"]} ({row["ripple_db"]:.2f} dB range)')
ax.axhspan(-3,3,color='#168358',alpha=.12,label='Provisional ±3 dB screen')
ax.set(xlabel='Frequency (Hz)',ylabel='Midpoint-centred residual after 350 Hz roll-off (dB)',title='Larger horn search: shape mutation improves the result, but the target is still missed')
ax.xaxis.set_major_locator(FixedLocator(f));ax.xaxis.set_major_formatter(FixedFormatter([f'{int(v):,}' for v in f]));ax.xaxis.set_minor_locator(NullLocator())
ax.grid(alpha=.2);ax.legend(fontsize=9);ax.set_ylim(-5,5)
fig.text(.5,-.045,'Same reported 4FE32 mids, synthetic HF and selected DSP. Eight solved frequencies; curves connect samples.\nNo frequency holdout, mesh convergence, commercial HF or physical qualification.',ha='center',fontsize=9)
fig.savefig(root/'docs/assets/larger-target-result.png',dpi=150,bbox_inches='tight')
assert load_completed_search(path)[0]==hashes
print('Verified completed baseline/winner comparison with identical DSP')
