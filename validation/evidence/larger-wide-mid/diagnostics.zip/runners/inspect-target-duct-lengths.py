"""Measure centre-line port gaps against the unported CAD, not nominal settings."""
from pathlib import Path
import json,math
import cadquery as cq
from meh_studio.geometry import HornGeometry
from meh_studio.waveguide_profile import horn_solids
from meh_studio.boundary_lab import sha256
root=Path.cwd();trial=root/'runs/larger-wide-mid-32k/trial-000'
candidate=json.loads((trial/'candidate.json').read_text());manifest=json.loads((trial/'geometry/geometry.json').read_text())
score=json.loads((trial/'score.json').read_text())
assert sha256(trial/'geometry/geometry.json')==score['geometry_manifest_sha256']
assert manifest['design']==candidate['design']
design=HornGeometry.model_validate(candidate['design']);air,_=horn_solids(design)
rows=[]
for source in manifest['sources']:
    axis=source['motion_axis'];diaphragm=math.hypot(*source['front_center_m'][:2])
    outer=diaphragm-design.front_depth_m
    gaps=[]
    for shift in (0.,.020):
        z=(design.entry_positions_m[0]-shift)*1000
        low,high=0.,(design.mouth_radius_m+design.length_m)*1000
        assert air.isInside(cq.Vector(0,0,z))
        assert not air.isInside(cq.Vector(axis[0]*high,axis[1]*high,z))
        for _ in range(45):
            mid=(low+high)/2
            if air.isInside(cq.Vector(axis[0]*mid,axis[1]*mid,z),1e-8):low=mid
            else:high=mid
        horn_radius=(low+high)/2000
        gaps.append({'port_shift_toward_throat_m':shift,'entry_z_m':z/1000,
            'unported_horn_surface_radius_m':horn_radius,'cavity_back_face_radius_m':outer,
            'centre_line_gap_m':outer-horn_radius})
    rows.append({'source_id':source['id'],'driver_centre_z_m':source['front_center_m'][2],
        'diaphragm_radius_from_axis_m':diaphragm,'measurements':gaps})
report={'application_source_commit':'1187c25','baseline_candidate_sha256':sha256(trial/'candidate.json'),
    'baseline_geometry_sha256':sha256(trial/'geometry/geometry.json'),
    'nominal_port_length_m':design.port_length_m,'rows':rows,
    'method':'45-step radial bisection against unported CadQuery solid at each port centre; 1e-8 mm containment tolerance',
    'limitations':['Centre-line geometric distance, not an effective acoustic length or predicted resonance',
        'No port end correction, cavity field, damping or diffraction is inferred',
        'Shifted port keeps the baseline driver/cavity position; actual new coupled solve is required']}
(root/'runs/target-duct-lengths.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
