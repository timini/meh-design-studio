"""Attach verified plotting scripts/images to the preserved historical search."""
from pathlib import Path
import json,zipfile
from meh_studio.boundary_lab import sha256
root=Path.cwd();target=root/'validation/evidence/larger-wide-mid';archive=target/'diagnostics.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name in ('plot-larger-target-result.py','inspect-large-mid-field.py','inspect-target-duct-lengths.py','package-larger-diagnostics.py'):
        z.write(root/'runs'/name,'runners/'+name)
    for name in ('larger-target-result.png','larger-mid-field.png'):
        z.write(root/'docs/assets'/name,'figures/'+name)
    z.write(root/'runs/target-duct-lengths.json','target-duct-lengths.json')
report_path=target/'report.json';report=json.loads(report_path.read_text())
report['archives'].append({'file':archive.name,'sha256':sha256(archive),'size_bytes':archive.stat().st_size})
report['diagnostic_source_commit']='1187c25'
report['diagnostics']={'baseline_field_trial':0,'winner_comparison_trial':7,'comparison_dsp_identical':True,
    'centre_line_duct_inspection':'CAD distances only; no effective acoustic length or resonance attribution'}
report_path.write_text(json.dumps(report,indent=2)+'\n')
for item in report['archives']:
    path=target/item['file'];assert sha256(path)==item['sha256'];assert path.stat().st_size==item['size_bytes']
    with zipfile.ZipFile(path) as z:assert z.testzip() is None
print('All ten archive hashes, sizes and CRC checks passed.')
