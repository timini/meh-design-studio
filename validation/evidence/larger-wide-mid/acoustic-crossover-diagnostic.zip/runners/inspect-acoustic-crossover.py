"""Separate mid-bank and HF-channel pressure contributions under saved DSP."""
from pathlib import Path
import json,numpy as np
from meh_studio.search_results import load_completed_search
from meh_studio.optimisation import verified_assessment
from meh_studio.boundary_lab import _contained
from meh_studio.acoustic_objectives import drive_weights
root=Path.cwd();path=root/'runs/larger-wide-mid-32k'
hashes,result,*_=load_completed_search(path);trial=path/f'trial-{result["winner_index"]:03d}'
raw=trial/'evaluation/upstream';m=json.loads((raw/'manifest.json').read_text())
system=json.loads((trial/'system/project.blab.json').read_text())['physical_system']
ports={p['id']:p['component_id'] for p in system['excitation_ports']};ids=[ports[p] for p in m['excitation_port_ids']];hf=ids.index('component:throat')
f=np.array([r['freq_hz'] for r in m['results']]);w=drive_weights(f,ids,result['winner']['drive_settings'])
d=next(d for d in json.loads(_contained(raw,m['domains_metadata_file']).read_text())['domains'] if d['id']=='observation:horizontal-polar')
with np.load(_contained(raw,m['domains_file'])) as a:axis=int(np.flatnonzero(a[d['coordinates']['angle_deg']]==0)[0])
rows=[]
for i,r in enumerate(m['results']):
 meta=json.loads(_contained(raw,r['metadata_file']).read_text());assert meta['diagnostics']['transducer_reference_voltage_v']==2.83
 q=next(q for q in meta['quantities'] if q['id']=='acoustic:pressure:horizontal-polar')
 with np.load(_contained(raw,r['arrays_file'])) as a:terms=w[i]*a[q['key']][:,axis]/2.83
 high=terms[hf];mid=terms[np.arange(len(ids))!=hf].sum()
 rows.append({'frequency_hz':r['freq_hz'],'mid_channel_pressure_pa_per_v':float(abs(mid)),
  'hf_channel_pressure_pa_per_v':float(abs(high)),
  'mid_over_hf_db':float(20*np.log10(abs(mid)/abs(high))),
  'phase_difference_deg':float(np.angle(mid/high,deg=True))})
report={'search_control_sha256':hashes,'winner_index':result['winner_index'],'drive_settings':result['winner']['drive_settings'],'rows':rows,
 'definition':'On-axis pressure contribution grouped by excitation channel, retaining every induced driver response in each native basis',
 'limitations':['Channel contributions, not independent diaphragm radiation or energy fractions',
  'Only sampled frequencies; no interpolation or exact acoustic crossover frequency claimed',
  'Reported mids with synthetic HF and no mesh/physical qualification']}
assert load_completed_search(path)[0]==hashes
(root/'runs/larger-acoustic-crossover.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['rows'],indent=2))
