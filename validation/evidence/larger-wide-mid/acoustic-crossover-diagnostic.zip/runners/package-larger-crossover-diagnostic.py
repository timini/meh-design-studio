from pathlib import Path
import json,zipfile
from meh_studio.boundary_lab import sha256
root=Path.cwd();target=root/'validation/evidence/larger-wide-mid';path=target/'acoustic-crossover-diagnostic.zip'
with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name in ('inspect-acoustic-crossover.py','package-larger-crossover-diagnostic.py'):
  z.write(root/'runs'/name,'runners/'+name)
 z.write(root/'runs/larger-acoustic-crossover.json','larger-acoustic-crossover.json')
report_path=target/'report.json';r=json.loads(report_path.read_text())
r['archives'].append({'file':path.name,'sha256':sha256(path),'size_bytes':path.stat().st_size})
r['diagnostics']['acoustic_crossover']={'source_commit':'1187c25','kind':'on_axis_excitation_channel_contributions',
 'mid_over_hf_at_2000_hz_db':-1.70965458221682,'mid_over_hf_at_3000_hz_db':-4.609881584807628,
 'interpretation':'3 kHz electrical filter setting does not establish a 3 kHz acoustic handover; no exact crossover frequency inferred'}
report_path.write_text(json.dumps(r,indent=2)+'\n')
with zipfile.ZipFile(path) as z:assert z.testzip() is None
assert sha256(path)==r['archives'][-1]['sha256']
print('New acoustic-crossover diagnostic archive verified.')
