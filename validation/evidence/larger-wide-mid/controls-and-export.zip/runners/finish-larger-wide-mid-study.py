"""Verify, export and preserve the completed historical larger-horn search."""
from pathlib import Path
import json,zipfile
from meh_studio.search_results import load_completed_search
from meh_studio.build_bundle import export_search
from meh_studio.operating import search_operating_report
from meh_studio.boundary_lab import sha256
root=Path.cwd();source=root/'runs/larger-wide-mid-32k';target=root/'validation/evidence/larger-wide-mid'
hashes,search,brief,base,winner,gain=load_completed_search(source)
export_path=root/'runs/larger-wide-mid-winner.zip'
export_report=export_search(source,export_path)
operating=search_operating_report(source,1.)
target.mkdir(parents=True,exist_ok=False)
archives=[]
for trial in search['trials']:
    directory=source/f'trial-{trial["index"]:03d}'
    archive=target/f'trial-{trial["index"]:03d}.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(directory.rglob('*')):
            if p.is_file():z.write(p,str(p.relative_to(source)))
    archives.append({'file':archive.name,'sha256':sha256(archive),'size_bytes':archive.stat().st_size})
control=target/'controls-and-export.zip'
with zipfile.ZipFile(control,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(source.iterdir()):
        if p.is_file():z.write(p,p.name)
    for name in ('run-larger-wide-mid-32k.py','finish-larger-wide-mid-study.py','plot-larger-baseline.py','inspect-large-mid-field.py','inspect-target-duct-lengths.py'):
        z.write(root/'runs'/name,'runners/'+name)
    z.write(export_path,'exports/'+export_path.name)
    z.write(root/'runs/target-duct-lengths.json','diagnostics/target-duct-lengths.json')
archives.append({'file':control.name,'sha256':sha256(control),'size_bytes':control.stat().st_size})
report={'application_source_commit':'a0a604e','source_state':'clean detached workload-source',
    'export_and_operating_source_commit':'1187c25','status':'exploratory_search_complete',
    'search':search,'archives':archives,'export_verification':export_report,
    'physical_validation':False,'mesh_convergence':False,'all_commercial_sources':False,
    'limitations':['Eight proposals on eight frequencies are not a global optimum or full-band validation',
        'Reported FaitalPRO 4FE32 16-ohm mid circuits with an explicitly synthetic HF placeholder',
        'No whole-sphere observations or independent axial offset gene in this historical source',
        'Ideal source interfaces do not qualify commercial basket/flange/cone geometry',
        'Costs are frozen planning allowances, not supplier quotes or a fully mounted assembly',
        'Strict complex128 electrical gate remains failed for native complex64 storage',
        'Original geometry/conformer failures retained; later code fixes do not relabel them']}
(target/'operating-1vrms.json').write_text(json.dumps(operating,indent=2)+'\n')
(target/'report.json').write_text(json.dumps(report,indent=2)+'\n')
assert load_completed_search(source)[0]==hashes
print(json.dumps({'winner_index':search['winner_index'],'trials':[{k:t.get(k) for k in ('index','status','ripple_db','objective','error')} for t in search['trials']], 'export':export_report,'archives':archives},indent=2))
