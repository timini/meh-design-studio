"""Wider geometric exploration; reported 4FE32 mids and labelled synthetic HF."""
from pathlib import Path
import json
from meh_studio.boundary_lab import BoundaryLabRuntime
from meh_studio.domain import DriverRevision
from meh_studio.catalogue import Catalogue
from meh_studio.optimisation import SearchBrief,optimise,candidates
from meh_studio.geometry import HornGeometry
root=Path.cwd();source=root/'runs/workload-source';native=root/'runs/runtime'
drivers=[DriverRevision.model_validate_json((source/'examples/reported-drivers/faitalpro-4fe32-16.json').read_text()),DriverRevision.model_validate(json.loads((source/'examples/synthetic-search-drivers.json').read_text())[0])]
base_data=json.loads((source/'examples/freeform-ring-geometry.json').read_text())
base_data.update(length_m=.3,mouth_radius_m=.22,entry_positions_m=[.06],port_radius_m=.016,port_length_m=.006,front_depth_m=.003,rear_depth_m=.07,mesh_size_m=.008,maximum_tetrahedra=5000000,maximum_exterior_triangles=32000)
for section in base_data['profile_sections']:
 section['radial_scales']=[1.05,1.,.95,1.,1.05,1.,.95,1.]
base=HornGeometry.model_validate(base_data)
brief=SearchBrief.model_validate({'frequencies_hz':[350,700,1200,2000,3000,4000,5000,7500],
 'throat_ids':['synthetic-throat'],'side_ids':['faitalpro-4fe32-16'],
 'prices':{'synthetic-throat':60,'faitalpro-4fe32-16':30},'max_driver_cost':220,
 'max_drivers':5,'lengths_m':[.3],'mouth_radii_m':[.22],'entry_fractions':[[.2]],
 'side_gains':[.1,.2,.4,.8,1.6,3.2], 'trial_budget':8,'seed':20260910,'exterior_mesh_size_m':.015,
 'evolution':{'elite_size':2,'explore_every':4,'sigma_fraction':.18,'profile_scale_bounds':[.85,1.2],'geometry_bounds':{'length_m':[.25,.35],'mouth_radius_m':[.18,.25],'entry_fraction_0':[.18,.3],'port_radius_m':[.009,.024],'port_length_m':[.003,.018],'front_depth_m':[.002,.008]}},
 'build_budget':{'maximum_total_cost':300.,'material_density_kg_m3':1270.,'material_cost_per_kg':16.,'process_allowance_factor':1.2,'other_cost_allowance':55.},
 'acoustic_objectives':{'mid_highpass_hz':350,'upper_crossovers_hz':[3000,4000,5000],'horizontal_coverage_deg':90,'vertical_coverage_deg':90,'minimum_bank_impedance_ohm':2,'hf_delays_s':[0.,.00015,.0003,.00045,.0006,.00075,.0009]}})
# Prices are planning allowances; the HF circuit is not a commercial prediction.
rows=candidates(brief,base,drivers)
print('Candidate input contracts passed',flush=True)
if __name__=='__main__':
 with Catalogue.create(root/'runs/larger-wide-mid-32k.sqlite') as catalogue:
  for d in drivers:catalogue.add(d)
 runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',native/'julia-1.12.6/bin/julia',julia_threads=4)
 print(json.dumps(optimise(brief,base,root/'runs/larger-wide-mid-32k.sqlite',runtime,root/'runs/larger-wide-mid-32k',solver_stage_timeout_s=3600),indent=2))
