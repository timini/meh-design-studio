"""Diagnostic snapshot of completed trial zero; not the running search's winner."""
from pathlib import Path
import json,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator,FixedFormatter,NullLocator
from meh_studio.acoustic_objectives import lr4
root=Path.cwd()
paths=[root/'runs/wide-mid-target-budget/trial-003/score.json',root/'runs/larger-wide-mid-32k/trial-000/score.json']
f=np.array([350.,700.,1200.,2000.,3000.,4000.,5000.,7500.])
fig,ax=plt.subplots(figsize=(9,4.8),layout='constrained')
for p,label in zip(paths,['Earlier compact winner: 4 × 3FE25','Larger baseline: 4 × 4FE32']):
 row=json.loads(p.read_text());residual=np.array(row['relative_response_db'])-20*np.log10(abs(lr4(f,350,'highpass')))
 residual-=(residual.max()+residual.min())/2
 ax.semilogx(f,residual,'o-',label=f'{label} ({row["ripple_db"]:.2f} dB span)')
ax.axhspan(-3,3,color='#168358',alpha=.12,label='Provisional ±3 dB screen')
ax.set(xlabel='Frequency (Hz)',ylabel='Residual after intended 350 Hz roll-off (dB)',title='Larger baseline improves the sampled result, but still misses the target')
ax.xaxis.set_major_locator(FixedLocator(f));ax.xaxis.set_major_formatter(FixedFormatter([f'{int(v):,}' for v in f]));ax.xaxis.set_minor_locator(NullLocator())
ax.grid(alpha=.2);ax.legend(fontsize=9,loc='lower right');ax.set_ylim(-7,8)
fig.text(.5,-.045,'Both use reported mid circuits and synthetic HF. Different drivers, geometry and DSP; no isolated shape attribution.\nOnly eight solved frequencies; curves connect samples. No mesh or physical qualification.',ha='center',fontsize=9)
fig.savefig(root/'runs/larger-baseline-comparison.png',dpi=150,bbox_inches='tight')
