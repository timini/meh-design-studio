from pathlib import Path
from meh_studio.boundary_lab import BoundaryLabRuntime,SolveRequest
root=Path.cwd();native=root/'runs/runtime'
runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',native/'julia-1.12.6/bin/julia',julia_threads=4)
runtime.solve(root/'runs/sphere-reference/project.blab.json',SolveRequest(frequencies_hz=(350.,2000.,5000.,7500.),include_project_observations=True,retain=('bem_boundary_traces',)),root/'runs/sphere-evaluation',timeout_s=900)
