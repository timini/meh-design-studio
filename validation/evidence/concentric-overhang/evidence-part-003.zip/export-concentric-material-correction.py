"""Create a separately attributed material export without changing the native run."""
from pathlib import Path
import json,subprocess,zipfile
from meh_studio.geometry import HornGeometry,export_geometry
from meh_studio.radiation_geometry import step_geometry_sha256
from meh_studio.boundary_lab import sha256
root=Path.cwd();old=root/'runs/concentric-overhang-search/trial-000/geometry';original=json.loads((old/'geometry.json').read_text())
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert commit=='91abae312980c3a1c464ba8e5fc065818f923303'
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
identities={'geometry.json':sha256(old/'geometry.json')}|{row['path']:sha256(old/row['path']) for row in original['files']}
out=root/'runs/concentric-overhang-final-material-export';design=HornGeometry.model_validate(original['design']);result=export_geometry(design,out)
assert result['design_hash']==original['design_hash'] and result['sources']==original['sources']
checks={}
for row in original['files']:
 if not row['path'].endswith('.step'):continue
 before=step_geometry_sha256(old/row['path']);after=step_geometry_sha256(out/row['path']);checks[row['path']]={'original_step_geometry_sha256':before,'corrected_step_geometry_sha256':after,'identical':before==after}
assert all(v['identical'] for v in checks.values()),'retained continuous CAD differs from corrected export'
assert identities=={rel:sha256(old/rel) for rel in identities}
report={'kind':'separate_material_retessellation','application_source_commit':commit,'native_application_source_commit':'ad0b400584a546442a0d2dbb3f74f3247a6372ac','runner_sha256':sha256(Path(__file__)),'original_geometry_sha256':identities['geometry.json'],'corrected_geometry_sha256':sha256(out/'geometry.json'),'original_files_unchanged':True,'step_geometry_checks':checks,'design_hash':design.content_hash,'export_checks':result['export_checks'],'new_native_solve':False,'qualified':False,'limitations':['This is a corrected material export, not a completed-search build bundle or native run of the newer source.','The native candidate fails its response and rotational limits.','Purchased-driver mounting, basket fit and print qualification remain open.']}
(out/'derivation.json').write_text(json.dumps(report,indent=2)+'\n')
archive=root/'runs/concentric-overhang-corrected-materials.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(out).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in result['files']:assert sha256(out/row['path'])==row['sha256']
print(json.dumps({'status':result['status'],'step_files_identical':len(checks),'archive_sha256':sha256(archive),'parts':len(result['export_checks']['parts']),'maximum_stl_volume_error':max(r['relative_cad_volume_error'] for r in result['export_checks']['parts'])},indent=2))
