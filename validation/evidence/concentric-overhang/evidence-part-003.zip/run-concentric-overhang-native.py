"""Native single-candidate concentric entry experiment with an explicit HF exterior package."""
from pathlib import Path
import argparse,json,subprocess
from meh_studio.boundary_lab import BoundaryLabRuntime,sha256
from meh_studio.catalogue import Catalogue
from meh_studio.domain import DriverRevision
from meh_studio.geometry import HornGeometry
from meh_studio.optimisation import SearchBrief,candidates,optimise
from meh_studio.evolution import validate_bounds
from meh_studio.build_bundle import export_search
from meh_studio.search_results import load_completed_search
root=Path.cwd();runs=root/'runs';source=runs/'throat-body-source'
p=argparse.ArgumentParser();p.add_argument('--prepare',action='store_true');args=p.parse_args()
commit=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
assert commit.startswith('ad0b400')
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True)
import meh_studio.evolution
assert Path(meh_studio.evolution.__file__).resolve().is_relative_to(source)
prior_path=runs/'quarter-commercial-rim-controls.json';prior=json.loads(prior_path.read_text())
seed_path=runs/'concentric-overhang-seed-cad/geometry.json';seed=json.loads(seed_path.read_text());assert seed['status']=='complete'
base=HornGeometry.model_validate(seed['design']);assert base.content_hash==seed['design_hash']
value=prior['brief'];value.update(trial_budget=1,seed=20260923,lengths_m=[base.length_m],
 mouth_radii_m=[base.mouth_radius_m],entry_fractions=[[base.entry_positions_m[0]/base.length_m]])
value['evolution'].update(mutate_profile=False,elite_size=1,explore_every=3,geometry_bounds={'port_length_m':[.020,.030]})
brief=SearchBrief.model_validate(value);validate_bounds(brief.evolution,base)
drivers=[DriverRevision.model_validate(d) for d in prior['drivers']]
assert candidates(brief,base,drivers)[0]['design'].content_hash==base.content_hash
assert brief.acoustic_objectives.minimum_bank_impedance_ohm==2.
assert brief.acoustic_objectives.acoustic_handover_hz==(3000.,5000.)
assert brief.acoustic_objectives.mid_highpass_hz==350. and brief.build_budget.maximum_total_cost==300.
assert list(brief.frequencies_hz)==prior['brief']['frequencies_hz']
controls={'application_source_commit':commit,'runner_sha256':sha256(Path(__file__)),
 'original_search_controls_sha256':sha256(prior_path),'seed_cad_manifest_sha256':sha256(seed_path),
 'layered_rear_comparison_sha256':sha256(runs/'commercial-layered-rear/comparison.json'),
 'focused_entry_seed_score_sha256':sha256(runs/'focused-entry-search/trial-000/score.json'),
 'hf_package_dimension_source':'https://products.peerless-audio.com/api/driver/438',
 'base':base.model_dump(mode='json'),'brief':brief.model_dump(mode='json'),
 'drivers':[d.model_dump(mode='json') for d in drivers],
 'backend':'coupled_reference','julia_threads':2,'solver_stage_timeout_s':7200,
 'maximum_total_tetrahedra':600000,'maximum_final_exterior_triangles':10000,
 'response_screen_limit_db':6.,'electrical_relative_tolerance':1e-8,'field_relative_limit':.02,
 'hypothesis':'Remove the 20mm chamber offset from the 30mm-entry seed, increase port length to25mm to clear the declared 45mm-radius by50.8mm-deep HF package, and include that body in exterior BEM. Test whether concentric cavities avoid the retained eccentric geometry anti-resonance. This changes geometry and is not an isolated single-parameter comparison.',
 'selection':'One declared candidate, same public source circuits and15frequency/DSPgrid. No optimisation improvement or global optimum claim from this pilot.',
 'qualified':False,'limitations':[
 'This is a new concentric overhanging geometry and exterior package; all prior native evidence and controls remain unchanged.',
 'Layered 0.5mm rear mesh improves the ideal cylinder; front/exterior convergence and denser frequency holdouts still required.',
 'Public T/S source data do not establish loaded phase-plug, cone/basket, breakup, physical fit, output or printing qualification.',
 'GBP300 is a design allowance, not a current supplier quote; no exact 2ohm plate amplifier is qualified.',
 'One declared candidate does not establish a global optimum or equivalence with Solana.']}
cp=runs/'concentric-overhang-controls.json'
if args.prepare:
 with cp.open('x') as f:f.write(json.dumps(controls,indent=2)+'\n')
 print(json.dumps({'controls_sha256':sha256(cp),'source_commit':commit,'trial_budget':brief.trial_budget,'seed_hash':base.content_hash},indent=2));raise SystemExit
assert json.loads(cp.read_text())==controls
class BoundedRuntime(BoundaryLabRuntime):
 def solve(self,project,request,output,*,timeout_s=7200):
  import meshio
  from meh_studio.radiation_geometry import surface_integrity
  document=json.loads(Path(project).read_text());assert document['symmetry']=='xy';total=0
  for resource in document['physical_system']['meshes']:
   mesh_path=Path(project).parent/resource['file']
   if resource['purpose']=='fem_volume':
    mesh=meshio.read(mesh_path);total+=sum(len(cell.data) for cell in mesh.cells if cell.type=='tetra')
   else:surface_integrity(mesh_path,maximum_triangles=controls['maximum_final_exterior_triangles'],symmetry='xy')
  assert total<=controls['maximum_total_tetrahedra'],'concentric overhang total tetrahedron cap exceeded'
  return super().solve(project,request,output,timeout_s=timeout_s)
output=runs/'concentric-overhang-search';database=runs/'concentric-overhang-search.sqlite'
assert not output.exists() and not database.exists()
with Catalogue.create(database) as catalogue:
 for driver in drivers:catalogue.add(driver)
native=runs/'runtime';runtime=BoundedRuntime(native/'boundary-lab',native/'blab-env/bin/python',
 native/'julia-1.12.6/bin/julia','coupled_reference',julia_threads=2)
result=optimise(brief,base,database,runtime,output,solver_stage_timeout_s=7200)
(output/'experiment-provenance.json').write_text(json.dumps({'application_source_commit':commit,
 'controls_sha256':sha256(cp),'qualified':False,'limitations':controls['limitations']},indent=2)+'\n')
load_completed_search(output)
export=export_search(output,runs/'concentric-overhang-winner.zip')
(output/'export-verification.json').write_text(json.dumps(export,indent=2)+'\n')
print(json.dumps({'status':result['status'],'winner_index':result['winner_index'],'export':export},indent=2))
