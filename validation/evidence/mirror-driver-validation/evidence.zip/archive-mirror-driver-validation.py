"""Preserve native quarter prototype and corrected postprocessing separately."""
from pathlib import Path
import json
import zipfile
from meh_studio.boundary_lab import sha256

root = Path.cwd(); runs = root / 'runs'
reanalysis = json.loads((runs / 'mirror-quarter-electrical-reanalysis.json').read_text())
assert reanalysis['runner_sha256'] == sha256(runs / 'recheck-symmetry-bank-validation.py')
for name, digest in reanalysis['postprocessor_source_sha256'].items():
    assert sha256(root / name) == digest
comparison = runs / 'mirror-quarter-reference-native/comparison.json'
assert sha256(comparison) == reanalysis['original_comparison_sha256']
controls = runs / 'mirror-quarter-reference-native-controls.json'
native = json.loads((runs / 'mirror-quarter-reference-native/report.json').read_text())
assert native['status'] == 'complete' and native['controls_sha256'] == sha256(controls)
inputs = json.loads(controls.read_text())['input_sha256']
for name, digest in inputs.items():
    assert sha256(runs / 'mirror-quarter-reference-mesh' / name) == digest
files = {}
for name in ['mirror-quarter-reference-preparation', 'mirror-quarter-reference-partition',
             'mirror-quarter-reference-adaptive', 'mirror-quarter-reference-mesh',
             'mirror-quarter-reference-native']:
    for path in sorted((runs / name).rglob('*')):
        if path.is_file(): files[str(path.relative_to(runs))] = path
for path in sorted(runs.glob('*mirror-quarter*')):
    if path.is_file(): files[path.name] = path
for name in ['native-quarter-mouth-conform.py', 'recheck-symmetry-bank-validation.py',
             'symmetry-bank-validation-tests.log', 'symmetry-bank-validation-noncad.log',
             'archive-mirror-driver-validation.py']:
    files[name] = runs / name
for name in reanalysis['postprocessor_source_sha256']:
    files['postprocessor-source/' + name] = root / name
for name in ['tests/test_electrical_validation.py']:
    files['postprocessor-source/' + name] = root / name
inventory = {name: sha256(path) for name, path in files.items()}
target = root / 'validation/evidence/mirror-driver-validation'
target.mkdir(parents=True, exist_ok=False)
path = target / 'evidence.zip'
with zipfile.ZipFile(path, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, file in files.items(): archive.write(file, name)
with zipfile.ZipFile(path) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(inventory)
assert inventory == {name: sha256(file) for name, file in files.items()}
assert path.stat().st_size < 100_000_000
report = {'status': 'complete_mirror_driver_validation_study',
          'native_source_commit': reanalysis['native_source_commit'],
          'reanalysis': reanalysis, 'archives': [{'file': path.name,
             'size_bytes': path.stat().st_size, 'sha256': sha256(path)}],
          'archived_file_sha256': inventory,
          'full_reference_archive': '../tilted-entry-search/report.json',
          'cram_regression_archive': '../bem-quadrature/report.json',
          'qualified': False, 'physical_validation': False}
(target / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'archives': report['archives'], 'archived_files': len(files)}, indent=2))
