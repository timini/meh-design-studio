"""Verify the CAD partition with adaptive area integration on trimmed spline faces."""
from pathlib import Path
import json, math, subprocess
import numpy as np
from meh_studio.boundary_lab import sha256
from meh_studio.geometry import HornGeometry
from meh_studio.cad_runtime import load_cadquery
from meh_studio.waveguide_profile import cad_volume
from meh_studio.radiation_geometry import meshing_runtime_identity

root=Path.cwd(); runs=root/'runs'; full=runs/'tilted-entry-10mm/trial-000'
out=runs/'mirror-quarter-reference-adaptive'; out.mkdir(exist_ok=False)
source_commit=subprocess.check_output(['git','-C',str(runs/'tilted-entry-source'),'rev-parse','HEAD'],text=True).strip()
assert source_commit=='9fdafd6a57e4f83ef24562a471ddb059dcc0b686'
gpath=full/'geometry/geometry.json'; geometry=json.loads(gpath.read_text())
design=HornGeometry.model_validate(geometry['design']); assert geometry['status']=='complete'
assert design.content_hash==geometry['design_hash']
inputs={'geometry':gpath,'full_project':full/'system/project.blab.json','envelope':full/'system/exterior/envelope.step'}
inputs.update({k:full/'geometry/air'/f'{k}.step' for k in geometry['air_volume_m3']})
identities={k:{'path':str(p.relative_to(runs)),'sha256':sha256(p)} for k,p in inputs.items()}
controls={'source_commit':source_commit,'runner_sha256':sha256(Path(__file__)),'inputs':identities,
          'previous_attempt_controls_sha256':sha256(runs/'mirror-quarter-reference-partition/controls.json'),
          'symmetry':'xy','cad_relative_volume_limit':1e-6,'source_area_relative_limit':1e-6,
          'future_final_native_maximum_triangles':5000,'future_final_native_maximum_tetrahedra':500000,
          'future_field_relative_l2_limit':.02,'future_bank_impedance_relative_limit':.02,
          'electrical_relative_tolerance':1e-8,'native_comparison_executed':False,'qualified':False,
          'limitations':['CAD preparation only; native symmetry, source completion and parallel-bank current accounting must be verified',
                         'Only sources and geometry with proven mirror-X and mirror-Y invariance can use even-XY reduction',
                         'Independent single-mid excitation is not mirror symmetric; compare coherent whole-bank and HF excitation',
                         'The full reference is itself an unqualified four-frequency synthetic-source experiment']}
(out/'controls.json').write_text(json.dumps(controls,indent=2)+'\n')
report={'status':'running','controls_sha256':sha256(out/'controls.json'),'compiler_runtime':meshing_runtime_identity()}
try:
 cq=load_cadquery(); shapes={k:cq.importers.importStep(str(p)).val() for k,p in inputs.items() if p.suffix=='.step'}
 def volume(s):return cad_volume(design,s)
 def difference(a,b):
  value=(volume(a.cut(b))+volume(b.cut(a)))/volume(a)
  assert math.isfinite(value) and value<=controls['cad_relative_volume_limit'],value
  return value
 checks={}
 for k in ['front','envelope']:
  checks[k]={plane:difference(shapes[k],shapes[k].mirror(plane)) for plane in ['YZ','XZ']}
 for a,b,plane in [('rear_entry_0_positive','rear_entry_0_negative','YZ'),('rear_entry_0_positive_y','rear_entry_0_negative_y','XZ')]:
  checks[a+'_pair']=difference(shapes[b],shapes[a].mirror(plane))
 box=cq.Workplane('XY').box(2000,2000,2000,centered=(False,False,False)).translate((0,0,-1000)).val()
 quarter={k:shapes[k].intersect(box).clean() for k in ['front','rear_entry_0_positive','rear_entry_0_positive_y','envelope']}
 fractions={'front':.25,'rear_entry_0_positive':.5,'rear_entry_0_positive_y':.5,'envelope':.25}
 for k,q in quarter.items():
  assert q.isValid() and len(q.Solids())==1
  assert math.isclose(volume(q)/volume(shapes[k]),fractions[k],rel_tol=1e-6)
  pieces=[q,q.mirror('YZ'),q.mirror('XZ'),q.mirror('YZ').mirror('XZ')]
  # The four pieces occupy disjoint open orthants. Each is contained in the
  # corresponding full source solid; their total volume equals the full model.
  # This proves the volume partition without a coincident-face Boolean union.
  piece_checks=[]
  for piece,(sx,sy) in zip(pieces,[(1,1),(-1,1),(1,-1),(-1,-1)],strict=True):
   assert piece.isValid() and len(piece.Solids())==1
   bb=piece.BoundingBox()
   assert (bb.xmin>=-1e-6 if sx==1 else bb.xmax<=1e-6)
   assert (bb.ymin>=-1e-6 if sy==1 else bb.ymax<=1e-6)
   original=shapes[k]
   if k=='rear_entry_0_positive' and sx==-1:original=shapes['rear_entry_0_negative']
   if k=='rear_entry_0_positive_y' and sy==-1:original=shapes['rear_entry_0_negative_y']
   outside=volume(piece.cut(original))/volume(piece)
   assert math.isfinite(outside) and abs(outside)<=controls['cad_relative_volume_limit'],outside
   piece_checks.append({'orthant':[sx,sy],'outside_relative_volume':outside})
  expected_total=volume(shapes[k])*(1 if k in ['front','envelope'] else 2)
  error=abs(sum(volume(v) for v in pieces)/expected_total-1)
  assert error<=controls['cad_relative_volume_limit']
  checks[k+'_partition']={'pieces':piece_checks,'relative_total_volume_error':error}
  cq.exporters.export(q,str(out/(k+'.step')))
 sources={s['id']:s for s in geometry['sources']}
 def surface_properties(face):
  from OCP.BRepGProp import BRepGProp
  from OCP.GProp import GProp_GProps
  properties=GProp_GProps();error=BRepGProp.SurfaceProperties_s(face.wrapped,properties,1e-10,False)
  assert error<=1e-9
  return properties
 def source_face(shape,centre_m,axis,expected_area_m2):
  centre=np.array(centre_m)*1000;axis=np.array(axis);axis=axis/np.linalg.norm(axis)
  matches=[f for f in shape.Faces() if f.geomType()=='PLANE' and abs(np.dot(np.array(f.Center().toTuple())-centre,axis))<1e-6 and abs(np.dot(f.normalAt().toTuple(),axis))>1-1e-10]
  assert len(matches)==1,len(matches)
  f=matches[0];properties=surface_properties(f);area=properties.Mass()/1e6
  assert math.isclose(area,expected_area_m2,rel_tol=controls['source_area_relative_limit'])
  return {'center_m':[v/1000 for v in f.Center().toTuple()],'area_m2':area,'motion_axis':list(axis)}
 descriptors={k:{} for k in quarter if k!='envelope'}
 descriptors['front']['throat_source']=source_face(quarter['front'],[0,0,0],[0,0,1],math.pi*design.throat_radius_m**2/4)
 full_mouth=next(f for f in shapes['front'].Faces() if f.geomType()=='PLANE' and abs(f.Center().z/1000-design.length_m)<1e-9)
 full_mouth_area=surface_properties(full_mouth).Mass()/1e6
 descriptors['front']['mouth_interface']=source_face(quarter['front'],[0,0,design.length_m],[0,0,1],full_mouth_area/4)
 report['mouth_area_integration']={'adaptive_full_area_m2':full_mouth_area,'original_reported_area_m2':geometry['mouth_interface']['area_m2'],'adaptive_relative_tolerance':1e-10}
 for name in ['entry_0_positive','entry_0_positive_y']:
  s=sources[name]
  descriptors['front'][name+'_front_source']=source_face(quarter['front'],s['front_center_m'],s['motion_axis'],math.pi*s['radius_m']**2/2)
  descriptors['rear_'+name][name+'_rear_source']=source_face(quarter['rear_'+name],s['rear_center_m'],s['motion_axis'],math.pi*s['radius_m']**2/2)
 representatives=[{'component':'throat','surface_completion_factor':4.,'physical_orbit_count':1.},
                  {'component':'entry_0_positive','surface_completion_factor':2.,'physical_orbit_count':2.},
                  {'component':'entry_0_positive_y','surface_completion_factor':2.,'physical_orbit_count':2.}]
 assert sum(v['physical_orbit_count'] for v in representatives)==5
 assert identities=={k:{'path':str(p.relative_to(runs)),'sha256':sha256(p)} for k,p in inputs.items()}
 report.update(status='complete_cad_preparation',geometry_checks=checks,boundary_descriptors=descriptors,
               expected_native_representatives=representatives,volumes_m3={k:volume(q)/1e9 for k,q in quarter.items()},
               files={p.name:sha256(p) for p in out.glob('*.step')},native_comparison_executed=False,qualified=False)
except BaseException as e:
 report.update(status='failed',error=f'{type(e).__name__}: {e}')
 raise
finally:
 (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'geometry_checks':checks,'volumes_m3':report['volumes_m3']},indent=2))
