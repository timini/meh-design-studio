"""Reanalyse retained native fields; never overwrite their original validation."""
from pathlib import Path
import json
import subprocess
from meh_studio.boundary_lab import sha256
from meh_studio.validation import validate_electrical_basis

root = Path.cwd()
runs = root / 'runs'
source = {str(p.relative_to(root)): sha256(p) for p in sorted((root / 'src').rglob('*.py'))}
old = runs / 'mirror-quarter-reference-native/comparison.json'
comparison = json.loads(old.read_text())
old_hash = sha256(old)
quarter = validate_electrical_basis(runs / 'mirror-quarter-reference-mesh/project.blab.json',
                                    runs / 'mirror-quarter-reference-native/evaluation')
assert quarter['passed'] and quarter['relative_tolerance'] == 1e-8
assert sorted(c['physical_driver_orbit_count'] for c in quarter['symmetry']['components'].values()) == [1, 2, 2]
full = []
saved = json.loads((runs / 'tilted-entry-10mm-native-validation.json').read_text())
for trial in saved['trials']:
    base = runs / 'tilted-entry-10mm' / trial['trial']
    report = validate_electrical_basis(base / 'system/project.blab.json', base / 'evaluation')
    assert report == trial['electrical_validation'] and not report['passed']
    full.append({'trial': trial['trial'], 'report': report, 'exactly_matches_original': True})
cram = []
study = runs / 'cram-quadrature-study'
for row in json.loads((study / 'run-summary.json').read_text())['rows']:
    report = validate_electrical_basis(study / 'project/reference.blab.json', study / row['name'])
    legacy = {k: v for k, v in report.items() if k != 'symmetry'}
    assert legacy == row['evidence']['checks'] and not report['passed']
    cram.append({'case': row['name'], 'report': report, 'all_original_metrics_unchanged': True})
assert sha256(old) == old_hash
assert source == {str(p.relative_to(root)): sha256(p) for p in sorted((root / 'src').rglob('*.py'))}
report = {
    'status': 'complete_reanalysis',
    'native_source_commit': '9fdafd6a57e4f83ef24562a471ddb059dcc0b686',
    'cram_native_source_commit': '852a5a33af9617ac3a40f9956ca12f744e3d0ba8',
    'postprocessor_parent_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'postprocessor_source_sha256': source,
    'runner_sha256': sha256(Path(__file__)),
    'quarter_electrical_validation': quarter, 'unreduced_regression': full,
    'fractional_driver_regression': cram,
    'original_comparison_sha256': old_hash,
    'original_reduced_electrical_validation': comparison['reduced_electrical_checks'],
    'fields_passed': comparison['fields_passed'],
    'maximum_field_relative_l2': max(r['relative_l2'] for r in comparison['rows']),
    'bank_impedance_passed': comparison['bank_impedance_passed'],
    'maximum_bank_relative_error': max(r['relative_l2'] for r in comparison['parallel_mid_bank']),
    'qualified': False, 'physical_validation': False,
    'limitations': ['Postprocessing of existing native arrays, not new solver runs',
                    'Mesh-verified group current accounting only; acoustic fields are unchanged',
                    'Original full-model electrical and quarter/full acoustic discrepancies remain',
                    'Quarter geometry is a standalone experiment, not an integrated search feature']}
with (runs / 'mirror-quarter-electrical-reanalysis.json').open('x') as stream:
    stream.write(json.dumps(report, indent=2) + '\n')
print(json.dumps({'quarter_electrical_passed': quarter['passed'],
                  'maximum_reciprocity_residual': max(r['electrical_reciprocity_relative_residual'] for r in quarter['rows']),
                  'full_regressions_unchanged': len(full), 'fractional_regressions_unchanged': len(cram),
                  'fields_passed': report['fields_passed'],
                  'maximum_field_relative_l2': report['maximum_field_relative_l2']}, indent=2))
