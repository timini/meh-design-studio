"""Run the predeclared full-versus-quarter reference once the small slot is free."""
from pathlib import Path
import argparse,json,subprocess,time
from meh_studio.boundary_lab import BoundaryLabRuntime,SolveRequest,sha256
from meh_studio.optimisation import verified_assessment
root=Path.cwd();runs=root/'runs';parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');args=parser.parse_args()
source=runs/'tilted-entry-source';commit=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
assert commit=='9fdafd6a57e4f83ef24562a471ddb059dcc0b686'
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True)
full=runs/'tilted-entry-10mm/trial-000';prepared=runs/'mirror-quarter-reference-mesh'
prep=json.loads((prepared/'report.json').read_text());assert prep['status']=='complete_quarter_mesh_preparation'
request=SolveRequest.model_validate_json((full/'evaluation/request.json').read_text())
assert request.frequencies_hz==(350.,1000.,2000.,3000.)
project=prepared/'project.blab.json';assert prep['project_sha256']==sha256(project)
inputs={'project.blab.json':sha256(project)}|{str(p.relative_to(prepared)):sha256(p) for p in sorted((prepared/'meshes').glob('*.msh'))}
cad_controls=json.loads((runs/'mirror-quarter-reference-adaptive/controls.json').read_text())
controls={'source_commit':commit,'runner_sha256':sha256(Path(__file__)),'preparation_report_sha256':sha256(prepared/'report.json'),
          'input_sha256':inputs,'request':request.model_dump(mode='json'),'full_reference':verified_assessment(full/'system/project.blab.json',full/'evaluation'),
          'relative_l2_limit':cad_controls['future_field_relative_l2_limit'],'bank_impedance_relative_limit':cad_controls['future_bank_impedance_relative_limit'],
          'electrical_relative_tolerance':1e-8,'backend':'coupled_reference','julia_threads':2,'solver_timeout_s':1800,
          'qualified':False,'physical_validation':False,'limitations':cad_controls['limitations']}
path=runs/'mirror-quarter-reference-native-controls.json'
if args.prepare:
 with path.open('x') as stream:stream.write(json.dumps(controls,indent=2)+'\n')
 print(json.dumps({'controls_sha256':sha256(path),'source_commit':commit},indent=2));raise SystemExit
assert json.loads(path.read_text())==controls
assert json.loads((runs/'tilted-entry-10mm/search.json').read_text())['status'] in ('complete','failed'), 'small native slot still occupied'
out=runs/'mirror-quarter-reference-native';out.mkdir(exist_ok=False);native=runs/'runtime'
runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',native/'julia-1.12.6/bin/julia','coupled_reference',julia_threads=2)
start=time.monotonic();result={'status':'running','controls_sha256':sha256(path)}
try:
 runtime.solve(project,request,out/'evaluation',timeout_s=1800)
 result.update(status='complete',evidence=verified_assessment(project,out/'evaluation'))
except Exception as e:result.update(status='failed',error=f'{type(e).__name__}: {e}')
finally:
 result['wall_s']=time.monotonic()-start
 result['input_identities_unchanged']=all(sha256(prepared/name)==digest for name,digest in inputs.items())
 assert result['input_identities_unchanged']
 assert verified_assessment(full/'system/project.blab.json',full/'evaluation')==controls['full_reference']
 (out/'report.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'wall_s':result['wall_s'],'error':result.get('error')},indent=2))
