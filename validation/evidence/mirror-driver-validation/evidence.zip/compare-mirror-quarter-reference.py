"""Compare supported even-XY excitations with the unreduced physical reference."""
from pathlib import Path
import json
import numpy as np
from meh_studio.boundary_lab import sha256,_contained
from meh_studio.optimisation import verified_assessment
root=Path.cwd();runs=root/'runs';full=runs/'tilted-entry-10mm/trial-000';small=runs/'mirror-quarter-reference-native'
prep=runs/'mirror-quarter-reference-mesh';cp=runs/'mirror-quarter-reference-native-controls.json';controls=json.loads(cp.read_text())
run=json.loads((small/'report.json').read_text());assert run['status']=='complete' and run['controls_sha256']==sha256(cp)
fe=verified_assessment(full/'system/project.blab.json',full/'evaluation');re=verified_assessment(prep/'project.blab.json',small/'evaluation')
assert fe==controls['full_reference'] and re==run['evidence']
roots=[full/'evaluation/upstream',small/'evaluation/upstream'];manifests=[json.loads((p/'manifest.json').read_text()) for p in roots]
assert manifests[0]['frequencies_hz']==manifests[1]['frequencies_hz']==controls['request']['frequencies_hz']
compiled=[json.loads((p/'compiled-system.json').read_text()) for p in roots]
components=[{c['id']:c for c in system['components']} for system in compiled]
groups={'component:throat':['component:throat'],
        'component:entry_0_positive':['component:entry_0_positive','component:entry_0_negative'],
        'component:entry_0_positive_y':['component:entry_0_positive_y','component:entry_0_negative_y']}
expected_completion={'component:throat':4,'component:entry_0_positive':2,'component:entry_0_positive_y':2}
assert set(components[1])==set(groups)
for name,represented in groups.items():
 params=components[1][name]['parameters'];assert params['surface_completion_factor']==expected_completion[name]
 assert params['physical_driver_orbit_count']==len(represented)
 for key in ['re_ohm','le_h','bl_n_per_a','mmd_kg','cms_m_per_n','rms_n_s_per_m','motion_axis']:
  assert params[key]==components[0][name]['parameters'][key]
assert sum(c['parameters']['physical_driver_orbit_count'] for c in components[1].values())==5
ports=[{p['id']:p['component_id'] for p in system['excitation_ports']} for system in compiled]
orders=[[pmap[p] for p in manifest['excitation_port_ids']] for pmap,manifest in zip(ports,manifests,strict=True)]
assert set(orders[0])==set(components[0]) and set(orders[1])==set(groups)
domains=[{d['id']:d for d in json.loads(_contained(p,m['domains_metadata_file']).read_text())['domains']} for p,m in zip(roots,manifests,strict=True)]
with np.load(_contained(roots[0],manifests[0]['domains_file']),allow_pickle=False) as a,np.load(_contained(roots[1],manifests[1]['domains_file']),allow_pickle=False) as b:
 for key,value in domains[0].items():
  if not key.startswith('observation:'):continue
  other=domains[1][key];assert value['coordinates'].keys()==other['coordinates'].keys()
  for k,v in value['coordinates'].items():assert np.array_equal(a[v],b[other['coordinates'][k]])
def relative(reference,value,limit):
 difference=float(np.linalg.norm(value-reference));norm=float(np.linalg.norm(reference));error=difference/norm if norm else (0. if difference==0 else None)
 return {'reference_norm':norm,'difference_norm':difference,'relative_l2':error,'limit':limit,'passed':error is not None and error<=limit}
rows=[];banks=[]
for fr,rr in zip(manifests[0]['results'],manifests[1]['results'],strict=True):
 assert fr['freq_hz']==rr['freq_hz'];frequency=fr['freq_hz']
 metadata=[json.loads(_contained(p,r['metadata_file']).read_text()) for p,r in zip(roots,(fr,rr),strict=True)]
 assert all(m['diagnostics']['transducer_reference_voltage_v']==2.83 for m in metadata)
 assert metadata[0]['diagnostics']['symmetry']=='off' and metadata[1]['diagnostics']['symmetry']=='xy'
 quantities=[{q['id']:q for q in m['quantities'] if q['axes'] in (['excitation','observation'],['excitation','transducer'])} for m in metadata]
 assert quantities[0].keys()==quantities[1].keys()
 with np.load(_contained(roots[0],fr['arrays_file']),allow_pickle=False) as a,np.load(_contained(roots[1],rr['arrays_file']),allow_pickle=False) as b:
  for name,fq in quantities[0].items():
   rq=quantities[1][name];fv=a[fq['key']];rv=b[rq['key']];assert fv.dtype==rv.dtype==np.complex128
   assert fq['axes']==rq['axes'] and fq['unit']==rq['unit']
   for group,physical_ids in groups.items():
    reference=fv[[orders[0].index(k) for k in physical_ids]].sum(axis=0)
    value=rv[orders[1].index(group)]
    if fq['axes']==['excitation','transducer']:
     full_components=fq['metadata']['component_ids'];reduced_components=rq['metadata']['component_ids']
     assert fq['metadata']['physical_driver_orbit_counts']==[1]*len(full_components)
     assert rq['metadata']['physical_driver_orbit_counts']==[len(groups[k]) for k in reduced_components]
     lookup={k:g for g,represented in groups.items() for k in represented}
     value=value[[reduced_components.index(lookup[k]) for k in full_components]]
    rows.append({'frequency_hz':frequency,'quantity':name,'excitation_group':group,'full_excited_components':physical_ids,**relative(reference,value,controls['relative_l2_limit'])})
  current='electrical:voice-coil-current';fq,rq=quantities[0][current],quantities[1][current]
  full_current=a[fq['key']][[i for i,k in enumerate(orders[0]) if k!='component:throat']].sum(axis=0)
  red_current=b[rq['key']][[i for i,k in enumerate(orders[1]) if k!='component:throat']].sum(axis=0)
  fi=sum(full_current[i] for i,k in enumerate(fq['metadata']['component_ids']) if k!='component:throat')
  ri=sum(red_current[i]*len(groups[k]) for i,k in enumerate(rq['metadata']['component_ids']) if k!='component:throat')
  assert abs(fi)>0 and abs(ri)>0
  fz,rz=2.83/fi,2.83/ri
  banks.append({'frequency_hz':frequency,'full_current_a':[float(fi.real),float(fi.imag)],'reduced_current_a':[float(ri.real),float(ri.imag)],
                'full_impedance_ohm':[float(fz.real),float(fz.imag)],'reduced_impedance_ohm':[float(rz.real),float(rz.imag)],
                **relative(np.array([fz]),np.array([rz]),controls['bank_impedance_relative_limit'])})
assert verified_assessment(full/'system/project.blab.json',full/'evaluation')==fe
assert verified_assessment(prep/'project.blab.json',small/'evaluation')==re
report={'status':'complete_comparison','controls_sha256':sha256(cp),'postprocessor_sha256':sha256(Path(__file__)),
        'rows':rows,'parallel_mid_bank':banks,'fields_passed':all(r['passed'] for r in rows),'bank_impedance_passed':all(b['passed'] for b in banks),
        'full_electrical_checks':fe['checks'],'reduced_electrical_checks':re['checks'],'physical_driver_count':5,
        'full_reference_identity':fe,'reduced_reference_identity':re,'qualified':False,'physical_validation':False,
        'limitations':controls['limitations']+['Corresponding observation/transducer vectors are compared separately for each frequency and even-XY excitation group; mesh-node fields have different coordinates and are not compared directly',
        'The quarter mesh is independently generated from the same CAD; this tests reduction plus discretisation against the retained full reference, not a same-matrix algebraic reduction']}
with (small/'comparison.json').open('x') as stream:stream.write(json.dumps(report,indent=2)+'\n')
print(json.dumps({'fields_passed':report['fields_passed'],'bank_impedance_passed':report['bank_impedance_passed'],
                  'maximum_field_relative_l2':max(r['relative_l2'] for r in rows),'maximum_bank_relative_error':max(b['relative_l2'] for b in banks),
                  'full_electrical_passed':fe['checks']['passed'],'reduced_electrical_passed':re['checks']['passed']},indent=2))
