from pathlib import Path
import json,zipfile,subprocess
from meh_studio.boundary_lab import sha256
root=Path.cwd();target=root/'validation/evidence/acoustic-handover';target.mkdir(parents=True,exist_ok=False)
report=json.loads((root/'runs/acoustic-handover-reanalysis.json').read_text())
reference_commit=subprocess.check_output(['git','rev-parse','codex/larger-target-evidence'],text=True).strip()
reference=json.loads(subprocess.check_output(['git','show',reference_commit+':validation/evidence/larger-wide-mid/report.json'],text=True))
report['raw_native_evidence']={'git_commit':reference_commit,'directory':'validation/evidence/larger-wide-mid',
    'archives':reference['archives'],'relationship':'unchanged original native search; no duplicate solve or relabelled source'}
archive=target/'reanalysis-inputs.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name in ('reanalyse-acoustic-handover.py','archive-acoustic-handover.py'):
        z.write(root/'runs'/name,'runners/'+name)
    for name in ('acoustic-handover-reanalysis.json','larger-acoustic-crossover.json'):
        z.write(root/'runs'/name,name)
    native=root/'runs/larger-wide-mid-32k'
    for name in ('brief.json','base-geometry.json','catalogue-snapshot.json','trial-007/candidate.json','trial-007/score.json'):
        z.write(native/name,'native-controls/'+name)
report['reanalysis_archive']={'file':archive.name,'sha256':sha256(archive),'size_bytes':archive.stat().st_size}
(target/'report.json').write_text(json.dumps(report,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
assert sha256(archive)==report['reanalysis_archive']['sha256']
print(json.dumps({'archive':report['reanalysis_archive'],'native_evidence_commit':reference_commit},indent=2))
