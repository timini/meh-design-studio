"""Apply the new channel constraint to unchanged archived native voltage bases."""
from pathlib import Path
import json
from meh_studio.search_results import load_completed_search
from meh_studio.acoustic_objectives import AcousticObjectives,score_acoustics
from meh_studio.acoustic_handover import acoustic_handover
from meh_studio.boundary_lab import sha256
root=Path.cwd();search=root/'runs/larger-wide-mid-32k'
hashes,result,brief,*_=load_completed_search(search)
trial=search/f'trial-{result["winner_index"]:03d}'
objectives=AcousticObjectives.model_validate(brief.acoustic_objectives.model_dump()|{'acoustic_handover_hz':[3000.,5000.]})
old=json.loads((root/'runs/larger-acoustic-crossover.json').read_text())
assert old['search_control_sha256']==hashes and old['drive_settings']==result['winner']['drive_settings']
rows=old['rows']
old_handover=acoustic_handover([r['frequency_hz'] for r in rows],
    [r['mid_channel_pressure_pa_per_v'] for r in rows],[r['hf_channel_pressure_pa_per_v'] for r in rows],350.,(3000.,5000.))
# Magnitudes suffice for this check; the DSP selection below reads complex bases.
assert not old_handover['passed']
print('Original selected DSP fails the new acoustic handover constraint.',flush=True)
try:
    new_score=score_acoustics(trial/'system/project.blab.json',trial/'evaluation',brief.side_gains,objectives)
    status='completed_reanalysis_with_feasible_dsp';error=None
except ValueError as exc:
    if 'handover window' not in str(exc):raise
    new_score=None;status='completed_reanalysis_no_feasible_dsp';error=str(exc)
report={'status':status,'analysis_application_source_commit':'e1a7a42','native_application_source_commit':'a0a604e',
    'native_runtime':result['runtime'],'unchanged_native_search_control_sha256':hashes,
    'candidate_index':result['winner_index'],'original_score':result['winner'],
    'new_acoustic_objectives':objectives.model_dump(mode='json'),'original_dsp_handover_check':old_handover,
    'constrained_score':new_score,'constraint_error':error,
    'native_search_modified':False,'new_native_solve':False,'physical_validation':False,
    'limitations':['Reanalysis of the same native voltage basis; no new geometry or independent acoustic measurement',
       'Declared on-axis channel dominance window, not an exact or off-axis crossover proof',
       'Reported mid circuits and synthetic HF; strict electrical storage failure remains',
       'No mesh convergence, frequency holdout, random-search benchmark or print qualification']}
# Recheck the already verified controls without repeating all native decoding.
assert all(sha256(search/name)==value for name,value in hashes.items())
path=root/'runs/acoustic-handover-reanalysis.json'
with path.open('x') as out:json.dump(report,out,indent=2);out.write('\n')
print(json.dumps({'status':status,'old_ripple_db':result['winner']['ripple_db'],
    'new_ripple_db':None if new_score is None else new_score['ripple_db'],
    'old_drive':result['winner']['drive_settings'],'new_drive':None if new_score is None else new_score['drive_settings'],
    'old_handover':old_handover,'error':error},indent=2))
