"""Preserve changed-circuit native comparison and distinct derived evidence."""
from pathlib import Path
import json,zipfile
from meh_studio.boundary_lab import sha256
from meh_studio.optimisation import verified_assessment
root=Path.cwd();search=root/'runs/circuit-reanalysis-search';derived=root/'runs/circuit-reanalysis-derived'
validation=json.loads((search/'circuit-validation.json').read_text())
assert validation['status']=='complete'
assert sha256(root/'runs/circuit-reanalysis-controls.json')==validation['controls_sha256']
assert sha256(derived/'derived.json')==validation['derived_report_sha256']
assert verified_assessment(search/'trial-000/system/project.blab.json',search/'trial-000/evaluation')==validation['new_evidence']
dr=json.loads((derived/'derived.json').read_text())
assert sha256(derived/'circuit-basis.npz')==dr['circuit_basis_sha256']
assert all(sha256(derived/r['arrays_file'])==r['arrays_sha256'] for r in dr['rows'])
target=root/'validation/evidence/circuit-reanalysis';target.mkdir(parents=True,exist_ok=False)
groups={};files=[];total=0;part=0
for directory in (search,derived):
    for path in sorted(directory.rglob('*')):
        if not path.is_file():continue
        size=path.stat().st_size;assert size<90_000_000
        if total+size>85_000_000 and files:
            groups[f'native-and-derived-{part:02d}']=files;files=[];total=0;part+=1
        files.append((path,str(path.relative_to(root/'runs'))));total+=size
if files:groups[f'native-and-derived-{part:02d}']=files
names=('run-circuit-reanalysis-reference.py','circuit-reanalysis-controls.json',
    'circuit-reanalysis-prepare.log','circuit-reanalysis-reference.log',
    'finish-circuit-reanalysis-study.py','circuit-reanalysis-final-unit-tests.log')
groups['controls-and-runners']=[(root/'runs'/name,name) for name in names]
archives=[]
for label,files in groups.items():
    path=target/(label+'.zip')
    with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for source,name in files:archive.write(source,name)
    assert path.stat().st_size<100_000_000
    with zipfile.ZipFile(path) as archive:assert archive.testzip() is None
    archives.append({'file':path.name,'sha256':sha256(path),'size_bytes':path.stat().st_size})
report={'status':'completed_native_alternate_circuit_comparison',
    'application_source_commit':validation['application_source_commit'],
    'reference_source_commit':'ab6714f','reference_archive_report':'../periodic-profile-symmetry/report.json',
    'archives':archives,'comparison_passed':validation['comparison_passed'],
    'all_quantity_relative_complex_l2_limit':1e-8,
    'maximum_relative_complex_l2':validation['maximum_relative_complex_l2'],
    'strict_native_electrical_checks_passed':validation['strict_native_electrical_checks_passed'],
    'search_error':validation['search_error'],'qualified':False,'physical_validation':False,
    'limitations':['Same acoustic discretisation, four frequencies, synthetic mids and provisional Peerless ideal outlet model',
        'No target-horn acceptance, mesh convergence, physical source validation, driver fit or print qualification',
        'Conditional unfitted Peerless PWT comparison still fails its declared 3 dB screen']}
(target/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
