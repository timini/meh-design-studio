"""Compare reconstructed fields with an independent changed-circuit native solve."""
from pathlib import Path
import argparse,json
import numpy as np
from meh_studio.boundary_lab import BoundaryLabRuntime,sha256,_contained
from meh_studio.catalogue import Catalogue
from meh_studio.domain import DriverRevision
from meh_studio.geometry import HornGeometry
from meh_studio.optimisation import SearchBrief,candidates,optimise,verified_assessment
from meh_studio.search_results import load_completed_search
from meh_studio.circuit_reanalysis import reanalyse_circuits

root=Path.cwd();prior=root/'runs/periodic-symmetry-search';old_trial=prior/'trial-000'
load_completed_search(prior)
saved_path=old_trial/'candidate.json';saved=json.loads(saved_path.read_text())
base=HornGeometry.model_validate(saved['design'])
replacement_path=root/'examples/reported-drivers/peerless-dfm2535-8-ideal-outlet.json'
replacement=DriverRevision.model_validate_json(replacement_path.read_text())
drivers=[replacement if d['id']=='synthetic-throat' else DriverRevision.model_validate(d) for d in saved['driver_revisions']]
controls=json.loads((prior/'brief.json').read_text());controls.pop('evolution')
controls.update(trial_budget=1,throat_ids=[replacement.id],prices={replacement.id:60.,'synthetic-side':3.},max_driver_cost=100.)
brief=SearchBrief.model_validate(controls);candidate=candidates(brief,base,drivers)[0]
assert candidate['design']==base
parser=argparse.ArgumentParser();parser.add_argument('--source-commit',required=True);parser.add_argument('--prepare',action='store_true');args=parser.parse_args()
provenance={'application_source_commit':args.source_commit,'reference_source_commit':'ab6714f',
    'reference_candidate_sha256':sha256(saved_path),'replacement_driver_file_sha256':sha256(replacement_path),
    'native_backend':'coupled_reference','native_threads':2,
    'predeclared_limits':{'all_quantity_relative_complex_l2':1e-8,'electrical_consistency':1e-8},
    'required_identical_native_inputs':['all compiled mesh hashes by mesh id','frequency grid','excitation ids','quantity ids and shapes'],
    'construction':'Retain small four-synthetic-mid reference geometry, replace synthetic HF with provisional Peerless ideal outlet circuit; independently rebuild and solve the changed native circuit',
    'qualified':False,'physical_validation':False,
    'limitations':['Small four-frequency fixed-geometry comparison; no convergence or target-horn acceptance claim',
        'Synthetic mids and provisional commercial HF; failed conditional PWT source screen remains unresolved',
        'Disabled 2-ohm screen and increased 100 GBP fixture driver allowance; not a target design or price quote',
        'Agreement with the same native discretisation does not establish physical, source or print qualification']}
controls_path=root/'runs/circuit-reanalysis-controls.json'
payload={'brief':brief.model_dump(mode='json'),'base':base.model_dump(mode='json'),
    'drivers':[d.model_dump(mode='json') for d in drivers],'provenance':provenance}
if args.prepare:
    controls_path.write_text(json.dumps(payload,indent=2)+'\n')
    print(json.dumps(provenance,indent=2));raise SystemExit
assert json.loads(controls_path.read_text())==payload
derived=root/'runs/circuit-reanalysis-derived'
report=reanalyse_circuits(old_trial/'system/project.blab.json',old_trial/'evaluation',candidate['sources'],derived)
assert report['status']=='complete'
native=root/'runs/runtime';output=root/'runs/circuit-reanalysis-search';database=root/'runs/circuit-reanalysis-search.sqlite'
with Catalogue.create(database) as catalogue:
    for driver in drivers:catalogue.add(driver)
runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',native/'julia-1.12.6/bin/julia','coupled_reference',julia_threads=2)
search_error=None
try:
    optimise(brief,base,database,runtime,output,solver_stage_timeout_s=1800)
except Exception as exc:
    search_error=f'{type(exc).__name__}: {exc}'
(output/'experiment-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
trial=output/'trial-000';evidence=verified_assessment(trial/'system/project.blab.json',trial/'evaluation')
old_evidence=verified_assessment(old_trial/'system/project.blab.json',old_trial/'evaluation')
assert old_evidence==report['native_evidence']
old_project=json.loads((old_trial/'system/project.blab.json').read_text())['physical_system']
new_project=json.loads((trial/'system/project.blab.json').read_text())['physical_system']
assert old_project['metadata']['generated_mesh_sha256']==new_project['metadata']['generated_mesh_sha256']
meshes=[]
for a,b in zip(old_project['meshes'],new_project['meshes'],strict=True):
    assert a['id']==b['id'] and sha256(old_trial/'system'/a['file'])==sha256(trial/'system'/b['file'])
    meshes.append({'id':a['id'],'sha256':sha256(trial/'system'/b['file'])})
old_raw=old_trial/'evaluation/upstream';new_raw=trial/'evaluation/upstream'
a=json.loads((old_raw/'manifest.json').read_text());b=json.loads((new_raw/'manifest.json').read_text())
assert a['frequencies_hz']==b['frequencies_hz'] and a['excitation_port_ids']==b['excitation_port_ids']
errors=[]
for ar,br,dr in zip(a['results'],b['results'],report['rows'],strict=True):
    assert ar['freq_hz']==br['freq_hz']==dr['frequency_hz']
    am=json.loads(_contained(old_raw,ar['metadata_file']).read_text());bm=json.loads(_contained(new_raw,br['metadata_file']).read_text())
    aq={q['id']:q for q in am['quantities']};bq={q['id']:q for q in bm['quantities']};assert aq.keys()==bq.keys()
    assert sha256(Path(dr['original_metadata_file']))==dr['original_metadata_sha256']
    assert sha256(derived/dr['arrays_file'])==dr['arrays_sha256']
    with np.load(derived/dr['arrays_file'],allow_pickle=False) as da,np.load(_contained(new_raw,br['arrays_file']),allow_pickle=False) as ba:
        for name in aq:
            assert aq[name]['axes']==bq[name]['axes'] and aq[name]['unit']==bq[name]['unit']
            av=da[aq[name]['key']];bv=ba[bq[name]['key']];assert av.shape==bv.shape
            norm=float(np.linalg.norm(bv));error=float(np.linalg.norm(av-bv)/norm) if norm else (0. if not np.any(av) else float('inf'))
            errors.append({'frequency_hz':ar['freq_hz'],'quantity':name,'relative_complex_l2':error})
assert verified_assessment(trial/'system/project.blab.json',trial/'evaluation')==evidence
maximum=max(r['relative_complex_l2'] for r in errors)
validation={'status':'complete','comparison_passed':maximum<=1e-8,
    'controls_sha256':sha256(controls_path),'application_source_commit':args.source_commit,
    'derived_report_sha256':sha256(derived/'derived.json'),'search_error':search_error,
    'reference_evidence':old_evidence,'new_evidence':evidence,
    'identical_meshes':meshes,'quantity_errors':errors,'maximum_relative_complex_l2':maximum,
    'strict_native_electrical_checks_passed':evidence['checks']['passed'],
    'qualified':False,'physical_validation':False}
(output/'circuit-validation.json').write_text(json.dumps(validation,indent=2)+'\n')
print(json.dumps(validation,indent=2))
assert validation['comparison_passed']
