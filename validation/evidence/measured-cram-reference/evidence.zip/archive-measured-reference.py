"""Preserve both attempts and the failed conditional measurement screen."""
from pathlib import Path
import json
import zipfile
import numpy as np
from meh_studio.boundary_lab import sha256
from meh_studio.optimisation import verified_assessment
root=Path.cwd(); runs=root/'runs'; old=runs/'cram-measured-reference'; new=runs/'cram-measured-reference-verified'
a=json.loads((runs/'cram-measured-reference-controls.json').read_text())
b=json.loads((runs/'cram-measured-reference-verified-controls.json').read_text())
assert {k:v for k,v in a.items() if k not in ('application_source_commit','runner_sha256')}=={k:v for k,v in b.items() if k not in ('application_source_commit','runner_sha256')}
original=json.loads((old/'evaluation/evaluation.json').read_text()); fresh=json.loads((new/'evaluation/evaluation.json').read_text())
assert original['status']=='failed' and fresh['status']=='complete'
reinspection=json.loads((runs/'named-volume-native-reinspection.json').read_text())
assert reinspection['original_evaluation_sha256']==sha256(old/'evaluation/evaluation.json')
assert reinspection['verifier_sha256']==sha256(runs/'named-volume-source/src/meh_studio/result_domains.py')
comparison=json.loads((new/'comparison.json').read_text())
assert comparison['source_evidence']==verified_assessment(new/'project/reference.blab.json',new/'evaluation')
assert comparison['controls_sha256']==sha256(runs/'cram-measured-reference-verified-controls.json')
assert comparison['runner_sha256']==sha256(runs/'finish-cram-measured-reference-verified.py')
assert comparison['figure_sha256']==sha256(new/'comparison.png')
for controls,folder,runner in ((a,old,'run-cram-measured-reference.py'),(b,new,'run-cram-measured-reference-verified.py')):
 assert controls['runner_sha256']==sha256(runs/runner)
 for name,digest in controls['original_file_sha256'].items(): assert sha256(folder/'project'/name)==digest
assert (old/'project/reference.blab.json').read_bytes()==(new/'project/reference.blab.json').read_bytes()
oldraw=old/'evaluation/upstream'; newraw=new/'evaluation/upstream'
x=json.loads((oldraw/'manifest.json').read_text()); y=json.loads((newraw/'manifest.json').read_text())
assert x['status']==y['status']=='complete' and all(x['completion_mask']) and all(y['completion_mask'])
assert x['frequencies_hz']==y['frequencies_hz']==b['frequencies_hz']
count=0
for u,v in zip(x['results'],y['results'],strict=True):
 with np.load(oldraw/u['arrays_file'],allow_pickle=False) as aa,np.load(newraw/v['arrays_file'],allow_pickle=False) as bb:
  assert set(aa.files)==set(bb.files)
  for k in aa.files:
   assert aa[k].shape==bb[k].shape and aa[k].dtype==bb[k].dtype and np.array_equal(aa[k],bb[k])
   count+=1
paths=sorted(p for folder in (old,new) for p in folder.rglob('*') if p.is_file())
paths += [runs/name for name in ('run-cram-measured-reference.py','cram-measured-reference-controls.json',
 'cram-measured-reference.log','run-cram-measured-reference-verified.py','cram-measured-reference-verified-controls.json',
 'cram-measured-reference-verified-prepare.log','cram-measured-reference-verified.log',
 'finish-cram-measured-reference-verified.py','cram-measured-reference-verified-comparison.log',
 'named-volume-native-reinspection.json','named-volume-tests.log','named-volume-unit-tests.log',
 'archive-measured-reference.py')]
lic=runs/'runtime/boundary-lab/LICENSE'
inventory={str(p.relative_to(runs)):sha256(p) for p in paths};inventory['upstream/LICENSE']=sha256(lic)
target=root/'validation/evidence/measured-cram-reference';target.mkdir(parents=True,exist_ok=False)
archive_path=target/'evidence.zip'
with zipfile.ZipFile(archive_path,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
 for p in paths:archive.write(p,str(p.relative_to(runs)))
 archive.write(lic,'upstream/LICENSE')
with zipfile.ZipFile(archive_path) as archive:assert archive.testzip() is None
assert inventory=={**{str(p.relative_to(runs)):sha256(p) for p in paths},'upstream/LICENSE':sha256(lic)}
report={'status':'completed_verification_fix_and_failed_conditional_shape_screen',
 'application_source_commit':b['application_source_commit'],'original_failure_source_commit':a['application_source_commit'],
 'upstream_source':'https://github.com/JWSound/boundary-lab/tree/8cb166226e412877d3f71f2845918e479b97aa85/examples/2x12_CRAM',
 'upstream_license':'GPL-3.0, included in evidence.zip/upstream/LICENSE',
 'original_adapter_status':original['status'],'original_adapter_error':original['error'],
 'fresh_adapter_status':fresh['status'],'unchanged_native_arrays':count,
 'native_arrays_exactly_equal':True,'comparison':comparison,
 'archives':[{'file':archive_path.name,'sha256':sha256(archive_path),'size_bytes':archive_path.stat().st_size}],
 'archived_file_sha256':inventory,'qualified':False,'physical_validation':False}
(target/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('comparison','archived_file_sha256')},indent=2))
