"""Exploratory target-band loop: reported mids, explicitly synthetic HF placeholder."""
from pathlib import Path
import json
from meh_studio.boundary_lab import BoundaryLabRuntime
from meh_studio.domain import DriverRevision
from meh_studio.catalogue import Catalogue
from meh_studio.optimisation import SearchBrief,optimise,candidates
from meh_studio.geometry import HornGeometry
root=Path.cwd();source=root/'runs/workload-source';native=root/'runs/runtime'
drivers=[DriverRevision.model_validate_json((source/'examples/reported-drivers/faitalpro-3fe25-16.json').read_text()),DriverRevision.model_validate(json.loads((source/'examples/synthetic-search-drivers.json').read_text())[0])]
base_data=json.loads((source/'examples/freeform-ring-geometry.json').read_text())
base_data.update(length_m=.2,mouth_radius_m=.10,entry_positions_m=[.04],port_radius_m=.012,port_length_m=.006,front_depth_m=.003,rear_depth_m=.06,mesh_size_m=.006,maximum_tetrahedra=3000000,maximum_exterior_triangles=16000)
base=HornGeometry.model_validate(base_data)
brief=SearchBrief.model_validate({'frequencies_hz':[350,700,1200,2000,3000,4000,5000,7500],
 'throat_ids':['synthetic-throat'],'side_ids':['faitalpro-3fe25-16'],
 'prices':{'synthetic-throat':60,'faitalpro-3fe25-16':20},'max_driver_cost':200,
 'max_drivers':5,'lengths_m':[.2],'mouth_radii_m':[.10],'entry_fractions':[[.2]],
 'side_gains':[.1,.2,.4,.8,1.6,3.2], 'trial_budget':4,'seed':2026,'exterior_mesh_size_m':.01,
 'evolution':{'elite_size':1,'explore_every':4,'geometry_bounds':{'length_m':[.18,.22],'entry_fraction_0':[.15,.3],'port_radius_m':[.009,.018],'port_length_m':[.003,.012],'front_depth_m':[.002,.006]}},
 'build_budget':{'maximum_total_cost':300.,'material_density_kg_m3':1270.,'material_cost_per_kg':16.,'process_allowance_factor':1.2,'other_cost_allowance':55.},
 'acoustic_objectives':{'mid_highpass_hz':350,'upper_crossovers_hz':[3000,4000,5000],'horizontal_coverage_deg':90,'vertical_coverage_deg':90,'minimum_bank_impedance_ohm':2}})
# Planning cost allowances only; synthetic HF is not a Celestion model or quote.
rows=candidates(brief,base,drivers)
print('Candidate input contracts passed',flush=True)
with Catalogue.create(root/'runs/wide-mid-target-budget.sqlite') as catalogue:
 for d in drivers:catalogue.add(d)
runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',native/'julia-1.12.6/bin/julia',julia_threads=4)
print(json.dumps(optimise(brief,base,root/'runs/wide-mid-target-budget.sqlite',runtime,root/'runs/wide-mid-target-budget'),indent=2))
