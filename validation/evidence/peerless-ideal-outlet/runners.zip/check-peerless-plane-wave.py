"""Unfitted, conditional outlet-model comparison against manufacturer PWT magnitude.

The 3 dB screen is a diagnostic, not source qualification. The manufacturer's
graph does not specify the tube diameter or publish complex phase. Assume a
25.4 mm matched tube and retain that uncertainty explicitly.
"""
from pathlib import Path
import hashlib
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root = Path.cwd()
record_path = root/'runs/peerless-driver-438.json'
curve_path = root/'runs/peerless-438-pwt-graph.json'
record = json.loads(record_path.read_text())
curve = json.loads(curve_path.read_text())
assert curve['yAxis'][0]['title']['text'] == 'PWT SPL (dB) @ 283mV'
points = np.array(curve['series'][0]['data'])
f, reported_db = points.T
assert np.all(np.diff(f) > 0)
# Diagnostic assumptions/conversions declared before inspecting error statistics.
rho, speed, voltage, outlet_diameter = 1.21, 343., .283, .0254
band, limit_db = (3000., 7500.), 3.
re, le = record['Re'], record['Le']*1e-3
mass, compliance = record['Mmd']*1e-3, record['Cms']*1e-6
area, bl = record['Sd']*1e-4, record['BL']
resistance = 2*np.pi*record['Fs']*record['Mms']*1e-3/record['Qms']
outlet_area = np.pi*(outlet_diameter/2)**2
omega = 2*np.pi*f
ze = re + 1j*omega*le
zm = resistance + 1j*omega*mass + 1/(1j*omega*compliance)
load = rho*speed*area**2/outlet_area
diaphragm_velocity = voltage*bl/(ze*(zm+load)+bl**2)
outlet_pressure = rho*speed*area/outlet_area*diaphragm_velocity
predicted_db = 20*np.log10(abs(outlet_pressure)/20e-6)
mask = (f>=band[0]) & (f<=band[1])
errors = predicted_db-reported_db
maximum = float(abs(errors[mask]).max())
report = {
    'status': 'conditional_unfitted_magnitude_comparison',
    'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'inputs': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (record_path,curve_path)},
    'source_urls': ['https://products.peerless-audio.com/api/driver/438',
        'https://products.peerless-audio.com/api/graphs/driver/438?chart=SPL_PWT'],
    'assumptions': {'rho_kg_m3':rho, 'sound_speed_m_s':speed,
        'voltage_rms_v':voltage, 'matched_tube_diameter_m':outlet_diameter,
        'tube_diameter_confirmed':False, 'API_mass_unit_assumed':'g',
        'API_compliance_unit_assumed':'micrometre/N', 'API_area_unit_assumed':'cm^2',
        'ideal_lossless_zero_length_area_transformer':True},
    'circuit_si': {'re_ohm':re, 'le_h':le, 'mmd_kg':mass, 'cms_m_n':compliance,
        'rms_ns_m':resistance, 'bl_n_a':bl, 'sd_m2':area},
    'screen_band_hz':list(band), 'screen_limit_absolute_error_db':limit_db,
    'screen_sample_count':int(mask.sum()), 'maximum_absolute_error_db':maximum,
    'rms_error_db':float(np.sqrt(np.mean(errors[mask]**2))),
    'mean_signed_error_db':float(errors[mask].mean()),
    'conditional_screen_passed':maximum<=limit_db,
    'fitted_parameters':[], 'gain_normalisation_db':0.,
    'physical_qualification':False, 'phase_validated':False,
    'limitations':['Unknown exact tube geometry, termination, calibration and measurement uncertainty',
        'Assumed API unit conversions; no independently measured dry-mass circuit',
        'No phase-plug/cavity propagation, losses, diaphragm breakup or thermal/nonlinear behaviour',
        'A magnitude-only screen cannot validate source phase or arbitrary-horn load dependence',
        'No source import or replacement in existing native experiments'],
}
(root/'runs/peerless-plane-wave-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
fig, axes = plt.subplots(2,1,figsize=(9,6),sharex=True,layout='constrained')
axes[0].semilogx(f,reported_db,label='Manufacturer PWT, 283 mV')
axes[0].semilogx(f,predicted_db,label='Unfitted circuit + ideal area transformer')
axes[0].set(ylabel='Pressure level (dB re 20 µPa)',ylim=(90,135))
axes[0].legend(fontsize=8)
axes[1].semilogx(f,errors)
axes[1].axhspan(-limit_db,limit_db,color='green',alpha=.12)
axes[1].set(xlabel='Frequency (Hz)',ylabel='Prediction − reported (dB)',xlim=(500,15000),ylim=(-15,15))
for ax in axes:
    ax.axvspan(*band,color='blue',alpha=.05)
    ax.grid(alpha=.2)
fig.suptitle('Peerless DFM-2535R00-08: conditional matched-tube magnitude check\n25.4 mm tube assumed; no fitting, phase validation or source qualification',fontsize=10)
fig.savefig(root/'runs/peerless-plane-wave-comparison.png',dpi=150)
print(json.dumps(report,indent=2))
