"""Create a provisional physical source record without promoting source qualification."""
from pathlib import Path
import hashlib,json,math
from meh_studio.domain import DriverRevision
from meh_studio.catalogue import Catalogue
from meh_studio.geometry import HornGeometry
from meh_studio.optimisation import SearchBrief,candidates
root=Path.cwd();raw_path=root/'runs/peerless-driver-438-recheck.json';r=json.loads(raw_path.read_text())
assert (r['MarketingNo'],r['DesignRev'],r['DBRev'])==('DFM-2535R00-08',1,'5.000')
comparison_path=root/'runs/peerless-plane-wave-comparison.json';comparison=json.loads(comparison_path.read_text())
assert not comparison['conditional_screen_passed'] and comparison['screen_limit_absolute_error_db']==3.
api='https://products.peerless-audio.com/api/driver/438';pdf='https://products.peerless-audio.com/pdf/438'
source={'re_ohm':r['Re'],'le_h':r['Le']*1e-3,'bl_n_a':r['BL'],'mmd_kg':r['Mmd']*1e-3,
    'cms_m_n':r['Cms']*1e-6,'rms_ns_m':2*math.pi*r['Fs']*r['Mms']*1e-3/r['Qms'],
    'sd_m2':r['Sd']*1e-4,'ideal_outlet_area_m2':math.pi*(.0254/2)**2,
    'provenance':{'kind':'derived','permission':'unknown','source':
        f'{api}; retrieved 2026-09-11, DesignRev 1 / MP, DBRev 5.000 updated 2026-05-06. '
        'Provisional SI interpretation: Mmd/Mms in g, Le in mH, Cms in micrometre/N, Sd in cm^2; '
        'API fields lack individual unit labels. Same-catalogue units and Fs/Qes consistency support these conversions, not manufacturer confirmation for this circuit. '
        'Rms derived as 2*pi*Fs*Mms/Qms; dry mass uses Mmd, not Mms. '
        f'25.4 mm outlet from {pdf}, June 2026. Ideal lossless zero-length area transformer; no internal cavity, rear-load or phase-plug model. '
        'Conditional unfitted 3-7.5 kHz PWT magnitude comparison fails 3 dB screen (maximum 4.33329 dB); no phase, load-dependent or physical qualification.'}}
record=DriverRevision.model_validate({'id':'peerless-dfm2535-8-ideal-outlet','revision':1,
    'manufacturer':'Peerless by Tymphany','model':'DFM-2535R00-08 (provisional ideal outlet approximation)',
    'outer_diameter_m':.09,'cutout_diameter_m':.0254,'depth_m':.0508,
    'provenance':{'kind':'derived','permission':'unknown','source':
        f'{pdf}, June 2026 drawing: 90 mm body, 50.8 mm depth and 25.4 mm nominal outlet opening. '
        'Cutout field denotes the nominal horn opening, not a qualified mounting clearance, gasket or bolt interface. '
        'Source is an unqualified derived approximation; see its separate circuit provenance.'},
    'source_model':source,'qualification':None})
for k in ('re_ohm','le_h','bl_n_a','mmd_kg','cms_m_n','rms_ns_m','sd_m2'):
    assert record.source_model.model_dump()[k]==comparison['circuit_si'][k]
target=root/'examples/reported-drivers/peerless-dfm2535-8-ideal-outlet.json'
target.write_text(json.dumps(record.model_dump(mode='json'),indent=2)+'\n')
db=root/'runs/provisional-commercial-hf.sqlite'
with Catalogue.create(db) as catalogue:catalogue.add(record)
# Exercise the actual catalogue-record/candidate path; no old native basis is reused.
controls=json.loads((root/'runs/quarter-turn-vocal-controls.json').read_text())
brief=controls['brief'];brief['throat_ids']=[record.id];brief['prices'][record.id]=60.
side=DriverRevision.model_validate_json((root/'examples/reported-drivers/faitalpro-4fe32-16.json').read_text())
base=HornGeometry.model_validate(controls['base']);proposal=candidates(SearchBrief.model_validate(brief),base,[record,side])[0]
assert proposal['design'].throat_radius_m==.0127
assert proposal['sources'].throat==record.source_model and record.qualification is None
report={'status':'provisional_record_imported_not_qualified','runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'record_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'api_recheck_sha256':hashlib.sha256(raw_path.read_bytes()).hexdigest(),
    'conditional_comparison_sha256':hashlib.sha256(comparison_path.read_bytes()).hexdigest(),
    'reported_fs_hz':r['Fs'],'calculated_fs_using_reported_mms_hz':1/(2*math.pi*math.sqrt(r['Mms']*1e-3*source['cms_m_n'])),
    'reported_qes':r['Qes'],'calculated_qes':2*math.pi*r['Fs']*r['Mms']*1e-3*r['Re']/r['BL']**2,
    'record_content_hash':record.content_hash,'outlet_velocity_ratio':record.source_model.outlet_velocity_ratio,
    'outlet_circuit':record.source_model.outlet_piston_parameters(),'candidate_geometry_hash':proposal['design'].content_hash,
    'candidate_driver_allowance_gbp':proposal['cost'],'price_basis':'Inherited exploratory £60 HF allowance, not a supplier quote',
    'native_solve_performed':False,'qualified':False,'physical_validation':False}
(root/'runs/peerless-ideal-outlet-import.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
