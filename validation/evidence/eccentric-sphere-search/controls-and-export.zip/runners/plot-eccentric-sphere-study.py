"""Display native whole-sphere samples, without interpolating unobserved angles."""
from pathlib import Path
import json,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from meh_studio.search_results import load_completed_search
from meh_studio.boundary_lab import _contained
from meh_studio.acoustic_objectives import drive_weights
root=Path.cwd();source=root/'runs/eccentric-sphere-search-v3'
hashes,result,brief,base,winner,gain=load_completed_search(source)
trial=source/f'trial-{result["winner_index"]:03d}';raw=trial/'evaluation/upstream'
man=json.loads((raw/'manifest.json').read_text());project=json.loads((trial/'system/project.blab.json').read_text())
ports={p['id']:p['component_id'] for p in project['physical_system']['excitation_ports']}
ids=[ports[p] for p in man['excitation_port_ids']]
weights=drive_weights([r['freq_hz'] for r in man['results']],ids,result['winner']['drive_settings'])
domains=json.loads(_contained(raw,man['domains_metadata_file']).read_text())['domains']
sphere=next(d for d in domains if d['id']=='observation:sphere');horizontal=next(d for d in domains if d['id']=='observation:horizontal-polar')
with np.load(_contained(raw,man['domains_file'])) as data:
 points=data[sphere['coordinates']['points_m']].copy();axis=int(np.flatnonzero(data[horizontal['coordinates']['angle_deg']]==0)[0])
longitude=np.arctan2(points[:,0],points[:,2]);latitude=np.arcsin(points[:,1]/np.linalg.norm(points,axis=1))
fig=plt.figure(figsize=(12,4.5),layout='constrained');axes=[]
for col,f in enumerate((1000.,2000.,3000.)):
 index=next(i for i,r in enumerate(man['results']) if r['freq_hz']==f);row=man['results'][index]
 meta=json.loads(_contained(raw,row['metadata_file']).read_text());q={q['id']:q for q in meta['quantities']}
 with np.load(_contained(raw,row['arrays_file'])) as data:
  pressure=weights[index]@data[q['acoustic:pressure:sphere']['key']]
  on_axis=weights[index]@data[q['acoustic:pressure:horizontal-polar']['key']][:,axis]
 values=20*np.log10(np.maximum(abs(pressure)/abs(on_axis),1e-6))
 ax=fig.add_subplot(1,3,col+1,projection='mollweide');axes.append(ax)
 im=ax.scatter(longitude,latitude,c=values,cmap='viridis',vmin=-30,vmax=6,s=18)
 ax.grid(alpha=.3);ax.set_title(f'{f:g} Hz');ax.tick_params(labelsize=7)
fig.colorbar(im,ax=axes,label='dB relative to on axis',shrink=.5,pad=.02)
fig.suptitle(f'Native sphere samples from selected synthetic eccentric-port candidate {result["winner_index"]}\n413 directions at 1 m; forward = centre; fixed selected DSP; no physical or angular-convergence qualification',fontsize=11)
fig.savefig(root/'docs/assets/eccentric-sphere-samples.png',dpi=150)
assert load_completed_search(source)[0]==hashes
