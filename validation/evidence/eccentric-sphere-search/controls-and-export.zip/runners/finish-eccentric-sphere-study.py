"""Verify/export/archive the completed native eccentric-port integration study."""
from pathlib import Path
import json,zipfile
from meh_studio.search_results import load_completed_search
from meh_studio.build_bundle import export_search
from meh_studio.operating import search_operating_report
from meh_studio.boundary_lab import sha256
root=Path.cwd();source=root/'runs/eccentric-sphere-search-v3';target=root/'validation/evidence/eccentric-sphere-search'
hashes,search,brief,base,winner,gain=load_completed_search(source)
export_path=root/'runs/eccentric-sphere-winner.zip'
export_report=export_search(source,export_path)
operating=search_operating_report(source,1.)
target.mkdir(parents=True,exist_ok=False)
archives=[]
def archive(name,folder,prefix=''):
 path=target/name
 with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in sorted(folder.rglob('*')):
   if p.is_file():z.write(p,str(Path(prefix)/p.relative_to(folder)))
 archives.append({'file':path.name,'sha256':sha256(path),'size_bytes':path.stat().st_size})
for t in search['trials']:
 archive(f'trial-{t["index"]:03d}.zip',source/f'trial-{t["index"]:03d}',f'trial-{t["index"]:03d}')
# Preserve the material failed native preflight, including its binary mesh.
archive('binary-preflight-failure.zip',root/'runs/eccentric-sphere-search-v2')
path=target/'controls-and-export.zip'
with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in source.iterdir():
  if p.is_file():z.write(p,p.name)
 for name in ('run-eccentric-sphere-search.py','run-eccentric-sphere-search-v2.py',
              'run-eccentric-sphere-search-v1.py','run-eccentric-sphere-search-rejected-inputs.py',
              'finish-eccentric-sphere-study.py','plot-eccentric-sphere-study.py'):
  z.write(root/'runs'/name,'runners/'+name)
 z.write(export_path,'exports/'+export_path.name)
 for p in (root/'runs/eccentric-sphere-search').iterdir():
  if p.is_file():z.write(p,'initial-profile-bound-failure/'+p.name)
 z.write(root/'runs/eccentric-sphere-rejected-inputs.log','initial-radius-clearance-failure.log')
archives.append({'file':path.name,'sha256':sha256(path),'size_bytes':path.stat().st_size})
report={'application_source_commit':'1187c25','source_state':'clean detached eccentric-text-source',
 'status':'native_integration_study_complete','search':search,'archives':archives,
 'export_verification':export_report,'native_sphere_samples_per_frequency':413,
 'all_commercial_sources':False,'physical_validation':False,'mesh_convergence':False,
 'limitations':['Synthetic drivers and a deliberately small horn; not the commercial 350 Hz design',
 'Two proposals and four frequencies do not demonstrate a global optimum or full-band performance',
 'The impedance screen was explicitly disabled for this synthetic diagnostic; no 2-ohm amplifier compatibility claim',
 'Whole-sphere pressure sampling is not qualified radiated power or angular quadrature convergence',
 'Strict electrical failures are retained; no acceptance limits relaxed',
 'Modelled cavity clearances do not qualify real baskets, flanges, cones or mounting hardware']}
(target/'operating-1vrms.json').write_text(json.dumps(operating,indent=2)+'\n')
(target/'report.json').write_text(json.dumps(report,indent=2)+'\n')
assert load_completed_search(source)[0]==hashes
print(json.dumps({'winner_index':search['winner_index'],'export':export_report,'archives':archives},indent=2))
