"""Two-proposal synthetic integration study; not the 350 Hz commercial design."""
from pathlib import Path
import json
from meh_studio.boundary_lab import BoundaryLabRuntime
from meh_studio.optimisation import SearchBrief,optimise,candidates
from meh_studio.geometry import HornGeometry
from meh_studio.domain import DriverRevision
from meh_studio.catalogue import Catalogue
root=Path.cwd();source=root/'runs/eccentric-source';native=root/'runs/runtime'
base=HornGeometry.model_validate_json((source/'examples/eccentric-ring-geometry.json').read_text())
drivers=[DriverRevision.model_validate(x) for x in json.loads((source/'examples/synthetic-search-drivers.json').read_text())]
brief=SearchBrief.model_validate({'frequencies_hz':[350.,1000.,2000.,3000.],
 'throat_ids':['synthetic-throat'],'side_ids':['synthetic-side'],
 'prices':{'synthetic-throat':8.,'synthetic-side':3.},'max_driver_cost':25.,'max_drivers':5,
 'lengths_m':[base.length_m],'mouth_radii_m':[base.mouth_radius_m],'entry_fractions':[[.16]],
 'side_gains':[.2,.4,.8,1.6],'trial_budget':2,'seed':20260911,'exterior_mesh_size_m':.01,
 'evolution':{'elite_size':1,'explore_every':4,'mutation_fraction':1.,'sigma_fraction':.1,
 'profile_scale_bounds':[.85,1.15],'geometry_bounds':{'driver_axial_offset_m':[.008,.012]}},
 'acoustic_objectives':{'mid_highpass_hz':350.,'upper_crossovers_hz':[2000.],
 'mid_polarities':[1,-1],'hf_delays_s':[0.,.0003],'minimum_bank_impedance_ohm':None,
 'sphere':{'angle_precision_deg':10.,'control_from_hz':1000.,'rear_attenuation_db':30.}}})
# Explicitly diagnostic synthetic circuits: the disabled 2-ohm screen is recorded
# in the frozen brief, not interpreted as acceptance under the user's load target.
candidates(brief,base,drivers)
with Catalogue.create(root/'runs/eccentric-sphere-search.sqlite') as catalogue:
 for driver in drivers:catalogue.add(driver)
runtime=BoundaryLabRuntime(native/'boundary-lab',native/'blab-env/bin/python',native/'julia-1.12.6/bin/julia',julia_threads=1)
print(json.dumps(optimise(brief,base,root/'runs/eccentric-sphere-search.sqlite',runtime,
 root/'runs/eccentric-sphere-search',solver_stage_timeout_s=1800),indent=2))
