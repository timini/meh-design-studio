"""Compare independently meshed full and reduced models without field fitting."""
from pathlib import Path
import json
import numpy as np
from meh_studio.boundary_lab import sha256, _contained
from meh_studio.optimisation import verified_assessment

root = Path.cwd(); runs = root / 'runs'; study = runs / 'mirror-quarter-finer'
cp = runs / 'mirror-quarter-finer-controls.json'; controls = json.loads(cp.read_text())
terminal = json.loads((study / 'report.json').read_text())
assert terminal['status'] == 'complete' and terminal['controls_sha256'] == sha256(cp)
groups = {'component:throat': ['component:throat'],
          'component:entry_0_positive': ['component:entry_0_positive', 'component:entry_0_negative'],
          'component:entry_0_positive_y': ['component:entry_0_positive_y', 'component:entry_0_negative_y']}
paths = {
    'full': (runs / 'tilted-entry-10mm/trial-000/system/project.blab.json', runs / 'tilted-entry-10mm/trial-000/evaluation'),
    '4mm': (runs / 'mirror-quarter-refinement-4mm-mesh/project.blab.json', runs / 'mirror-quarter-fine/4mm')}
paths.update({row['level']['name']: (runs / ('mirror-quarter-refinement-' + row['level']['name'] + '-mesh/project.blab.json'),
                                   study / row['level']['name']) for row in terminal['rows']})
expected = {'full': controls['full_reference'], '4mm': controls['coarse_reference']}
expected.update({row['level']['name']: row['evidence'] for row in terminal['rows']})
data = {}
for name, (project, evaluation) in paths.items():
    evidence = verified_assessment(project, evaluation); assert evidence == expected[name]
    raw = evaluation / 'upstream'; manifest = json.loads((raw / 'manifest.json').read_text())
    p = json.loads(project.read_text()); ports = {v['id']: v['component_id'] for v in p['physical_system']['excitation_ports']}
    order = [ports[port] for port in manifest['excitation_port_ids']]
    assert manifest['frequencies_hz'] == controls['request']['frequencies_hz']
    coordinates = {}
    domains = json.loads(_contained(raw, manifest['domains_metadata_file']).read_text())['domains']
    with np.load(_contained(raw, manifest['domains_file']), allow_pickle=False) as archive:
        for domain in domains:
            if domain['id'].startswith('observation:'):
                for key, value in domain['coordinates'].items():
                    coordinates[(domain['id'], key)] = archive[value].copy()
    rows = []
    for entry in manifest['results']:
        metadata = json.loads(_contained(raw, entry['metadata_file']).read_text())
        assert metadata['diagnostics']['transducer_reference_voltage_v'] == 2.83
        quantities = {}
        with np.load(_contained(raw, entry['arrays_file']), allow_pickle=False) as archive:
            for q in metadata['quantities']:
                if q['axes'] in (['excitation', 'observation'], ['excitation', 'transducer']):
                    array = archive[q['key']].copy(); assert array.dtype == np.complex128
                    quantities[q['id']] = (q, array)
        rows.append({'frequency_hz': entry['freq_hz'], 'quantities': quantities})
    counts = {component: 1 for component in order} if name == 'full' else {
        component: detail['physical_driver_orbit_count']
        for component, detail in evidence['checks']['symmetry']['components'].items()}
    assert counts == ({component: 1 for component in order} if name == 'full' else {k: len(v) for k, v in groups.items()})
    data[name] = {'rows': rows, 'order': order, 'coordinates': coordinates, 'counts': counts}

def relative(reference, value, limit):
    difference = float(np.linalg.norm(value - reference)); norm = float(np.linalg.norm(reference))
    error = difference / norm if norm else (0. if difference == 0. else None)
    return {'reference_norm': norm, 'difference_norm': difference, 'relative_l2': error,
            'limit': limit, 'passed': error is not None and error <= limit}

comparisons = []
for reference_name, value_name in [('full', '4mm'), ('full', '3mm'), ('3mm', '4mm')]:
    reference, value = data[reference_name], data[value_name]
    assert reference['coordinates'].keys() == value['coordinates'].keys()
    assert all(np.array_equal(v, value['coordinates'][k]) for k, v in reference['coordinates'].items())
    rows, banks = [], []
    for fr, vr in zip(reference['rows'], value['rows'], strict=True):
        assert fr['frequency_hz'] == vr['frequency_hz']
        assert fr['quantities'].keys() == vr['quantities'].keys()
        for name, (fq, fa) in fr['quantities'].items():
            vq, va = vr['quantities'][name]; assert fq['axes'] == vq['axes'] and fq['unit'] == vq['unit']
            for group, physical in groups.items():
                excitation = physical if reference_name == 'full' else [group]
                rf = fa[[reference['order'].index(k) for k in excitation]].sum(axis=0)
                vf = va[value['order'].index(group)]
                if fq['axes'] == ['excitation', 'transducer']:
                    fids, vids = fq['metadata']['component_ids'], vq['metadata']['component_ids']
                    lookup = {k: g for g, members in groups.items() for k in members}
                    target = [lookup[k] for k in fids] if reference_name == 'full' else fids
                    vf = vf[[vids.index(k) for k in target]]
                rows.append({'frequency_hz': fr['frequency_hz'], 'quantity': name,
                             'excitation_group': group, **relative(rf, vf, controls['field_relative_l2_limit'])})
        impedances = []
        for case, row in [(reference, fr), (value, vr)]:
            q, array = row['quantities']['electrical:voice-coil-current']
            induced = array[[i for i, component in enumerate(case['order']) if component != 'component:throat']].sum(axis=0)
            current = sum(induced[i] * case['counts'][component]
                          for i, component in enumerate(q['metadata']['component_ids']) if component != 'component:throat')
            assert abs(current) > 0
            impedances.append(2.83 / current)
        banks.append({'frequency_hz': fr['frequency_hz'],
                      'reference_impedance_ohm': [float(impedances[0].real), float(impedances[0].imag)],
                      'value_impedance_ohm': [float(impedances[1].real), float(impedances[1].imag)],
                      **relative(np.array([impedances[0]]), np.array([impedances[1]]), controls['bank_impedance_relative_limit'])})
    comparisons.append({'reference': reference_name, 'value': value_name, 'rows': rows, 'parallel_mid_bank': banks,
                        'fields_passed': all(r['passed'] for r in rows), 'bank_impedance_passed': all(r['passed'] for r in banks)})
for name, (project, evaluation) in paths.items():
    assert verified_assessment(project, evaluation) == expected[name]
report = {'status': 'complete_comparison', 'source_commit': controls['source_commit'],
          'controls_sha256': sha256(cp), 'runner_sha256': sha256(Path(__file__)),
          'evidence': expected, 'comparisons': comparisons, 'qualified': False,
          'physical_validation': False, 'limitations': controls['limitations']}
with (study / 'comparison.json').open('x') as stream: stream.write(json.dumps(report, indent=2) + '\n')
print(json.dumps([{'reference': c['reference'], 'value': c['value'], 'fields_passed': c['fields_passed'],
                   'maximum_field_relative_l2': max(r['relative_l2'] for r in c['rows']),
                   'bank_impedance_passed': c['bank_impedance_passed'],
                   'maximum_bank_relative_error': max(r['relative_l2'] for r in c['parallel_mid_bank'])}
                  for c in comparisons], indent=2))
