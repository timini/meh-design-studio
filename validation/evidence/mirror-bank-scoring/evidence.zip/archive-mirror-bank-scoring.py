"""Preserve physical-bank scoring checks and the additional 3 mm native solve."""
from pathlib import Path
import json
import zipfile
from meh_studio.boundary_lab import sha256
from meh_studio.optimisation import verified_assessment

root = Path.cwd(); runs = root / 'runs'
check = json.loads((runs / 'mirror-bank-scoring-native-check.json').read_text())
for name, digest in check['postprocessor_source_sha256'].items(): assert sha256(root / name) == digest
assert check['runner_sha256'] == sha256(runs / 'check-mirror-bank-scoring.py')
gate = json.loads((runs / 'mirror-bank-native-2ohm-gate.json').read_text())
assert gate['status'] == 'correctly_rejected'
assert gate['runner_sha256'] == sha256(runs / 'check-mirror-native-2ohm-gate.py')
assert gate['source_report_sha256'] == sha256(runs / 'mirror-bank-scoring-native-check.json')
study = runs / 'mirror-quarter-finer'; mesh = runs / 'mirror-quarter-refinement-3mm-mesh'
cp = runs / 'mirror-quarter-finer-controls.json'; controls = json.loads(cp.read_text())
native = json.loads((study / 'report.json').read_text()); comparison = json.loads((study / 'comparison.json').read_text())
assert native['status'] == 'complete' and native['controls_sha256'] == comparison['controls_sha256'] == sha256(cp)
assert controls['runner_sha256'] == sha256(runs / 'run-mirror-quarter-finer.py')
assert controls['mesher_sha256'] == sha256(runs / 'mesh-mirror-quarter-finer.py')
assert comparison['runner_sha256'] == sha256(runs / 'compare-mirror-quarter-finer.py')
row = native['rows'][0]
assert verified_assessment(mesh / 'project.blab.json', study / '3mm') == row['evidence'] == check['native_evidence']
assert all(sha256(mesh / name) == digest for name, digest in row['inputs_sha256'].items())
paths = {p for folder in (study, mesh) for p in folder.rglob('*') if p.is_file()}
for pattern in ['*mirror-quarter-finer*', 'check-mirror-bank-scoring.py', 'check-mirror-native-2ohm-gate.py',
                'mirror-bank-scoring-native-check.*', 'mirror-bank-native-2ohm-gate.*', 'mirror-bank-scoring-noncad.log']:
    paths.update(p for p in runs.glob(pattern) if p.is_file())
paths.add(Path(__file__).resolve())
files = {str(p.relative_to(runs)): p for p in sorted(paths)}
files.update({'postprocessor-source/' + name: root / name for name in check['postprocessor_source_sha256']})
for name in ['test_acoustic_objectives.py', 'test_acoustic_handover.py', 'test_spherical_metrics.py',
             'test_operating.py', 'test_electrical_validation.py']:
    files['postprocessor-source/tests/' + name] = root / 'tests' / name
inventory = {name: sha256(path) for name, path in files.items()}
target = root / 'validation/evidence/mirror-bank-scoring'; target.mkdir(parents=True, exist_ok=False)
path = target / 'evidence.zip'
with zipfile.ZipFile(path, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, file in files.items(): archive.write(file, name)
with zipfile.ZipFile(path) as archive: assert archive.testzip() is None
assert inventory == {name: sha256(file) for name, file in files.items()}
assert path.stat().st_size < 100_000_000
report = {'status': 'complete_mirror_bank_scoring_verification', 'native_controls_sha256': sha256(cp),
          'native': native, 'comparison': comparison, 'scoring': check, 'two_ohm_gate': gate,
          'archives': [{'file': path.name, 'size_bytes': path.stat().st_size, 'sha256': sha256(path)}],
          'archived_file_sha256': inventory, 'previous_refinement_archive': '../mirror-quarter-refinement/report.json',
          'qualified': False, 'physical_validation': False}
(target / 'report.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({'archives': report['archives'], 'archived_files': len(files)}, indent=2))
