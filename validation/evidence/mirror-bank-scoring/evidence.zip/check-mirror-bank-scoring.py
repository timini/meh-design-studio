"""Check real native bank scoring against independently summed coil currents."""
from pathlib import Path
import json
import subprocess
import numpy as np
from meh_studio.boundary_lab import sha256, _contained
from meh_studio.acoustic_objectives import AcousticObjectives, score_acoustics, drive_weights
from meh_studio.operating import operating_quantities
from meh_studio.optimisation import verified_assessment

root = Path.cwd(); runs = root / 'runs'
source = {str(p.relative_to(root)): sha256(p) for p in sorted((root / 'src').rglob('*.py'))}
brief = json.loads((runs / 'tilted-entry-10mm-controls.json').read_text())['brief']
targets = AcousticObjectives.model_validate(brief['acoustic_objectives'])
unreduced = []
for name in ['trial-000', 'trial-001']:
    trial = runs / 'tilted-entry-10mm' / name
    score = score_acoustics(trial / 'system/project.blab.json', trial / 'evaluation', brief['side_gains'], targets)
    saved = json.loads((trial / 'score.json').read_text())
    assert all(score[key] == saved[key] for key in score)
    unreduced.append({'trial': name, 'all_original_score_fields_identical': True, 'score': score})
project = runs / 'mirror-quarter-refinement-3mm-mesh/project.blab.json'
evaluation = runs / 'mirror-quarter-finer/3mm'
identity = verified_assessment(project, evaluation)
score = score_acoustics(project, evaluation, brief['side_gains'], targets)
assert score['parallel_mid_bank']['mid_count'] == 4
comparison = json.loads((runs / 'mirror-quarter-finer/comparison.json').read_text())
ref = next(c for c in comparison['comparisons'] if c['reference'] == 'full' and c['value'] == '3mm')
impedances = np.array([complex(*r['value_impedance_ohm']) for r in ref['parallel_mid_bank']])
bank = score['parallel_mid_bank']
np.testing.assert_allclose(np.array(bank['impedance_real_ohm']) + 1j*np.array(bank['impedance_imag_ohm']), impedances, rtol=1e-13)
raw = evaluation / 'upstream'; manifest = json.loads((raw / 'manifest.json').read_text())
p = json.loads(project.read_text()); system = p['physical_system']
ports = {v['id']: v['component_id'] for v in system['excitation_ports']}
ids = tuple(ports[v] for v in manifest['excitation_port_ids'])
counts = np.array([identity['checks']['symmetry']['components'][c]['physical_driver_orbit_count'] for c in ids])
assert sorted(counts) == [1, 2, 2]
current = []; velocity = []; pressure = []
for row in manifest['results']:
    metadata = json.loads(_contained(raw, row['metadata_file']).read_text())
    quantities = {q['id']: q for q in metadata['quantities']}
    with np.load(_contained(raw, row['arrays_file']), allow_pickle=False) as archive:
        for name, destination in [('electrical:voice-coil-current', current), ('mechanical:diaphragm-velocity', velocity)]:
            q = quantities[name]; order = q['metadata']['component_ids']
            destination.append(archive[q['key']][:, [order.index(c) for c in ids]].copy())
        pressure.append(archive[quantities['acoustic:pressure:horizontal-polar']['key']].copy())
frequencies = manifest['frequencies_hz']; weights = drive_weights(frequencies, list(ids), score['drive_settings'])
coil_currents = np.array([sum(weight*column for weight, column in zip(w, matrix, strict=True))
                          for w, matrix in zip(weights, current, strict=True)])
mids = [i for i, c in enumerate(ids) if c != 'component:throat']; hf = ids.index('component:throat')
group_currents = coil_currents*counts
selected = bank['selected_drive_currents']
for key, expected in [('mid_bank', group_currents[:, mids].sum(axis=1)), ('hf', group_currents[:, hf])]:
    actual = np.array(selected[key + '_real_a']) + 1j*np.array(selected[key + '_imag_a'])
    np.testing.assert_allclose(actual, expected, rtol=1e-13, atol=1e-15)
resistance = [{c['id']: c for c in system['components']}[name]['parameters']['re_ohm'] for name in ids]
operating = operating_quantities(frequencies, ids, 2.*weights, np.asarray(pressure)/2.83,
    np.asarray(current)/2.83, np.asarray(velocity)/2.83, resistance, physical_driver_orbit_counts=counts)
physical_power = np.real((2.*weights)*np.conj(coil_currents*2./2.83)*counts).sum(axis=1)
np.testing.assert_allclose(operating['total_power'], physical_power, rtol=1e-13)
assert verified_assessment(project, evaluation) == identity
assert source == {str(p.relative_to(root)): sha256(p) for p in sorted((root / 'src').rglob('*.py'))}
report = {'status': 'complete_native_scoring_reanalysis',
    'native_source_commit': '25e69a8575077df2c533ccab6db13ee4a823cc53',
    'unreduced_native_source_commit': '9fdafd6a57e4f83ef24562a471ddb059dcc0b686',
    'postprocessor_parent_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'postprocessor_source_sha256': source, 'runner_sha256': sha256(Path(__file__)),
    'native_evidence': identity, 'unreduced_regression': unreduced, 'quarter_score': score,
    'independent_comparison_sha256': sha256(runs / 'mirror-quarter-finer/comparison.json'),
    'impedance_and_selected_current_match_independent_sums': True,
    'two_v_rms_net_real_power_w': physical_power.tolist(), 'operating_power_matches_all_physical_coils': True,
    'relative_comparison_tolerance': 1e-13, 'qualified': False, 'physical_validation': False,
    'limitations': ['Reanalysis of existing native fields, not a new acoustic simulation',
                   'Four diagnostic frequencies and synthetic sources; original acoustic validation limits remain',
                   'Production generated geometry still uses the full model; circuit-replacement reanalysis still rejects reduced driver orbits']}
with (runs / 'mirror-bank-scoring-native-check.json').open('x') as stream: stream.write(json.dumps(report, indent=2)+'\n')
print(json.dumps({'mid_count': bank['mid_count'], 'minimum_bank_impedance_ohm': bank['minimum_impedance_magnitude_ohm'],
                  'unreduced_scores_identical': len(unreduced), 'all_independent_accounting_checks_passed': True}, indent=2))
