"""Exercise the actual scoring rejection path on the retained quarter basis."""
from pathlib import Path
import json
from meh_studio.boundary_lab import sha256
from meh_studio.acoustic_objectives import AcousticObjectives, score_acoustics

root = Path.cwd(); runs = root / 'runs'
source_report = runs / 'mirror-bank-scoring-native-check.json'
saved = json.loads(source_report.read_text())
for name, digest in saved['postprocessor_source_sha256'].items(): assert sha256(root / name) == digest
brief = json.loads((runs / 'tilted-entry-10mm-controls.json').read_text())['brief']
targets = AcousticObjectives.model_validate(brief['acoustic_objectives'] | {'minimum_bank_impedance_ohm': 2.})
try:
    score_acoustics(runs / 'mirror-quarter-refinement-3mm-mesh/project.blab.json',
                   runs / 'mirror-quarter-finer/3mm', brief['side_gains'], targets)
except ValueError as error:
    message = str(error); assert 'violates 2 ohm constraint' in message
else:
    raise AssertionError('sub-2-ohm physical bank was incorrectly accepted')
report = {'status': 'correctly_rejected', 'runner_sha256': sha256(Path(__file__)),
          'source_report_sha256': sha256(source_report), 'targets': targets.model_dump(mode='json'),
          'error': message, 'qualified': False, 'physical_validation': False}
with (runs / 'mirror-bank-native-2ohm-gate.json').open('x') as stream: stream.write(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
