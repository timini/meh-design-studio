Experimental synthetic-driver geometry. STL units: millimetres.
No mounting, sealing, structural, slicer or physical print qualification.
See docs/end-to-end-evidence.md in the repository.
